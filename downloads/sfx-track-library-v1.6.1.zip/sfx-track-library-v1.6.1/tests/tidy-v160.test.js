// v1.6.0：从时间线选中保存组合（套餐，含裁切/淡入淡出/声像）、一键整理音轨（方案 + 执行 + 回滚 + 备份）
const path = require('path'), fs = require('fs'), os = require('os');
const assert = require('assert');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve');
const { Library } = require(P + '/lib/library');
const { ResolveBridge } = require(P + '/lib/resolve-bridge');
const { MPI, TI, Timeline, Project } = require('./mock-resolve-lib');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx160-'));
const media = path.join(tmp, 'media'); fs.mkdirSync(media);
for (const n of ['Whoosh_A.wav', 'Boom Hit.wav', 'Riser Up.wav', 'Room Tone.wav', 'bgm_happy.mp3', 'unknown_long.wav', 'mystery.wav', 'ding.wav']) fs.writeFileSync(path.join(media, n), 'RIFF' + n);
const project = new Project();
const resolve = { GetProjectManager: () => ({ GetCurrentProject: () => project, SaveProject: () => true }), GetVersion: () => [21, 1, 0, 0], GetProductName: () => 'DaVinci Resolve Studio', GetVersionString: () => '21.1.0' };
const byTrack = (tl, i) => tl.audio[i - 1].slice().sort((a, b) => a.start - b.start).map((x) => [x.start, x.start + x.dur]);

(async () => {
  const lib = await new Library(path.join(tmp, 'lib')).load();
  await lib.addSounds(['Whoosh_A.wav', 'Boom Hit.wav', 'Riser Up.wav', 'Room Tone.wav'].map((n) => path.join(media, n)), null, { copy: true });
  const snd = (n) => lib.data.sounds.find((s) => s.name === n);
  const b = new ResolveBridge('x', '/nope'); b.resolve = resolve; b.version = [21, 1, 0];
  const settings = { poolRootName: '音效库', autoSaveBeforeApply: true, soundTarget: 'route', copyFiles: true };

  // ---------- 1. 选中保存为组合 ----------
  const tl = new Timeline('源', 25, 0); project.tl = tl; tl.project = project;
  const mpW = new MPI(lib.abs(snd('Whoosh_A').file), 25, 50), mpH = new MPI(lib.abs(snd('Boom Hit').file), 25, 15), mpNew = new MPI(path.join(media, 'ding.wav'), 25, 20);
  const c1 = new TI(mpW, 1000, 50, 0); c1.props = { AudioVolume: -3, AudioPan: 0 }; c1.fades = { FadeIn: 0, FadeOut: 5 };
  const c2 = new TI(mpH, 1010, 10, 2); c2.props = { AudioVolume: 2, AudioPan: -30 }; c2.fades = { FadeIn: 0, FadeOut: 0 };   // 裁切：从第 2 帧开始，长 10 帧（整段 15）
  const c3 = new TI(mpNew, 1030, 20, 0); c3.props = {}; c3.fades = { FadeIn: 2, FadeOut: 2 };                           // 不在库里 → 自动入库
  const vclip = new TI(new MPI('cam.mov', 25, 100, 'Video + Audio'), 1000, 100, 0); vclip.GetType = () => 'video';
  tl.audio[1].push(c1, c2); tl.AddTrack('audio', 'stereo'); tl.audio[2].push(c3);
  tl.selected = [c1, c2, c3, vclip];
  const cap = await b.captureSelectionAsStack(lib, { name: '重转场组合' }, settings);
  assert.equal(cap.layers, 3); assert.deepEqual(cap.added, ['ding']); assert.equal(cap.skipped.length, 1);
  const k = lib.stack(cap.stack.id);
  assert.deepEqual(k.layers.map((l) => l.offsetMs), [0, 400, 1200]);
  assert.deepEqual(k.layers.map((l) => l.gainDb), [-3, 2, 0]);
  assert.deepEqual(k.layers.map((l) => [l.inSec, l.durationSec]), [[0, 0], [0.08, 0.4], [0, 0]], '整段用 0，裁切的记录入点和时长');
  assert.deepEqual(k.layers.map((l) => [l.fadeInMs, l.fadeOutMs]), [[0, 200], [0, 0], [80, 80]]);
  assert.equal(k.layers[1].pan, -30);
  await assert.rejects(b.captureSelectionAsStack(lib, {}, settings), /先在时间线上选中/, '清空选择后报错').catch(() => {});
  tl.selected = [];
  await assert.rejects(b.captureSelectionAsStack(lib, {}, settings), /先在时间线上选中/);
  console.log('CAPTURE: 选中保存组合（偏移/裁切/淡入淡出/声像/自动入库/跳过视频） OK');

  // ---------- 2. 放置组合：裁切与淡入淡出生效 ----------
  const t2 = new Timeline('目标', 25, 0); project.tl = t2; t2.project = project; t2.playhead = 500;
  for (const s of lib.data.sounds) await lib.setLoudness(s.id, { lufs: -18, peakDb: -3, peakOffsetSec: 0.1, duration: 2 });
  const sr = await b.placeStack(lib, k, settings, 'playhead', () => ({ gainDb: -1, fadeInMs: 0, fadeOutMs: 0 }));
  assert.equal(sr.placed, 3, JSON.stringify(sr.failed));
  const hitPlaced = t2.audio.flat().find((x) => x.mp.file.includes('Boom'));
  assert.equal(hitPlaced.start, 510); assert.equal(hitPlaced.dur, 10, '按记录的裁切放 10 帧'); assert.equal(hitPlaced.srcStart, 2, '入点 0.08s = 2 帧');
  assert.equal(hitPlaced.props.AudioVolume, 1, '响度 -1 + 层增益 +2'); assert.equal(hitPlaced.props.AudioPan, -30);
  const dingPlaced = t2.audio.flat().find((x) => x.mp.file.includes('ding'));
  assert.deepEqual(dingPlaced.fades, { FadeIn: 2, FadeOut: 2 }, '层记录的淡入淡出覆盖分类默认');
  console.log('PLACE: 组合放置裁切/声像/淡入淡出 OK');

  // ---------- 3. 一键整理：方案 ----------
  const t3 = new Timeline('乱轨', 25, 0); project.tl = t3; t3.project = project;
  while (t3.audio.length < 8) t3.AddTrack('audio', 'stereo');
  t3.names = ['音频 1', '音频 2', '音频 3', '音频 4', '音频 5', '音频 6', '锁定轨', '音乐 避让'];
  const cam = () => { const it = new TI(new MPI(path.join(media, 'cam_take.mov'), 25, 300, 'Video + Audio'), 0, 300, 0); it.linked = [{}]; return it; };
  t3.audio[0].push(cam());                                                                  // A1：对白（链接画面）→ 不动，改名“对白”
  t3.audio[1].push(new TI(mpW, 100, 50, 0), new TI(mpW, 900, 50, 0));                       // A2：两个 whoosh
  t3.audio[2].push(new TI(mpW, 120, 50, 0));                                                // A3：与 A2 第一个重叠的 whoosh → 需要 FX 转场 2
  const hitClip = new TI(mpH, 300, 15, 0); hitClip.props = { AudioVolume: -6.5, AudioPan: 10 }; hitClip.fades = { FadeIn: 3, FadeOut: 10 }; hitClip.color = 'Orange';
  t3.audio[3].push(hitClip, new TI(new MPI(path.join(media, 'mystery.wav'), 25, 20), 2000, 20, 0)); // A4：打击（带属性） + 未知短音效
  t3.audio[4].push(new TI(new MPI(path.join(media, 'bgm_happy.mp3'), 25, 2000), 0, 2000, 0), new TI(new MPI(path.join(media, 'unknown_long.wav'), 25, 1500), 2100, 1500, 0)); // A5：音乐 + 未知长音频(60s)
  t3.audio[5].push(new TI(new MPI(path.join(media, 'Room Tone.wav'), 25, 500), 50, 500, 0)); // A6：氛围（库里有）
  t3.audio[6].push(new TI(mpH, 50, 15, 0)); t3.locked[7] = true;                             // A7：锁定 → 不动
  t3.audio[7].push(new TI(new MPI(path.join(media, 'bgm_happy.mp3'), 25, 2000), 100, 100, 100)); // A8：避让轨 → 不动
  const dis = new TI(mpW, 3000, 50, 0); dis.enabled = false; t3.audio[1].push(dis);          // 禁用片段 → 不动
  const plan = await b.tidyPlan(lib, { mode: 'detailed' });
  assert.equal(plan.moves, 8, JSON.stringify(plan.newTracks.map((t) => [t.name, t.clips.length])));
  const names = plan.newTracks.map((t) => t.name);
  assert.deepEqual(names, ['FX 转场', 'FX 转场 2', 'FX 打击', 'FX 其他', 'BG 氛围', 'MX 音乐'], names.join(','));
  assert.deepEqual(plan.newTracks.find((t) => t.name === 'FX 转场').clips.map((c) => c.start), [100, 900]);
  assert.deepEqual(plan.newTracks.find((t) => t.name === 'FX 转场 2').clips.map((c) => c.start), [120]);
  assert.deepEqual(plan.newTracks.find((t) => t.name === 'MX 音乐').clips.map((c) => c.name).sort(), ['bgm_happy.mp3', 'unknown_long.wav'], '未知的 60 秒音频按时长归到音乐');
  assert.deepEqual(plan.newTracks.find((t) => t.name === 'FX 其他').clips.map((c) => c.name), ['mystery.wav']);
  assert.ok(plan.keepReasons.some((r) => /链接/.test(r.reason)) && plan.keepReasons.some((r) => /锁定/.test(r.reason)) && plan.keepReasons.some((r) => /避让/.test(r.reason)) && plan.keepReasons.some((r) => /禁用/.test(r.reason)));
  assert.deepEqual(plan.willEmpty, [3, 4, 5, 6], 'A2 还剩一个禁用片段，不会空');
  // 简化模式
  const plan2 = await b.tidyPlan(lib, { mode: 'simple' });
  assert.deepEqual(plan2.newTracks.map((t) => t.name), ['FX 音效', 'FX 音效 2', 'BG 氛围', 'MX 音乐']);
  // 最少轨道：音效 + 氛围混装，只剩 音效 / 音乐
  const planC = await b.tidyPlan(lib, { mode: 'compact' });
  // 50~550 的氛围与 100 / 120 两个 whoosh 三者同时重叠 → 至少 3 条音效轨（装箱已是最少）
  assert.deepEqual(planC.newTracks.map((t) => [t.name, t.clips.length]), [['FX 音效', 3], ['FX 音效 2', 2], ['FX 音效 3', 1], ['MX 音乐', 2]], JSON.stringify(planC.newTracks.map((t) => [t.name, t.clips.length])));
  assert.ok(planC.tracksAfterCount <= plan2.tracksAfterCount && plan2.tracksAfterCount <= plan.tracksAfterCount, '三种方式轨道数递减');
  // 保护某条轨
  const plan3 = await b.tidyPlan(lib, { mode: 'detailed', protectTracks: [5] });
  assert.ok(!plan3.newTracks.some((t) => t.name === 'MX 音乐'));
  console.log('TIDY PLAN: 分类/分轨/保留原因/简化/保护 OK');

  // ---------- 4. 一键整理：执行 ----------
  const planD = await b.tidyPlan(lib, { mode: 'detailed' });
  const beforeTracks = t3.audio.length;
  const r = await b.tidyApply(lib, { backup: true, deleteEmpty: true }, settings);
  assert.equal(r.moved, 8, JSON.stringify(r.failed)); assert.equal(r.failed.length, 0);
  assert.ok(r.backupTimeline && /整理前备份/.test(r.backupTimeline) && project.duplicates.length === 1, '备份时间线');
  assert.equal(project.tl, t3, '仍停留在原时间线');
  assert.deepEqual(r.deletedTracks, ['音频 6', '音频 5', '音频 4', '音频 3']);
  assert.deepEqual(r.tracksAfter, ['对白', '音频 2', '锁定轨', '音乐 避让', 'FX 转场', 'FX 转场 2', 'FX 打击', 'FX 其他', 'BG 氛围', 'MX 音乐'], r.tracksAfter.join(','));
  assert.deepEqual(r.renamed, [{ index: 1, from: '音频 1', to: '对白' }]);
  const idx = (n) => r.tracksAfter.indexOf(n) + 1;
  assert.deepEqual(byTrack(t3, idx('FX 转场')), [[100, 150], [900, 950]]);
  assert.deepEqual(byTrack(t3, idx('FX 转场 2')), [[120, 170]]);
  assert.deepEqual(byTrack(t3, idx('MX 音乐')), [[0, 2000], [2100, 3600]]);
  assert.deepEqual(byTrack(t3, idx('音频 2')), [[3000, 3050]], '禁用片段留在原轨');
  assert.equal(t3.audio[idx('锁定轨') - 1].length, 1); assert.equal(t3.audio[idx('音乐 避让') - 1].length, 1);
  assert.equal(t3.audio[0][0].mp.file.includes('cam_take'), true, '对白原地不动');
  assert.ok(b.pendingTidy === null);
  // 属性保留
  const moved = t3.audio[idx('FX 打击') - 1][0];
  assert.deepEqual(moved.props, { AudioVolume: -6.5, AudioPan: 10 }); assert.deepEqual(moved.fades, { FadeIn: 3, FadeOut: 10 }); assert.equal(moved.color, 'Orange');
  // 方案过期 / 时间线变化
  await assert.rejects(b.tidyApply(lib, {}, settings), /已过期|重新生成/);
  await b.tidyPlan(lib, {});
  project.tl = t2; t2.project = project;
  await assert.rejects(b.tidyApply(lib, {}, settings), /不一样/);
  project.tl = t3;
  // 片段位置变化 → 拒绝
  await b.tidyPlan(lib, {});
  const any = t3.audio[idx('FX 转场') - 1][0]; const old = any.start; any.start = old + 1;
  await assert.rejects(b.tidyApply(lib, {}, settings), /位置和预览时不一样/);
  any.start = old;
  // 再整理一次：已经整齐 → 没有新轨需要创建? （所有可移动片段会被重新分组放到同名新轨，再删掉空的旧轨 → 结果等价）
  await b.tidyPlan(lib, {});
  const r2 = await b.tidyApply(lib, { backup: false, deleteEmpty: true }, settings);
  assert.equal(r2.failed.length, 0); assert.equal(r2.backupTimeline, '');
  assert.deepEqual(r2.tracksAfter, ['对白', '音频 2', '锁定轨', '音乐 避让', 'FX 转场', 'FX 转场 2', 'FX 打击', 'FX 其他', 'BG 氛围', 'MX 音乐']);
  console.log('TIDY APPLY: 搬运/属性/删空轨/改名/备份/校验 OK');

  // ---------- 5. 放置失败回滚 ----------
  const t4 = new Timeline('回滚', 25, 0); project.tl = t4; t4.project = project;
  t4.names = ['音频 1', '音频 2'];
  t4.audio[1].push(new TI(mpW, 100, 50, 0));
  await b.tidyPlan(lib, {});
  const origAppend = project.mp.AppendToTimeline.bind(project.mp);
  let calls = 0;
  project.mp.AppendToTimeline = (infos) => { calls += 1; if (calls === 1) return []; return origAppend(infos); }; // 第一次放置失败
  const r4 = await b.tidyApply(lib, { backup: false }, settings);
  project.mp.AppendToTimeline = origAppend;
  assert.equal(r4.moved, 0); assert.equal(r4.restored, 1); assert.match(r4.failed[0].reason, /已放回原轨/);
  assert.deepEqual(byTrack(t4, t4.names.indexOf('音频 2') + 1), [[100, 150]], '原片段回到原轨原位');
  assert.deepEqual(t4.names, ['音频 2'], '空的新轨和空的旧轨都被删掉');
  console.log('ROLLBACK OK');

  console.log('TIDY v1.6.0 OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
