'use strict';

/* 音效轨道库 —— 面板界面（渲染进程，沙箱环境，只通过 window.sfx 与主进程通信） */

(function () {
  const api = window.sfx || createMockApi();

  const S = {
    tab: 'templates',
    settings: {},
    library: { categories: [], sounds: [], templates: [], stacks: [], collections: [], root: '' },
    status: { connected: false },
    tplSearch: '',
    tplGroup: '',
    tplSort: 'used',
    tplView: 'templates',  // 轨道模板页下半部分：templates | stacks
    selectedTracks: new Set(),
    lastTrackClicked: null,
    selectionKey: '',
    cat: '__all',
    lib: 'sfx',            // 当前库：sfx 音效 / music 音乐（v1.2.0）
    sel: new Set(),        // 多选的音效 id
    anchorId: null,        // Shift 连选的起点
    focusId: null,         // 键盘焦点（空格试听、Enter 放到时间线）
    undo: [],              // 撤销栈（分类、标签、收藏）
    soundSearch: '',
    soundSort: 'used',
    playingId: null,
    filters: { duration: '', channels: '', rate: '', loud: '' },   // v1.4.0 条件筛选
    similarTo: null,       // v1.4.0 “找相似”的目标音效 id
    audition: null         // v1.4.0 时间线试听：{ soundId, trackIndex, anchorFrame }
  };
  const SEARCH = window.SfxSearch || null;

  const $ = (sel, root = document) => root.querySelector(sel);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const clock = (sec) => {
    if (!Number.isFinite(sec) || sec < 0) return '';
    const s = Math.round(sec);
    return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  };
  const date = (iso) => (iso ? iso.slice(0, 10) : '');
  const UNCAT = '未分类';
  const UNCAT_MUSIC = '未分类音乐';
  const isUncat = (n) => n === UNCAT || n === UNCAT_MUSIC;
  const kindOf = (x) => (x && x.kind === 'music' ? 'music' : 'sfx');
  const KIND_NAME = { sfx: '音效', music: '音乐' };
  // v1.3.0：对齐方式 / 达芬奇片段颜色
  const ALIGN_LABEL = { auto: '分类默认', head: '开头', peak: '最响点', tail: '结尾' };
  const ALIGN_HELP = { head: '文件开头对准放置点（环境声、提示音）', peak: '最响的那一下对准放置点（打击、转场）', tail: '文件结尾对准放置点（上升音、反转音）' };
  const CLIP_COLORS = [['Orange', '橙'], ['Apricot', '杏'], ['Yellow', '黄'], ['Lime', '青柠'], ['Olive', '橄榄'], ['Green', '绿'], ['Teal', '蓝绿'], ['Navy', '藏青'], ['Blue', '蓝'], ['Purple', '紫'], ['Violet', '紫罗兰'], ['Pink', '粉'], ['Tan', '棕褐'], ['Beige', '米'], ['Brown', '棕'], ['Chocolate', '巧克力']];
  const alignOptions = (value, withAuto = true) => (withAuto ? ['auto', 'head', 'peak', 'tail'] : ['head', 'peak', 'tail'])
    .map((v) => `<option value="${v}" ${value === v ? 'selected' : ''}>${ALIGN_LABEL[v]}${v === 'auto' ? '' : '对齐'}</option>`).join('');
  /** 当前“放到哪条轨”的说明文字 */
  function targetLabel() {
    const t = S.settings.soundTarget;
    if (t === 'new') return '每次新建一条音轨';
    if (t && t !== 'route') {
      const tr = (S.status.timeline?.tracks || []).find((x) => String(x.index) === String(t));
      return tr ? `A${tr.index} ${tr.name}` : `A${t}`;
    }
    return '按分类固定轨（如 FX 转场、FX 打击、BG 氛围）';
  }

  const ICON = {
    play: '<svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>',
    stop: '<svg viewBox="0 0 24 24" width="12" height="12"><path fill="currentColor" d="M6 6h12v12H6z"/></svg>',
    star: '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M12 17.3l6.2 3.7-1.6-7 5.4-4.7-7.1-.6L12 2 9.1 8.7l-7.1.6 5.4 4.7-1.6 7z"/></svg>',
    starO: '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M12 17.3l6.2 3.7-1.6-7 5.4-4.7-7.1-.6L12 2 9.1 8.7l-7.1.6 5.4 4.7-1.6 7z"/></svg>',
    place: '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M11 3h2v9.2l3.6-3.6L18 10l-6 6-6-6 1.4-1.4 3.6 3.6zM4 19h16v2H4z"/></svg>',
    more: '<svg viewBox="0 0 24 24" width="16" height="16"><circle cx="5" cy="12" r="1.8" fill="currentColor"/><circle cx="12" cy="12" r="1.8" fill="currentColor"/><circle cx="19" cy="12" r="1.8" fill="currentColor"/></svg>',
    close: '<svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M18.3 5.7L12 12l6.3 6.3-1.4 1.4L10.6 13.4 4.3 19.7 2.9 18.3 9.2 12 2.9 5.7 4.3 4.3l6.3 6.3 6.3-6.3z"/></svg>',
    box: '<svg viewBox="0 0 24 24" width="13" height="13" style="margin-right:2px"><path fill="currentColor" d="M3 7l9-4 9 4v10l-9 4-9-4V7zm9 2.2L5.6 7 12 4.2 18.4 7 12 9.2zM5 8.6v7.1l6 2.7V11.3L5 8.6zm8 2.7v7.1l6-2.7V8.6l-6 2.7z"/></svg>',
    saveOne: '<svg viewBox="0 0 24 24" width="15" height="15"><path fill="currentColor" d="M5 3h11l3 3v15H5V3zm2 2v4h8V5H7zm0 8v6h10v-6H7zm2 1h6v4H9v-4z"/></svg>',
    tidy: '<svg viewBox="0 0 24 24" width="13" height="13" style="margin-right:3px"><path fill="currentColor" d="M3 5h12v2H3zm0 6h18v2H3zm0 6h8v2H3zm14-6 4 4-1.4 1.4L17 13.8l-2.6 2.6L13 15z"/></svg>',
    plus: '<svg viewBox="0 0 24 24" width="13" height="13" style="margin-right:3px"><path fill="currentColor" d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',
    ear: '<svg viewBox="0 0 24 24" width="13" height="13" style="margin-right:3px"><path fill="currentColor" d="M17 20c-.3 0-.5 0-.8-.1-.7-.2-1.4-.8-1.7-1.5l-.5-1c-.3-.6-.9-1-1.5-1.1-2.4-.3-4.5-2.5-4.5-5.3h2c0 1.9 1.4 3.3 3 3.3 1.3 0 2.5.8 3 2l.5 1c.1.3.4.5.7.6.4.1.8 0 1-.3.3-.3.4-.7.4-1.1V13c0-.3.1-.6.2-.9A6.5 6.5 0 0 0 12 3.5 6.5 6.5 0 0 0 5.5 10h-2a8.5 8.5 0 0 1 17 0c0 1.1-.2 2.1-.6 3.1v3.4c0 1-.4 1.9-1.1 2.5-.5.6-1.2 1-1.8 1zM12 7a3 3 0 0 0-3 3h2a1 1 0 1 1 1 1v2a3 3 0 0 0 0-6z"/></svg>'
  };

  // ---------- 通用 UI ----------

  function toast(msg, type = '') {
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = msg;
    $('#toastRoot').appendChild(el);
    setTimeout(() => {
      el.classList.add('hide');
      setTimeout(() => el.remove(), 200);
    }, type === 'err' ? 6000 : 3200);
  }

  let busyEl = null;
  function busy(text) {
    if (!text) {
      busyEl?.remove();
      busyEl = null;
      return;
    }
    if (!busyEl) {
      busyEl = document.createElement('div');
      busyEl.className = 'busy';
      document.body.appendChild(busyEl);
    }
    busyEl.innerHTML = `<div class="busy-box"><div class="spinner"></div><div>${esc(text)}</div></div>`;
  }

  /** 调用主进程；统一处理错误和忙碌状态 */
  async function run(promise, busyText) {
    if (busyText) busy(busyText);
    try {
      const r = await promise;
      if (!r || !r.ok) {
        toast(r?.error || '操作失败', 'err');
        return null;
      }
      return r.data;
    } catch (e) {
      toast(`出错了：${e.message}`, 'err');
      return null;
    } finally {
      if (busyText) busy(null);
    }
  }

  function applyState(st) {
    if (!st) return;
    if (st.settings) { S.settings = st.settings; applyTheme(); }
    if (st.library) S.library = st.library;
    if (!S.library.categories.some((c) => c.name === S.cat) && !S.cat.startsWith('__')) S.cat = '__all';
    render();
  }

  function modal({ title, body, actions = [], wide = false, onMount }) {
    closeModal();
    const mask = document.createElement('div');
    mask.className = 'modal-mask';
    mask.innerHTML = `
      <div class="modal" style="${wide ? 'max-width:560px' : ''}">
        <div class="modal-head"><span>${esc(title)}</span><button class="icon-btn x" data-x>${ICON.close}</button></div>
        <div class="modal-body">${body}</div>
        ${actions.length ? `<div class="modal-foot">${actions.map((a, i) => `<button class="btn ${a.primary ? 'primary' : ''} ${a.danger ? 'danger' : ''}" data-a="${i}">${esc(a.label)}</button>`).join('')}</div>` : ''}
      </div>`;
    mask.addEventListener('mousedown', (e) => {
      if (e.target === mask) closeModal();
    });
    mask.querySelector('[data-x]').onclick = closeModal;
    mask.querySelectorAll('[data-a]').forEach((b) => {
      b.onclick = async () => {
        const a = actions[Number(b.dataset.a)];
        if (!a.onClick) return closeModal();
        const keep = await a.onClick(mask.querySelector('.modal-body'));
        // onClick 里已经关掉本弹窗并打开了别的弹窗时，不要把新弹窗也关掉
        if (keep !== true && mask.isConnected) closeModal();
      };
    });
    $('#modalRoot').appendChild(mask);
    const first = mask.querySelector('input[type=text], textarea');
    if (first) setTimeout(() => first.focus(), 30);
    onMount?.(mask.querySelector('.modal-body'));
    return mask;
  }
  function closeModal() {
    $('#modalRoot').innerHTML = '';
  }

  function prompt(title, label, value = '') {
    return new Promise((resolve) => {
      let done = false;
      modal({
        title,
        body: `<div class="field"><label>${esc(label)}</label><input type="text" id="pv" value="${esc(value)}"></div>`,
        actions: [
          { label: '取消', onClick: () => { done = true; resolve(null); } },
          { label: '确定', primary: true, onClick: (b) => { done = true; resolve($('#pv', b).value.trim()); } }
        ],
        onMount: (b) => {
          $('#pv', b).addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
              done = true;
              resolve(e.target.value.trim());
              closeModal();
            }
          });
          const obs = new MutationObserver(() => {
            if (!document.body.contains(b)) {
              obs.disconnect();
              if (!done) resolve(null);
            }
          });
          obs.observe($('#modalRoot'), { childList: true });
        }
      });
    });
  }

  function confirmBox(title, html, okLabel = '确定', danger = false) {
    return new Promise((resolve) => {
      modal({
        title,
        body: html,
        actions: [
          { label: '取消', onClick: () => resolve(false) },
          { label: okLabel, primary: !danger, danger, onClick: () => resolve(true) }
        ]
      });
    });
  }

  function menu(anchor, items) {
    closeMenu();
    const el = document.createElement('div');
    el.className = 'menu';
    el.innerHTML = items.map((it, i) => (it === '-' ? '<hr>' : `<button data-i="${i}" class="${it.danger ? 'danger' : ''}">${esc(it.label)}</button>`)).join('');
    el.querySelectorAll('button').forEach((b) => {
      b.onclick = () => {
        closeMenu();
        items[Number(b.dataset.i)].onClick();
      };
    });
    $('#menuRoot').appendChild(el);
    const r = anchor.getBoundingClientRect();
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    el.style.left = `${Math.max(6, Math.min(window.innerWidth - w - 6, r.right - w))}px`;
    el.style.top = `${r.bottom + h + 6 > window.innerHeight ? Math.max(6, r.top - h - 4) : r.bottom + 4}px`;
    setTimeout(() => document.addEventListener('mousedown', outside), 0);
    function outside(e) {
      if (!el.contains(e.target)) {
        closeMenu();
        document.removeEventListener('mousedown', outside);
      }
    }
  }
  function closeMenu() {
    $('#menuRoot').innerHTML = '';
  }
  // Esc：先关菜单，再关弹窗（输入框里按 Esc 也生效）
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if ($('#menuRoot').childElementCount) { e.stopPropagation(); return closeMenu(); }
    if ($('#modalRoot').childElementCount && !document.querySelector('.busy')) { e.stopPropagation(); closeModal(); }
  }, true);

  // ---------- 状态栏 ----------

  async function refreshStatus(quiet) {
    const before = JSON.stringify(S.status);
    const r = await api.status();
    S.status = r && r.ok ? r.data : { connected: false, error: r?.error };
    renderStatus();
    if (JSON.stringify(S.status) !== before) {
      if (S.tab === 'templates') renderTemplates();
      if (S.tab === 'settings') renderSettings();
    }
    if (!quiet && !S.status.connected) toast(S.status.error || '未连接到达芬奇', 'err');
  }

  function renderStatus() {
    const el = $('#status');
    const st = S.status;
    el.classList.toggle('ok', Boolean(st.connected));
    el.classList.toggle('err', !st.connected);
    let text;
    if (!st.connected) text = st.error || '未连接到达芬奇';
    else if (!st.project) text = '已连接 · 没有打开的项目';
    else text = `${st.project}${st.timeline ? ` › ${st.timeline.name}` : ' · 没有打开时间线'}`;
    $('.status-text', el).textContent = text;
    el.title = st.connected ? `${st.product || ''} ${st.version || ''}` : '';
  }

  // ---------- 轨道模板页 ----------

  function renderTemplates() {
    const page = $('#tab-templates');
    const st = S.status;
    const tl = st.timeline;
    const key = `${st.project || ''}|${tl?.id || tl?.name || ''}`;
    if (S.selectionKey !== key) { S.selectionKey = key; S.selectedTracks.clear(); }
    const valid = new Set((tl?.tracks || []).map(t => t.index));
    for (const i of S.selectedTracks) if (!valid.has(i)) S.selectedTracks.delete(i);
    const selectedCount = S.selectedTracks.size;
    const canSave = (tl?.tracks || []).some(t => S.selectedTracks.has(t.index) && t.clipCount);
    const trackTotal = tl?.tracks?.length || 0;
    const allChecked = trackTotal > 0 && selectedCount === trackTotal;
    const someChecked = selectedCount > 0 && !allChecked;

    // ---- 当前时间线：紧凑的音轨列表
    let tracksHtml;
    if (!st.connected) tracksHtml = `<div class="empty">没有连接到达芬奇。<br>请确认使用的是 Studio 版，并从「工作区 › 工作流集成」打开本插件。</div>`;
    else if (!tl) tracksHtml = `<div class="empty">请先在达芬奇里打开一条时间线</div>`;
    else if (!tl.tracks.length) tracksHtml = `<div class="empty">这条时间线还没有音轨</div>`;
    else {
      tracksHtml = `<div class="trk-list">${tl.tracks.map((t) => `
        <label class="trk ${S.selectedTracks.has(t.index) ? 'selected' : ''} ${t.enabled === false ? 'muted' : ''}" title="${esc(t.subType || '')}${t.locked ? ' · 已锁定' : ''}${t.enabled === false ? ' · 已静音' : ''}">
          <input type="checkbox" class="track-select" data-select-track="${t.index}" aria-label="选择 A${t.index} ${esc(t.name)}" ${S.selectedTracks.has(t.index) ? 'checked' : ''}>
          <span class="trk-badge">A${t.index}</span>
          <span class="trk-name">${esc(t.name)}</span>
          ${t.locked ? '<span class="trk-flag" title="已锁定">🔒</span>' : ''}${t.enabled === false ? '<span class="trk-flag" title="已静音">M</span>' : ''}
          <span class="trk-count ${t.clipCount ? '' : 'zero'}">${t.clipCount ? `${t.clipCount} 个片段` : '空'}</span>
          <button type="button" class="icon-btn trk-quick" data-act="save-track" data-track="${t.index}" title="只把这一条轨存为模板" ${t.clipCount ? '' : 'disabled'}>${ICON.saveOne}</button>
        </label>`).join('')}</div>`;
    }

    // ---- 模板 / 组合 两个列表用分段切换
    const view = S.tplView === 'stacks' ? 'stacks' : 'templates';
    const groups = [...new Set(S.library.templates.map((t) => t.group).filter(Boolean))];
    let list = S.library.templates.slice();
    const q = S.tplSearch.trim().toLowerCase();
    if (q) list = list.filter((t) => `${t.name} ${t.group} ${t.note} ${t.source?.timeline || ''}`.toLowerCase().includes(q));
    if (S.tplGroup === '__fav') list = list.filter((t) => t.favorite);
    else if (S.tplGroup) list = list.filter((t) => t.group === S.tplGroup);
    list.sort(sorter(S.tplSort));
    const cards = list.length
      ? list.map(tplCard).join('')
      : `<div class="empty">${S.library.templates.length ? '没有匹配的模板' : '还没有模板。<br>在上面勾选一条或多条音效轨 → 保存为模板 → 新项目一键还原。'}</div>`;
    const stackCount = (S.library.stacks || []).length;

    const keepScroll = page.scrollTop;
    page.innerHTML = `
      <div class="section tl-card">
        <div class="section-head">
          <h2>当前时间线</h2>
          <span class="muted" style="margin-left:0">${tl ? `${esc(tl.name)} · ${tl.fps} fps` : ''}</span>
          <span class="spacer"></span>
          ${st.connected && tl && trackTotal ? `<button class="btn small" data-act="tidy" title="分门别类、合并零散轨、自动命名、删空轨；先预览再执行">${ICON.tidy} 整理音轨</button>` : ''}
        </div>
        ${trackTotal ? `<div class="trk-head">
          <label class="trk-all"><input type="checkbox" class="track-select" id="trkAll" ${allChecked ? 'checked' : ''}><span>全选</span></label>
          <span class="muted">${selectedCount ? `已选 ${selectedCount} / ${trackTotal}` : `${trackTotal} 条音轨`}</span>
          <span class="spacer"></span>
          <button class="btn small ghost" data-act="tracks-all">选非空轨</button>
          ${selectedCount ? '<button class="btn small ghost" data-act="tracks-clear">清空</button>' : ''}
        </div>` : ''}
        ${tracksHtml}
        ${trackTotal ? `<div class="trk-foot">
          <span class="faint">${selectedCount ? (canSave ? 'Shift 可连选；保存后可在任何项目一键还原这几条轨' : '所选都是空轨，至少要有一条带片段的') : '勾选要一起保存的音轨'}</span>
          <span class="spacer"></span>
          <button class="btn small primary" data-act="save-selected" ${canSave ? '' : 'disabled'}>保存为模板${selectedCount ? `（${selectedCount} 轨）` : ''}</button>
        </div>` : ''}
      </div>

      <div class="subtabs" id="tplView">
        <button class="subtab ${view === 'templates' ? 'active' : ''}" data-view="templates">轨道模板 <span class="count">${S.library.templates.length}</span></button>
        <button class="subtab ${view === 'stacks' ? 'active' : ''}" data-view="stacks">音效组合 <span class="count">${stackCount}</span></button>
      </div>

      ${view === 'templates' ? `
      <div class="toolbar">
        <input type="search" class="search" id="tplSearch" placeholder="搜索模板名称、分组、备注…" value="${esc(S.tplSearch)}">
        <select id="tplGroup">
          <option value="">全部分组</option>
          <option value="__fav" ${S.tplGroup === '__fav' ? 'selected' : ''}>★ 收藏</option>
          ${groups.map((g) => `<option ${S.tplGroup === g ? 'selected' : ''}>${esc(g)}</option>`).join('')}
        </select>
        <select id="tplSort">
          <option value="used" ${S.tplSort === 'used' ? 'selected' : ''}>最常用</option>
          <option value="recent" ${S.tplSort === 'recent' ? 'selected' : ''}>最近保存</option>
          <option value="lastUsed" ${S.tplSort === 'lastUsed' ? 'selected' : ''}>最近使用</option>
          <option value="name" ${S.tplSort === 'name' ? 'selected' : ''}>名称</option>
        </select>
      </div>
      ${cards}` : `
      <div class="toolbar">
        <button class="btn small primary" data-act="stack-from-selection" ${st.connected && tl ? '' : 'disabled'} title="${st.features?.timelineSelection === false ? '需要达芬奇 21.0.4 以上' : '先在达芬奇时间线上选中几个音效片段（可跨轨）'}">${ICON.plus} 把时间线选中的音效存为组合</button>
        <button class="btn small ghost" data-act="stacks" title="在音效库里勾选音效新建套餐、编辑层参数">管理 / 从库里新建</button>
      </div>
      <div class="faint" style="margin:-4px 0 10px">组合 = 几个音效叠在一起；放到播放头时保持相对位置、裁切、音量、淡入淡出，各层按分类进固定音轨。</div>
      ${stackCardsHtml(true)}`}`;

    page.querySelectorAll('[data-select-track]').forEach(input => {
      input.onclick = (e) => {
        const index = Number(input.dataset.selectTrack);
        const order = (tl?.tracks || []).map((t) => t.index);
        if (e.shiftKey && S.lastTrackClicked != null && order.includes(S.lastTrackClicked)) {
          const a = order.indexOf(S.lastTrackClicked), b = order.indexOf(index);
          for (const i of order.slice(Math.min(a, b), Math.max(a, b) + 1)) {
            if (input.checked) S.selectedTracks.add(i); else S.selectedTracks.delete(i);
          }
        } else if (input.checked) S.selectedTracks.add(index); else S.selectedTracks.delete(index);
        S.lastTrackClicked = index;
        renderTemplates();
      };
    });
    const trkAll = $('#trkAll', page);
    if (trkAll) {
      trkAll.indeterminate = someChecked;
      trkAll.onchange = () => {
        S.selectedTracks = trkAll.checked ? new Set((tl?.tracks || []).map((t) => t.index)) : new Set();
        renderTemplates();
      };
    }
    page.querySelectorAll('#tplView .subtab').forEach((b) => { b.onclick = () => { S.tplView = b.dataset.view; renderTemplates(); }; });
    const search = $('#tplSearch', page);
    if (search) {
      search.oninput = () => {
        S.tplSearch = search.value;
        const pos = search.selectionStart;
        renderTemplates();
        const s2 = $('#tplSearch');
        s2.focus();
        s2.setSelectionRange(pos, pos);
      };
      $('#tplGroup', page).onchange = (e) => { S.tplGroup = e.target.value; renderTemplates(); };
      $('#tplSort', page).onchange = (e) => { S.tplSort = e.target.value; renderTemplates(); };
    }
    page.scrollTop = keepScroll;
  }

  function sorter(mode) {
    return (a, b) => {
      if (mode === 'name') return String(a.name).localeCompare(String(b.name), 'zh-CN');
      if (mode === 'recent') return String(b.createdAt || b.addedAt || '').localeCompare(String(a.createdAt || a.addedAt || ''));
      if (mode === 'lastUsed') return String(b.lastUsed || '').localeCompare(String(a.lastUsed || ''));
      return (b.favorite - a.favorite) || (b.useCount - a.useCount) || String(b.lastUsed || '').localeCompare(String(a.lastUsed || ''));
    };
  }

  function templateTrackList(tpl) {
    return tpl.tracks?.length ? tpl.tracks : [{ sourceIndex: tpl.source?.trackIndex || 1, name: tpl.track?.name || '音效', subType: tpl.track?.subType || 'stereo' }];
  }

  function hasFullBackup(tpl) {
    return tpl.drtReady !== undefined ? tpl.drtReady : Boolean(tpl.drt);
  }

  function tplCard(t) {
    const tracks = templateTrackList(t);
    return `
      <div class="tpl" data-id="${t.id}">
        <div class="tpl-top">
          <div class="tpl-name" title="${esc(t.name)}">${esc(t.name)}</div>
          <span class="tag">${tracks.length} 轨组合</span>
          ${t.group ? `<span class="tag grey">${esc(t.group)}</span>` : ''}
          ${hasFullBackup(t) ? '<span class="tag ok" title="含逐轨 DRT 备份，嵌套应用时也会分别新建音轨">完整备份</span>' : ''}
          <button class="icon-btn ${t.favorite ? 'on' : ''}" data-act="tpl-fav" title="收藏">${t.favorite ? ICON.star : ICON.starO}</button>
        </div>
        <div class="tpl-meta">${t.clipCount} 个音效 · 时长 ${clock(t.lengthSec)} · 用过 ${t.useCount} 次 · ${date(t.createdAt)}</div>
        <div class="tpl-tracks">${tracks.map((x) => `<span>A${x.sourceIndex} ${esc(x.name)}</span>`).join('')}</div>
        ${t.note ? `<div class="tpl-note">${esc(t.note)}</div>` : ''}
        <div class="tpl-actions">
          <button class="btn primary small" data-act="tpl-apply" title="直接应用：自动新建对应数量的音轨，不覆盖已有轨道">一键应用 · 新建 ${tracks.length} 轨</button>
          <button class="btn small" data-act="tpl-options">应用选项</button>
          <button class="btn small" data-act="tpl-detail">详情</button>
          <span class="spacer"></span>
          <button class="icon-btn" data-act="tpl-more" title="更多">${ICON.more}</button>
        </div>
      </div>`;
  }

  function saveTrackDialog(selection) {
    const tl = S.status.timeline;
    const indices = (Array.isArray(selection) ? selection : [selection]).map(Number);
    const tracks = (tl?.tracks || []).filter((t) => indices.includes(t.index));
    if (!tracks.length) return toast('请先勾选要保存的音轨', 'err');
    if (!tracks.some((t) => t.clipCount)) return toast('所选音轨都是空的', 'err');
    const groups = [...new Set(S.library.templates.map((t) => t.group).filter(Boolean))];
    const defaultName = `${tl.name} - ${tracks.length === 1 ? tracks[0].name : `${tracks.length}轨音效组合`}`;
    modal({
      title: `把 ${tracks.length} 条音轨合存为一份模板`,
      body: `
        <div class="note info">${tracks.map((t) => `A${t.index}「${esc(t.name)}」`).join(' + ')}<br>保留轨道顺序、名称和相互之间的时间位置，不改动原时间线。</div>
        <div class="field"><label>模板名称</label><input type="text" id="tName" value="${esc(defaultName)}"></div>
        <div class="field"><label>分组（可选，比如节目名、风格）</label>
          <input type="text" id="tGroup" list="groupList" placeholder="例如：综艺节目 / 片头片尾 / Vlog">
          <datalist id="groupList">${groups.map((g) => `<option value="${esc(g)}">`).join('')}</datalist>
        </div>
        <div class="field"><label>备注（可选）</label><textarea id="tNote" placeholder="这一组音效轨适合什么场景…"></textarea></div>
        <label class="check"><input type="checkbox" id="tCopy" checked><span>把用到的音频文件复制到音效库<small>推荐。相同素材在这一份模板内只复制一次</small></span></label>
        <label class="check"><input type="checkbox" id="tDrt" checked><span>同时保存完整备份（.drt）<small>保存组合备份和逐轨备份；嵌套应用仍会分别新建 ${tracks.length} 条音轨，不压成一条。复杂效果器需试听确认</small></span></label>
        <div class="field"><label>这份模板“一键应用”的方式</label><select id="tMode"><option value="rebuild">精确重建：保留多轨，每个音效都能直接编辑</option><option value="nested">逐轨嵌套：每轨一个整体，尽量保留复杂效果</option></select></div>
        ${S.status.features?.audioProps ? '<div class="note ok">当前版本支持片段音量 / 声像 / 音高 / 淡入淡出，会一并保存。</div>' : '<div class="note">当前版本低于 21.1，精确重建无法还原片段音量等属性。</div>'}`,
      actions: [
        { label: '取消' },
        {
          label: `保存为一份模板（${tracks.length} 轨）`, primary: true,
          onClick: async (b) => {
            const opts = { name: $('#tName', b).value.trim(), group: $('#tGroup', b).value.trim(), note: $('#tNote', b).value.trim(), copyMedia: $('#tCopy', b).checked, fullBackup: $('#tDrt', b).checked, defaultMode: $('#tMode', b).value };
            if (opts.defaultMode === 'nested' && !opts.fullBackup) { toast('逐轨嵌套需要勾选完整备份', 'err'); return true; }
            closeModal();
            const r = await run(api.saveTemplate(tracks.map((t) => t.index), opts), '正在保存所选音轨组合（完整备份可能需要稍候）…');
            if (!r) return;
            S.selectedTracks.clear();
            applyState(r.state);
            const msgs = [`已保存「${r.template.name}」：${r.template.trackCount || tracks.length} 条音轨，${r.template.clipCount} 个音效`];
            if (r.skipped?.length) msgs.push(`${r.skipped.length} 个转场/复合条目无法逐片重建，请用逐轨嵌套`);
            if (r.drtError) msgs.push(`部分完整备份失败：${r.drtError}`);
            toast(msgs.join('；'), r.drtError ? 'err' : 'ok');
            refreshStatus(true);
          }
        }
      ]
    });
  }

  async function quickApply(tpl) {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开目标时间线', 'err');
    const opts = { target: 'new', position: S.settings.defaultPosition || 'original', mode: tpl.defaultMode || (tpl.clipCount ? 'rebuild' : 'nested'), restoreProps: true };
    const r = await run(api.applyTemplate(tpl.id, opts), `正在新建 ${templateTrackList(tpl).length} 条音轨并整组应用…`);
    if (!r) return;
    applyState(r.state);
    showApplyResult(tpl, r);
    refreshStatus(true);
  }

  function applyDialog(tpl) {
    const st = S.status;
    if (!st.connected || !st.timeline) return toast('请先在达芬奇里打开要应用的时间线', 'err');
    const count = templateTrackList(tpl).length;
    const pos = S.settings.defaultPosition || 'original';
    const mode = tpl.defaultMode || (tpl.clipCount ? 'rebuild' : 'nested');
    const presets = st.fairlightPresets || [];
    const backup = hasFullBackup(tpl);
    modal({
      title: `应用选项 · ${tpl.name}`,
      body: `
        <div class="field"><label>目标音轨</label>
          <select id="aTarget"><option value="new">自动新建 ${count} 条音轨，按源轨道顺序和名称放入</option>
            ${count === 1 ? st.timeline.tracks.map((t) => `<option value="${t.index}" ${t.locked ? 'disabled' : ''}>A${t.index} · ${esc(t.name)}（${t.clipCount} 个片段${t.locked ? '，已锁定' : ''}）</option>`).join('') : ''}
          </select>
          <div class="faint">${count > 1 ? '多轨组合始终分别新建，不合并成一条，不覆盖已有音轨。' : '单轨模板也可选择现有空轨；一键应用默认新建。'}</div>
        </div>
        <div class="field"><label>整组从哪里开始</label><div class="radio-group">
          <label class="check"><input type="radio" name="aPos" value="original" ${pos === 'original' ? 'checked' : ''}><span>与原时间线相同的位置<small>相对时间线起点；保留各轨道原来的时间关系</small></span></label>
          <label class="check"><input type="radio" name="aPos" value="playhead" ${pos === 'playhead' ? 'checked' : ''}><span>整组第一个音效对齐当前播放头</span></label>
          <label class="check"><input type="radio" name="aPos" value="start" ${pos === 'start' ? 'checked' : ''}><span>整组第一个音效对齐时间线开头</span></label>
        </div></div>
        <div class="field"><label>还原方式</label><div class="radio-group">
          <label class="check"><input type="radio" name="aMode" value="rebuild" ${mode === 'rebuild' ? 'checked' : ''} ${tpl.clipCount ? '' : 'disabled'}><span>精确重建<small>每条源轨对应一条新轨，每个音效单独可编辑；还原位置、裁切和可读取参数</small></span></label>
          <label class="check"><input type="radio" name="aMode" value="nested" ${mode === 'nested' ? 'checked' : ''} ${backup ? '' : 'disabled'}><span>完整保真（逐轨嵌套）${backup ? '' : ' — 缺少逐轨完整备份'}<small>仍是 ${count} 条新音轨，每轨一个嵌套片段；轨内细节尽量保留，复杂效果及总线处理需试听</small></span></label>
        </div></div>
        <label class="check"><input type="checkbox" id="aProps" checked><span>重建时还原音量 / 声像 / 音高 / 淡入淡出</span></label>
        <label class="check"><input type="checkbox" id="aRemember"><span>把所选还原方式设为这份模板的一键应用方式</span></label>
        ${presets.length ? `<div class="field" style="margin-top:10px"><label>Fairlight 预设（可选，作用于整条时间线）</label><select id="aPreset"><option value="">不套用</option>${presets.map((p) => `<option>${esc(p)}</option>`).join('')}</select></div>` : ''}
        ${S.settings.autoSaveBeforeApply ? '<div class="note info">应用前自动保存项目；默认只添加新音轨，不改动已有轨道。</div>' : ''}`,
      actions: [{ label: '取消' }, {
        label: '按以上选项应用', primary: true,
        onClick: async (b) => {
          const opts = { target: $('#aTarget', b).value, position: b.querySelector('input[name=aPos]:checked').value, mode: b.querySelector('input[name=aMode]:checked')?.value || 'rebuild', restoreProps: $('#aProps', b).checked, fairlightPreset: $('#aPreset', b)?.value || '' };
          const remember = $('#aRemember', b).checked;
          closeModal();
          const r = await run(api.applyTemplate(tpl.id, opts), '正在整组应用音效轨道…');
          if (!r) return;
          applyState(r.state);
          showApplyResult(tpl, r);
          if (remember) applyState(await run(api.updateTemplate(tpl.id, { defaultMode: opts.mode })));
          refreshStatus(true);
        }
      }]
    });
  }

  function showApplyResult(tpl, r) {
    const allOk = r.placed === r.expected && !r.missingFiles?.length && !r.notPlaced?.length && !r.propsFail && !r.skippedAtSave && r.fairlightPresetApplied !== false;
    const targets = r.tracks || [{ trackIndex: r.trackIndex, name: tpl.track?.name || '', placed: r.placed, expected: r.expected }];
    if (allOk) return toast(`「${tpl.name}」已应用：${r.createdTracks !== undefined ? `新建 ${r.createdTracks} 条音轨，` : ''}放置 ${r.placed} 个${r.mode === 'nested' ? '嵌套片段' : '音效'}`, 'ok');
    const lines = [targets.map((t) => `A${t.trackIndex}「${esc(t.name)}」：${t.placed}/${t.expected}`).join('<br>')];
    if (r.propsOk || r.propsFail) lines.push(`属性还原：成功 ${r.propsOk} 项${r.propsFail ? `，失败 ${r.propsFail} 项` : ''}。`);
    if (r.missingFiles?.length) lines.push(`<span style="color:var(--err)">找不到素材：${r.missingFiles.map(esc).join('、')}</span>`);
    if (r.notPlaced?.length) lines.push(`<span style="color:var(--err)">没有放上去：${r.notPlaced.map(esc).join('、')}</span>`);
    if (r.skippedAtSave) lines.push(`${r.skippedAtSave} 个转场/复合条目无法精确重建；若需保留，请在应用选项中选择逐轨嵌套。`);
    if (r.fairlightPresetApplied === false) lines.push('<span style="color:var(--err)">Fairlight 预设套用失败。</span>');
    modal({ title: '应用结果（请检查提示）', body: lines.map((l) => `<p style="margin:0 0 8px">${l}</p>`).join(''), actions: [{ label: '知道了', primary: true }] });
  }

  async function detailDialog(tpl) {
    const full = await run(api.getTemplate(tpl.id));
    if (!full) return;
    const rows = full.clips
      .slice()
      .sort((a, b) => a.relStartSec - b.relStartSec)
      .map((c) => {
        const vol = c.props && c.props.AudioVolume !== undefined ? `${Number(c.props.AudioVolume).toFixed(1)} dB` : '—';
        const fades = c.fades && (c.fades.FadeIn || c.fades.FadeOut) ? `${c.fades.FadeIn}/${c.fades.FadeOut}` : '—';
        return `<tr><td>A${c.sourceTrack ?? full.source?.trackIndex ?? 1}</td><td>+${clock(c.relStartSec)}</td><td class="n" title="${esc(c.originalPath)}">${esc(c.name || c.fileName)}</td><td>${clock(c.durationSec) || '<1s'}</td><td>${vol}</td><td>${fades}</td></tr>`;
      })
      .join('');
    modal({
      title: full.name,
      wide: true,
      body: `
        <div class="kv" style="margin-bottom:12px">
          <div>来源</div><div>${esc(full.source?.project || '')} › ${esc(full.source?.timeline || '')}</div>
          <div>音轨</div><div>${templateTrackList(full).map(t => `A${t.sourceIndex} ${esc(t.name)}（${esc(t.subType || '')}）`).join('<br>')}</div>
          <div>帧率</div><div>${full.fps} fps</div>
          <div>开始位置</div><div>时间线起点后 ${clock(full.anchorOffsetSec)}</div>
          <div>完整备份</div><div>${hasFullBackup(full) ? '<span class="feature-ok">有逐轨备份</span>' : `<span class="feature-no">无${full.drtError ? `（${esc(full.drtError)}）` : ''}</span>`}</div>
          <div>属性</div><div>${full.propsCaptured ? '<span class="feature-ok">已保存音量/声像等</span>' : '<span class="feature-no">未保存（版本低于 21.1）</span>'}</div>
        </div>
        ${full.skipped?.length ? `<div class="note">${full.skipped.length} 个条目无法精确重建：${full.skipped.map((s) => esc(s.name)).join('、')}</div>` : ''}
        <table class="clip-table"><thead><tr><th>源轨</th><th>偏移</th><th>音效</th><th>时长</th><th>音量</th><th>淡入/出(帧)</th></tr></thead><tbody>${rows || '<tr><td colspan="6" class="faint">无可重建片段</td></tr>'}</tbody></table>`,
      actions: [{ label: '关闭' }, { label: '应用到当前时间线', primary: true, onClick: () => { closeModal(); applyDialog(tpl); return true; } }]
    });
  }

  function tplMenu(anchor, tpl) {
    menu(anchor, [
      {
        label: '重命名',
        onClick: async () => {
          const v = await prompt('重命名模板', '模板名称', tpl.name);
          if (v) applyState(await run(api.updateTemplate(tpl.id, { name: v })));
        }
      },
      {
        label: '修改分组',
        onClick: async () => {
          const v = await prompt('修改分组', '分组名称（留空 = 不分组）', tpl.group || '');
          if (v !== null) applyState(await run(api.updateTemplate(tpl.id, { group: v })));
        }
      },
      {
        label: '编辑备注',
        onClick: async () => {
          const v = await prompt('编辑备注', '备注', tpl.note || '');
          if (v !== null) applyState(await run(api.updateTemplate(tpl.id, { note: v })));
        }
      },
      { label: '打开模板文件夹', onClick: () => api.revealTemplate(tpl.id) },
      '-',
      {
        label: '删除模板',
        danger: true,
        onClick: async () => {
          if (await confirmBox('删除模板', `<p>确定删除「${esc(tpl.name)}」？模板复制的素材和完整备份也会一并删除。<b>已引用这些库文件的项目可能因此媒体离线</b>，请先确认并做好备份。</p>`, '删除', true)) {
            applyState(await run(api.deleteTemplate(tpl.id)));
          }
        }
      }
    ]);
  }

  // ---------- 音效库页 ----------

  function libCategories() {
    return S.library.categories.filter((c) => kindOf(c) === S.lib);
  }

  function currentCategory() {
    return libCategories().find((c) => c.name === S.cat) || null;
  }

  const projectName = () => S.status.project || '';
  const usedInProject = (s) => Boolean(projectName() && s.usedIn && s.usedIn[projectName()]);
  const activeCollection = () => (S.cat.startsWith('__coll:') ? (S.library.collections || []).find((c) => c.id === S.cat.slice(7)) || null : null);

  function filteredSounds() {
    let list = S.library.sounds.filter((s) => kindOf(s) === S.lib);
    if (S.cat === '__fav') list = list.filter((s) => s.favorite);
    else if (S.cat === '__hot') list = list.filter((s) => s.useCount > 0);
    else if (S.cat === '__proj') list = list.filter(usedInProject);
    else if (S.cat.startsWith('__coll:')) {
      const c = activeCollection();
      const ids = new Set(c ? c.soundIds : []);
      list = list.filter((s) => ids.has(s.id));
    } else if (S.cat !== '__all') list = list.filter((s) => s.category === S.cat);
    const q = S.soundSearch.trim().toLowerCase();
    let scores = null;
    if (q) {
      if (SEARCH) {
        const tokens = SEARCH.tokenize(q);
        scores = new Map();
        list = list.filter((s) => { const sc = SEARCH.matchScore(s, tokens); if (sc > 0) scores.set(s.id, sc); return sc > 0; });
      } else list = list.filter((s) => `${s.name} ${s.category} ${(s.tags || []).join(' ')} ${s.key || ''} ${s.mood || ''}`.toLowerCase().includes(q));
    }
    if (SEARCH && SEARCH.countActiveFilters(S.filters)) list = list.filter((s) => SEARCH.passFilters(s, S.filters));
    if (S.similarTo && SEARCH) {
      const target = S.library.sounds.find((s) => s.id === S.similarTo);
      if (target) return SEARCH.findSimilar(target, list, 40);
    }
    const base = S.cat === '__hot' ? sorter('used') : S.cat === '__proj' ? (a, b) => String(b.usedIn?.[projectName()]?.lastUsed || '').localeCompare(String(a.usedIn?.[projectName()]?.lastUsed || '')) : sorter(S.soundSort);
    list.sort(scores ? (a, b) => (scores.get(b.id) - scores.get(a.id)) || base(a, b) : base);
    return list;
  }

  function renderSounds() {
    const isMusic = S.lib === 'music';
    const page = $(isMusic ? '#tab-music' : '#tab-sounds');
    const kname = KIND_NAME[S.lib];
    const all = S.library.sounds.filter((s) => kindOf(s) === S.lib);
    const total = all.length;
    const favN = all.filter((s) => s.favorite).length;
    const hotN = all.filter((s) => s.useCount > 0).length;
    const projN = all.filter(usedInProject).length;
    const colls = S.library.collections || [];
    const coll = activeCollection();
    const filterN = SEARCH ? SEARCH.countActiveFilters(S.filters) : 0;
    const similarTarget = S.similarTo ? S.library.sounds.find((x) => x.id === S.similarTo) : null;
    const cats = libCategories();
    const cat = currentCategory();
    const tracks = S.status.timeline?.tracks || [];
    const target = S.settings.soundTarget || 'route';
    const align = S.settings.placeAlign || 'auto';
    const list = filteredSounds();
    // 清掉已经不在库里的选择
    for (const id of [...S.sel]) if (!S.library.sounds.some((s) => s.id === id)) S.sel.delete(id);
    const selN = S.sel.size;
    const hint = isMusic
      ? '提示：按住音乐行可以<b>直接拖进达芬奇的时间线或媒体池</b>；点 ⤓ 放到播放头位置（按分类进固定音轨，自动调响度）；「音乐避让对白」可以让有对白的地方音乐自动压低。'
      : '提示：按住音效行可以<b>直接拖进达芬奇的时间线或媒体池</b>；点 ⤓ 放到播放头位置（打击/转场默认用最响点对齐，上升音用结尾对齐）；拖到上方分类标签可以换分类。';
    const keys = '快捷键：<b>空格</b> 试听 · <b>Enter</b> 放到播放头 · <b>↑↓</b> 移动焦点 · <b>Ctrl+A</b> 全选 · <b>Esc</b> 清空选择 · <b>Ctrl+Z</b> 撤销';
    const emptyText = total
      ? `这里还没有${kname}`
      : isMusic
        ? '音乐库是空的。<br>把背景音乐、片头曲拖进来，可以记录 BPM、调性、情绪和授权信息，<br>并在任何项目里一键导入到媒体池。'
        : '音效库是空的。<br>把常用的音效拖进来，插件会帮你分类整理，<br>并在任何项目里一键导入到媒体池。';
    const libDir = `${S.library.root || ''}${S.library.root ? (S.library.root.includes('/') && !S.library.root.includes('\\') ? '/' : '\\') : ''}${isMusic ? 'music' : 'sounds'}`;

    const keepScroll = page.scrollTop;
    page.innerHTML = `
      <div class="chips" id="chips">
        <button class="chip ${S.cat === '__all' ? 'active' : ''}" data-cat="__all">全部 <span class="n">${total}</span></button>
        <button class="chip ${S.cat === '__fav' ? 'active' : ''}" data-cat="__fav">★ 收藏 <span class="n">${favN}</span></button>
        <button class="chip ${S.cat === '__hot' ? 'active' : ''}" data-cat="__hot">常用 <span class="n">${hotN}</span></button>
        ${projectName() ? `<button class="chip ${S.cat === '__proj' ? 'active' : ''}" data-cat="__proj" title="在当前项目「${esc(projectName())}」里放置过的${kname}，方便同一部片子前后统一">本片用过 <span class="n">${projN}</span></button>` : ''}
        <span class="chip-sep"></span>
        ${cats.map((c) => `<button class="chip ${S.cat === c.name ? 'active' : ''}" data-cat="${esc(c.name)}" title="可以把${kname}行拖到这里换分类"><span class="dot" style="background:${esc(c.color)}"></span>${esc(c.name)} <span class="n">${c.count}</span></button>`).join('')}
        <button class="chip" data-act="cat-add" title="新建${kname}分类">＋</button>
        ${colls.length || selN ? '<span class="chip-sep"></span>' : ''}
        ${colls.map((c) => `<button class="chip coll ${S.cat === `__coll:${c.id}` ? 'active' : ''}" data-cat="__coll:${c.id}" title="素材包：${esc(c.note || c.name)}（可以把${kname}行拖到这里加入）">${ICON.box}${esc(c.name)} <span class="n">${c.soundIds.filter((id) => S.library.sounds.some((x) => x.id === id && kindOf(x) === S.lib)).length}</span></button>`).join('')}
        ${selN ? `<button class="chip" data-act="coll-new" title="把勾选的 ${selN} 个存成一个素材包">＋ 素材包</button>` : colls.length ? '' : `<button class="chip" data-act="coll-new" title="跨分类的一组常用${kname}，比如“综艺常用包”">＋ 素材包</button>`}
      </div>
      ${coll ? `<div class="collbar">
        <span>${ICON.box}<b>${esc(coll.name)}</b>${coll.note ? ` · ${esc(coll.note)}` : ''}</span>
        <button class="btn small primary" data-act="coll-sync" title="把这个素材包里的全部文件导入当前项目媒体池（按分类建文件夹）">导入到媒体池</button>
        <button class="btn small" data-act="coll-rename">重命名 / 备注</button>
        <button class="btn small" data-act="coll-remove-sel" ${selN ? '' : 'disabled'}>移出所选${selN ? `（${selN}）` : ''}</button>
        <span class="grow"></span>
        <button class="btn small danger" data-act="coll-delete">删除素材包</button>
      </div>` : ''}
      ${similarTarget ? `<div class="collbar similar"><span>与「<b>${esc(similarTarget.name)}</b>」相似的${kname}，越靠前越像</span><span class="grow"></span><button class="btn small ghost" data-act="similar-off">关闭</button></div>` : ''}
      ${S.audition ? `<div class="collbar audition"><span>${ICON.ear}<b>时间线试听中</b>：${esc(S.library.sounds.find((x) => x.id === S.audition.soundId)?.name || '')} → A${S.audition.trackIndex}「试听」轨。<b>↑ ↓</b> 换一个候选 · <b>Enter</b> 确认正式放置 · <b>Esc</b> 取消。到达芬奇里按空格听。</span><span class="grow"></span><button class="btn small primary" data-act="audition-confirm">确认放置</button><button class="btn small ghost" data-act="audition-cancel">取消</button></div>` : ''}
      <div class="libpath" title="${esc(libDir)}">
        <span>${kname}文件夹</span><span class="p"><bdi>${esc(libDir)}</bdi></span>
        <button class="btn small ghost" data-act="lib-open">打开</button>
        <button class="btn small ghost" data-act="lib-choose" title="换一个文件夹作为音效库（音效和音乐都会存在那里的 sounds / music 子文件夹）">更换…</button>
      </div>

      <div class="dropzone" id="dropzone">
        <div class="big">把${kname}文件或文件夹拖到这里 → ${cat ? `放入「<b>${esc(cat.name)}</b>」` : '<b>自动分类</b>'}</div>
        <div class="faint">${cat ? `切换到「全部」时会根据文件名自动归类` : '根据文件名关键词自动归类，你手动调整后它会记住你的习惯'}</div>
        <div class="row">
          <button class="btn small" data-act="add-browse">选择文件…</button>
          <button class="btn small" data-act="add-pool" title="先在达芬奇媒体池里选中${kname}">添加媒体池选中项</button>
          <button class="btn small" data-act="add-timeline" title="先在时间线上选中音频片段（需要 21.0.4+）">添加时间线选中项</button>
        </div>
      </div>

      ${batchbarHtml(selN)}

      <div class="toolbar">
        <input type="search" class="search" id="soundSearch" placeholder="${isMusic ? '搜索音乐（名称、标签、调性、情绪）…' : '搜索音效…'}" value="${esc(S.soundSearch)}">
        <select id="soundSort" ${S.cat === '__hot' ? 'disabled' : ''}>
          <option value="used" ${S.soundSort === 'used' ? 'selected' : ''}>最常用</option>
          <option value="recent" ${S.soundSort === 'recent' ? 'selected' : ''}>最近添加</option>
          <option value="lastUsed" ${S.soundSort === 'lastUsed' ? 'selected' : ''}>最近使用</option>
          <option value="name" ${S.soundSort === 'name' ? 'selected' : ''}>名称</option>
        </select>
        <select id="soundTarget" title="点 ⤓ 时放到哪条音轨">
          <option value="route" ${target === 'route' ? 'selected' : ''}>放到：按分类固定轨（推荐）</option>
          <option value="new" ${target === 'new' ? 'selected' : ''}>放到：每次新建音轨</option>
          ${tracks.map((t) => `<option value="${t.index}" ${String(target) === String(t.index) ? 'selected' : ''}>放到：A${t.index} ${esc(t.name)}</option>`).join('')}
        </select>
        <select id="alignSel" title="放置时用${kname}的哪个位置对准播放头 / 标记">${alignOptions(align)}</select>
        <button class="btn small ${filterN ? 'primary' : ''}" data-act="filters" title="按时长、声道、采样率、响度筛选">筛选${filterN ? ` · ${filterN}` : ''}</button>
        <button class="btn small ${S.audition ? 'primary' : ''}" data-act="audition-toggle" title="把当前焦点的${kname}放到“试听”轨，用 ↑↓ 换着听，Enter 确认">${ICON.ear} 时间线试听</button>
        <button class="btn small ghost" data-act="sel-all" title="选中当前列表里的全部（Ctrl+A）">全选</button>
      </div>

      <div id="soundList">
        ${list.length ? list.map(soundRow).join('') : `<div class="empty">${emptyText}</div>`}
      </div>
      <div class="hint">${hint}<br>${keys}</div>

      <div class="footer-actions">
        <button class="btn primary" data-act="sync-pool">导入到当前项目媒体池</button>
        <button class="btn" data-act="batch-place" title="在时间线上打好标记（M），一键把${kname}放到每个标记或每个画面切点上">按标记 / 切点批量放置…</button>
        ${isMusic
          ? '<button class="btn" data-act="duck" title="有对白的地方自动把音乐压低">音乐避让对白…</button><button class="btn" data-act="cuesheet" title="把时间线上用到的音乐（含未入库的音频）导出成表格：入出点、时长、来源、授权">导出音乐使用清单…</button>'
          : `<button class="btn" data-act="stacks" title="几个音效叠在一起一键放置">音效套餐${S.library.stacks?.length ? ` <span class="count">${S.library.stacks.length}</span>` : ''}</button><button class="btn" data-act="ambience" title="选一个环境声，循环铺满入出点范围或播放头到结尾，接缝处自动交叉淡化">氛围铺底…</button>`}
        <button class="btn" data-act="manage-cats">管理${kname}分类、音轨与关键词</button>
      </div>`;

    const search = $('#soundSearch', page);
    search.oninput = () => {
      S.soundSearch = search.value;
      const pos = search.selectionStart;
      renderSounds();
      const s2 = $('#soundSearch');
      s2.focus();
      s2.setSelectionRange(pos, pos);
    };
    $('#soundSort', page).onchange = (e) => {
      S.soundSort = e.target.value;
      renderSounds();
    };
    $('#soundTarget', page).onchange = async (e) => {
      const st = await run(api.saveSettings({ soundTarget: e.target.value }));
      if (st) S.settings = st.settings;
    };
    $('#alignSel', page).onchange = async (e) => {
      const st = await run(api.saveSettings({ placeAlign: e.target.value }));
      if (st) S.settings = st.settings;
    };
    setupDropzone($('#dropzone', page));
    setupChipDrop(page);
    page.querySelectorAll('.sound[draggable=true]').forEach((row) => {
      row.addEventListener('dragstart', (e) => {
        // 使用系统级文件拖放：可以直接拖进达芬奇时间线/媒体池，也可以拖到上方分类标签换分类
        e.preventDefault();
        internalDragId = row.dataset.id;
        internalDropped = false;
        row.classList.add('dragging');
        document.body.classList.add('is-dragging');
        api.startDrag(row.dataset.id);
      });
    });
    page.scrollTop = keepScroll;
    probeDurations(list);
    probeLoudness(list);
  }

  function batchbarHtml(selN) {
    if (!selN) return '';
    return `
      <div class="batchbar" id="batchbar">
        <span>已选 <b>${selN}</b> 个</span>
        <button class="btn small" data-act="b-cat">移到分类…</button>
        <button class="btn small" data-act="b-tag">加标签…</button>
        <button class="btn small" data-act="b-fav">★ 收藏</button>
        <button class="btn small" data-act="b-unfav">取消收藏</button>
        <button class="btn small danger" data-act="b-del">移除…</button>
        <button class="btn small" data-act="batch-place" title="把勾选的这些轮流放到时间线的标记或画面切点上">放到标记/切点…</button>
        <button class="btn small" data-act="coll-add" title="加入某个素材包">加入素材包…</button>
        <span class="grow"></span>
        <button class="btn small ghost" data-act="sel-clear">清空选择</button>
      </div>`;
  }

  /** 只更新选中/焦点状态和批量条，不重绘整个列表（滚动位置、播放进度都保持） */
  function syncSelectionUI() {
    const list = document.getElementById('soundList');
    const page = $(S.lib === 'music' ? '#tab-music' : '#tab-sounds');
    if (!list || !page) return renderSounds();
    for (const row of list.querySelectorAll('.sound[data-id]')) {
      const on = S.sel.has(row.dataset.id);
      row.classList.toggle('selected', on);
      row.classList.toggle('focused', S.focusId === row.dataset.id);
      const cb = row.querySelector('.selbox');
      if (cb && cb.checked !== on) cb.checked = on;
    }
    const existing = $('#batchbar', page);
    const selN = S.sel.size;
    if (!selN) { existing?.remove(); return; }
    if (existing) { existing.querySelector('b').textContent = selN; return; }
    $('.toolbar', page).insertAdjacentHTML('beforebegin', batchbarHtml(selN));
  }

  // 正在从面板拖出的音效（系统拖放回到本窗口时，用它识别是“自己的”文件）
  let internalDragId = null;
  let internalDropped = false;
  const endDragVisual = () => {
    document.querySelectorAll('.sound.dragging').forEach((r) => r.classList.remove('dragging'));
    document.body.classList.remove('is-dragging');
  };
  const clearInternalDrag = () => {
    internalDropped = true;
    endDragVisual();
    setTimeout(() => { internalDragId = null; }, 50);
  };
  // 拖拽结束且没有落在本面板里 = 拖进了达芬奇，记一次使用
  document.addEventListener('mousemove', (e) => {
    if (internalDragId && e.buttons === 0) {
      const id = internalDragId;
      internalDragId = null;
      endDragVisual();
      if (!internalDropped) api.markUsed(id).then((r) => r?.ok && applyState(r.data));
    }
  });
  document.addEventListener('dragend', endDragVisual);

  // ---------- 多选 ----------

  function snapshotOf(ids) {
    return S.library.sounds
      .filter((s) => ids.includes(s.id))
      .map((s) => ({ id: s.id, category: s.category, tags: [...(s.tags || [])], favorite: Boolean(s.favorite) }));
  }

  /** 点击行：Ctrl 切换选择，Shift 连选，普通点击只设焦点并清空选择 */
  function pickRow(id, e) {
    S.focusId = id;
    if (e.shiftKey && S.anchorId) {
      const ids = filteredSounds().map((s) => s.id);
      const a = ids.indexOf(S.anchorId);
      const b = ids.indexOf(id);
      if (a >= 0 && b >= 0) for (const x of ids.slice(Math.min(a, b), Math.max(a, b) + 1)) S.sel.add(x);
    } else if (e.ctrlKey || e.metaKey) {
      if (S.sel.has(id)) S.sel.delete(id);
      else S.sel.add(id);
      S.anchorId = id;
    } else {
      S.sel.clear();
      S.anchorId = id;
    }
    syncSelectionUI();
  }

  // ---------- 撤销 ----------

  function pushUndo(label, items) {
    if (!items || !items.length) return;
    S.undo.push({ label, items });
    if (S.undo.length > 30) S.undo.shift();
  }

  async function undoLast() {
    const u = S.undo.pop();
    if (!u) return toast('没有可以撤销的操作');
    const st = await run(api.restoreSounds(u.items), '正在撤销…');
    if (st) {
      applyState(st);
      toast(`已撤销：${u.label}`, 'ok');
    }
  }

  /** 修改单个音效并记入撤销栈 */
  async function updateOne(s, patch, label) {
    const before = label ? snapshotOf([s.id]) : null;
    const st = await run(api.updateSound(s.id, patch));
    if (st) {
      applyState(st);
      if (before) pushUndo(label, before);
    }
    return st;
  }

  /** 批量操作：删除不可撤销；其余操作记入撤销栈 */
  async function batchAct(action, payload, label) {
    const ids = [...S.sel];
    if (!ids.length) return toast('请先选择音效', 'err');
    const before = action === 'delete' ? [] : snapshotOf(ids);
    const r = await run(api.batchSounds(ids, action, payload), '正在批量处理…');
    if (!r) return null;
    applyState(r.state);
    if (before.length) pushUndo(`${label}（${r.done} 个）`, before);
    toast(`${label}：${r.done} 个${r.skipped ? `，${r.skipped} 个类型不符已跳过` : ''}`, 'ok');
    return r;
  }

  function batchCategoryDialog() {
    const n = S.sel.size;
    modal({
      title: `移动 ${n} 个${KIND_NAME[S.lib]}`,
      body: `<div class="field"><label>目标分类</label><select id="bCat">${libCategories().map((c) => `<option>${esc(c.name)}</option>`).join('')}</select></div>
             ${S.settings.learnOnMove ? '<div class="faint">移动后会记住这些文件名的特征，以后类似文件自动归到这里。</div>' : ''}`,
      actions: [
        { label: '取消' },
        {
          label: '移动',
          primary: true,
          onClick: async (b) => {
            const name = $('#bCat', b).value;
            await batchAct('category', { category: name, learn: Boolean(S.settings.learnOnMove) }, `已移到「${name}」`);
          }
        }
      ]
    });
  }

  function batchTagDialog() {
    modal({
      title: `给 ${S.sel.size} 个${KIND_NAME[S.lib]}加标签`,
      body: `<div class="field"><label>标签（逗号分隔，可多个）</label><input type="text" id="bTag" placeholder="如 开场, 欢快"></div>`,
      actions: [
        { label: '取消' },
        {
          label: '添加',
          primary: true,
          onClick: async (b) => {
            const tags = $('#bTag', b).value.split(/[,，、\n]/).map((x) => x.trim()).filter(Boolean);
            if (!tags.length) return toast('请输入标签', 'err');
            await batchAct('addTags', { tags }, '已加标签');
          }
        }
      ]
    });
  }

  function batchDeleteDialog() {
    const n = S.sel.size;
    modal({
      title: `移除 ${n} 个${KIND_NAME[S.lib]}`,
      body: `<p>从音效库移除选中的 ${n} 个？移除后无法用撤销恢复。</p><label class="check"><input type="checkbox" id="bDelFile"><span>同时删除库里的文件副本</span></label>`,
      actions: [
        { label: '取消' },
        {
          label: '移除',
          danger: true,
          onClick: async (b) => {
            await batchAct('delete', { deleteFile: Boolean($('#bDelFile', b)?.checked) }, '已移除');
            S.sel.clear();
            renderSounds();
          }
        }
      ]
    });
  }

  // ---------- 键盘 ----------

  document.addEventListener('keydown', (e) => {
    if (S.tab !== 'sounds' && S.tab !== 'music') return;
    if (e.target && e.target.closest && e.target.closest('input, textarea, select, [contenteditable]')) return;
    if (document.querySelector('.modal-mask, .busy')) return;
    const key = e.key;
    const mod = e.ctrlKey || e.metaKey;
    const lower = key.toLowerCase();
    if (mod && lower === 'a') {
      e.preventDefault();
      S.sel = new Set(filteredSounds().map((s) => s.id));
      return syncSelectionUI();
    }
    if (mod && lower === 'z') {
      e.preventDefault();
      return undoLast();
    }
    if (mod || e.altKey) return;
    const cur = S.library.sounds.find((x) => x.id === S.focusId);
    if (key === ' ') {
      if (!cur) return;
      e.preventDefault();
      if (e.target && e.target.tagName === 'BUTTON') e.target.blur();
      togglePlay(cur);
    } else if (key === 'Enter') {
      if (!cur) return;
      e.preventDefault();
      if (e.target && e.target.tagName === 'BUTTON') e.target.blur();
      if (S.audition) auditionConfirm();
      else placeSound(cur, 'playhead');
    } else if (key === 'Escape') {
      if (S.audition) return auditionCancel();
      if (S.sel.size) {
        S.sel.clear();
        syncSelectionUI();
      }
    } else if (key === 'ArrowDown' || key === 'ArrowUp') {
      e.preventDefault();
      const ids = filteredSounds().map((s) => s.id);
      if (!ids.length) return;
      let i = ids.indexOf(S.focusId);
      i = i < 0 ? 0 : Math.min(ids.length - 1, Math.max(0, i + (key === 'ArrowDown' ? 1 : -1)));
      if (e.shiftKey) {
        if (S.anchorId == null) S.anchorId = S.focusId;
        const a = ids.indexOf(S.anchorId);
        S.sel = new Set(ids.slice(Math.min(a < 0 ? i : a, i), Math.max(a < 0 ? i : a, i) + 1));
      }
      S.focusId = ids[i];
      syncSelectionUI();
      document.querySelector(`.sound[data-id="${S.focusId}"]`)?.scrollIntoView({ block: 'nearest' });
      if (S.audition && !e.shiftKey) auditionSwapLater(S.library.sounds.find((x) => x.id === S.focusId));
    }
  });

  function soundRow(s) {
    const cat = S.library.categories.find((c) => c.name === s.category);
    const playing = S.playingId === s.id;
    const picked = S.sel.has(s.id);
    const focused = S.focusId === s.id;
    const musicMeta = s.kind === 'music' ? [s.bpm ? `${s.bpm} BPM` : '', s.key, s.mood].filter(Boolean).join(' · ') : '';
    const tags = (s.tags || []).length ? ` · #${(s.tags || []).join(' #')}` : '';
    const effAlign = S.settings.placeAlign && S.settings.placeAlign !== 'auto' ? S.settings.placeAlign : cat?.align || 'head';
    const peakTxt = effAlign === 'peak' && s.peakOffsetSec != null && s.peakOffsetSec >= 0.05 ? ` · 最响点 ${s.peakOffsetSec.toFixed(2)}s` : '';
    const projTxt = usedInProject(s) ? ` · 本片 ${s.usedIn[projectName()].count} 次` : '';
    const chTxt = s.channels ? (s.channels === 1 ? ' · 单声道' : s.channels === 2 ? '' : ` · ${s.channels}声道`) : '';
    return `
      <div class="sound ${s.exists ? '' : 'missing'} ${playing ? 'playing' : ''} ${picked ? 'selected' : ''} ${focused ? 'focused' : ''}" data-id="${s.id}" draggable="${s.exists ? 'true' : 'false'}" title="${esc(s.absPath)}">
        <input type="checkbox" class="selbox" data-act="sel" ${picked ? 'checked' : ''} title="选择（Ctrl 多选，Shift 连选）">
        <button class="play" data-act="play" title="试听（空格）">${playing ? ICON.stop : ICON.play}</button>
        <div class="info">
          <div class="name">${esc(s.name)}</div>
          <div class="meta"><span class="dot" style="background:${esc(cat?.color || '#888')}"></span>${esc(s.category)}${s.duration ? ` · ${s.duration < 1 ? `${s.duration.toFixed(1)}s` : clock(s.duration)}` : ''}${chTxt}${musicMeta ? ` · ${esc(musicMeta)}` : ''}${s.loudness != null ? ` · ${s.loudness.toFixed(1)} LUFS` : ''}${peakTxt}${s.useCount ? ` · 用过 ${s.useCount} 次` : ''}${projTxt}${esc(tags)}${s.exists ? '' : ' · 文件丢失'}</div>
        </div>
        ${waveformHtml(s, playing)}
        <button class="icon-btn ${s.favorite ? 'on' : ''}" data-act="fav" title="收藏">${s.favorite ? ICON.star : ICON.starO}</button>
        <button class="icon-btn" data-act="place" title="放到时间线播放头位置（Enter）">${ICON.place}</button>
        <button class="icon-btn" data-act="more" title="更多">${ICON.more}</button>
      </div>`;
  }

  /** 波形缩略图（点击任意位置从那里开始试听）；最响点用一根竖线标出 */
  function waveformHtml(s, playing) {
    const w = 96, h = 26;
    if (!s.waveform || !s.waveform.length) return `<div class="wave empty" data-act="seek" title="${s.exists ? '分析后显示波形' : ''}"></div>`;
    const n = s.waveform.length;
    const bw = w / n;
    let bars = '';
    for (let i = 0; i < n; i += 1) {
      const v = Math.max(1, (s.waveform[i] / 100) * (h - 2));
      bars += `<rect x="${(i * bw).toFixed(2)}" y="${((h - v) / 2).toFixed(2)}" width="${Math.max(0.6, bw - 0.35).toFixed(2)}" height="${v.toFixed(2)}" rx="0.4"/>`;
    }
    const peakX = s.duration > 0 && s.peakOffsetSec != null ? Math.min(w - 1, (s.peakOffsetSec / s.duration) * w) : null;
    return `<div class="wave ${playing ? 'playing' : ''}" data-act="seek" title="点击从这里试听">
      <svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" preserveAspectRatio="none"><g class="bars">${bars}</g>${peakX !== null ? `<line class="peak" x1="${peakX.toFixed(1)}" y1="0" x2="${peakX.toFixed(1)}" y2="${h}"/>` : ''}</svg>
      <div class="played" ${playing ? 'id="playProgress"' : ''}></div>
    </div>`;
  }

  function setupDropzone(zone) {
    let depth = 0;
    zone.addEventListener('dragenter', (e) => {
      if (!e.dataTransfer.types.includes('Files')) return;
      e.preventDefault();
      depth += 1;
      zone.classList.add('hover');
    });
    zone.addEventListener('dragover', (e) => {
      if (e.dataTransfer.types.includes('Files')) e.preventDefault();
    });
    zone.addEventListener('dragleave', () => {
      depth = Math.max(0, depth - 1);
      if (!depth) zone.classList.remove('hover');
    });
    zone.addEventListener('drop', async (e) => {
      e.preventDefault();
      depth = 0;
      zone.classList.remove('hover');
      if (internalDragId) return clearInternalDrag();
      const paths = [...e.dataTransfer.files].map((f) => api.pathForFile(f)).filter(Boolean);
      if (!paths.length) return toast('没有拿到文件路径，请从资源管理器拖入，或用「选择文件」', 'err');
      addFiles(paths);
    });
  }

  // 整个窗口任意位置拖入文件也能添加
  document.addEventListener('dragover', (e) => {
    if (e.dataTransfer.types.includes('Files')) e.preventDefault();
  });
  document.addEventListener('drop', (e) => {
    if (!e.dataTransfer.types.includes('Files')) return;
    e.preventDefault();
    if (internalDragId) return clearInternalDrag();
    if (e.target.closest && e.target.closest('#dropzone')) return;
    const paths = [...e.dataTransfer.files].map((f) => api.pathForFile(f)).filter(Boolean);
    if (paths.length) {
      if (S.tab !== 'sounds' && S.tab !== 'music') switchTab(S.lib === 'music' ? 'music' : 'sounds');
      addFiles(paths);
    }
  });

  function setupChipDrop(page) {
    page.querySelectorAll('.chip[data-cat]').forEach((chip) => {
      const name = chip.dataset.cat;
      if (name.startsWith('__') && !name.startsWith('__coll:')) return;
      chip.addEventListener('dragover', (e) => {
        if (internalDragId) {
          e.preventDefault();
          chip.classList.add('drop-hover');
        }
      });
      chip.addEventListener('dragleave', () => chip.classList.remove('drop-hover'));
      chip.addEventListener('drop', async (e) => {
        chip.classList.remove('drop-hover');
        const id = internalDragId;
        if (!id) return;
        e.preventDefault();
        e.stopPropagation();
        internalDropped = true;
        internalDragId = null;
        endDragVisual();
        const s = S.library.sounds.find((x) => x.id === id);
        if (!s) return;
        if (name.startsWith('__coll:')) {
          const c = (S.library.collections || []).find((x) => x.id === name.slice(7));
          if (!c) return;
          if (c.soundIds.includes(id)) return toast(`「${s.name}」已经在素材包「${c.name}」里`);
          const st = await run(api.updateCollection(c.id, { add: [id] }));
          if (st) { applyState(st); toast(`已加入素材包「${c.name}」`, 'ok'); }
          return;
        }
        if (s.category === name) return;
        const st = await updateOne(s, { category: name }, `移到「${name}」`);
        if (st) toast(`已移到「${name}」${S.settings.learnOnMove ? '，已记住这类文件名' : ''}`, 'ok');
      });
    });
  }

  async function addFiles(paths) {
    const cat = currentCategory();
    const r = await run(api.addFiles(paths, cat ? cat.name : null, S.lib), '正在整理…');
    if (r) reportAdd(r);
  }

  function reportAdd(r) {
    applyState(r.state);
    const x = r.results;
    const parts = [`新增 ${x.added} 个`];
    if (x.duplicate) parts.push(`${x.duplicate} 个已在库中`);
    if (x.skipped) parts.push(`${x.skipped} 个不是音频已跳过`);
    if (x.auto?.length) {
      const byCat = {};
      for (const a of x.auto) byCat[a.category] = (byCat[a.category] || 0) + 1;
      parts.push(`自动归类：${Object.entries(byCat).map(([k, v]) => `${k} ${v}`).join('，')}`);
    }
    toast(parts.join('；'), x.added ? 'ok' : '');
  }

  // 试听
  const player = new Audio();
  player.addEventListener('ended', () => setPlaying(null));
  player.addEventListener('error', () => {
    if (S.playingId) toast('无法播放这个文件（格式不受支持或文件丢失）', 'err');
    setPlaying(null);
  });
  player.addEventListener('timeupdate', () => {
    const bar = document.getElementById('playProgress');
    if (bar && player.duration) bar.style.width = `${(player.currentTime / player.duration) * 100}%`;
  });
  /** 点击波形：从该位置开始播放这条音效 */
  function seekPlay(s, fraction) {
    if (!s.url) return;
    if (S.playingId !== s.id) {
      player.src = s.url;
      setPlaying(s.id);
    }
    const go = () => { if (player.duration) player.currentTime = Math.max(0, Math.min(player.duration - 0.05, fraction * player.duration)); player.play().catch(() => {}); };
    if (player.readyState >= 1) go(); else player.addEventListener('loadedmetadata', go, { once: true });
  }
  function setPlaying(id) {
    S.playingId = id;
    if (S.tab === 'sounds' || S.tab === 'music') {
      document.querySelectorAll('.sound').forEach((row) => {
        const on = row.dataset.id === id;
        row.classList.toggle('playing', on);
        row.querySelector('.play').innerHTML = on ? ICON.stop : ICON.play;
        const wave = row.querySelector('.wave');
        if (wave) {
          wave.classList.toggle('playing', on);
          const played = wave.querySelector('.played');
          if (played) { played.id = on ? 'playProgress' : ''; if (!on) played.style.width = '0'; }
        }
      });
    }
  }
  function togglePlay(s) {
    if (S.playingId === s.id) {
      player.pause();
      return setPlaying(null);
    }
    if (!s.url) return;
    player.src = s.url;
    player.currentTime = 0;
    player.play().catch(() => {});
    setPlaying(s.id);
  }

  // 读取时长（只对没有时长的做一次）
  const probing = new Set();
  // ---------- 响度测量（v1.2.1）：渲染进程解码音频，用 js/loudness.js 计算 ----------
  const loudPending = new Map();   // id -> Promise，避免同一条音效重复测量
  const loudFailed = new Set();    // 测量过但没有结果（静音、解码失败），不再重试
  let loudQueue = [];
  let loudActive = 0;
  let listRefreshTimer = null;

  function measureSound(s) {
    if (s.loudness != null && s.peakOffsetSec != null && s.waveform) return Promise.resolve(s.loudness);
    if (!s.exists || !window.SfxLoudness || loudFailed.has(s.id)) return Promise.resolve(null);
    if (loudPending.has(s.id)) return loudPending.get(s.id);
    const p = (async () => {
      try {
        const r = await api.readSoundBytes(s.id);
        if (!r || !r.ok || !r.data) { loudFailed.add(s.id); return null; }
        const bytes = r.data;
        const ab = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
        const Ctx = window.AudioContext || window.webkitAudioContext;
        const ctx = new Ctx();
        let buf;
        try { buf = await ctx.decodeAudioData(ab); } finally { ctx.close().catch(() => {}); }
        const chans = [];
        for (let c = 0; c < buf.numberOfChannels; c += 1) chans.push(buf.getChannelData(c));
        const m = window.SfxLoudness.measureChannels(chans, buf.sampleRate);
        const waveform = window.SfxLoudness.waveformBins ? window.SfxLoudness.waveformBins(chans, 140) : null;
        s.loudness = Number.isFinite(m.lufs) ? Math.round(m.lufs * 10) / 10 : null;
        s.peakDb = Number.isFinite(m.peakDb) ? Math.round(m.peakDb * 10) / 10 : null;
        s.peakOffsetSec = Number.isFinite(m.peakOffsetSec) ? Math.round(m.peakOffsetSec * 1000) / 1000 : null;
        s.truePeakDb = Number.isFinite(m.truePeakDb) ? Math.round(m.truePeakDb * 10) / 10 : null;
        s.zcr = Number.isFinite(m.zcr) ? m.zcr : null;
        s.channels = buf.numberOfChannels;
        s.sampleRate = buf.sampleRate;
        if (waveform) s.waveform = waveform;
        if (Number.isFinite(buf.duration) && buf.duration > 0) s.duration = buf.duration;
        await api.setLoudness(s.id, { lufs: m.lufs, peakDb: m.peakDb, peakOffsetSec: m.peakOffsetSec, duration: buf.duration, waveform, channels: buf.numberOfChannels, sampleRate: buf.sampleRate, truePeakDb: m.truePeakDb, zcr: m.zcr });
        if (s.loudness == null) loudFailed.add(s.id);
        return s.loudness;
      } catch (e) {
        loudFailed.add(s.id);
        return null;
      }
    })().finally(() => loudPending.delete(s.id));
    loudPending.set(s.id, p);
    return p;
  }

  /** 列表里还没有响度的音效，后台慢慢测（同时最多 2 个） */
  function probeLoudness(list) {
    if (!window.SfxLoudness) return;
    const todo = list.filter((s) => s.exists && (s.loudness == null || s.peakOffsetSec == null || !s.waveform) && !loudFailed.has(s.id) && !loudPending.has(s.id)).slice(0, 60);
    if (!todo.length) return;
    loudQueue.push(...todo);
    pumpLoudness();
  }

  function pumpLoudness() {
    while (loudActive < 2 && loudQueue.length) {
      const s = loudQueue.shift();
      loudActive += 1;
      measureSound(s).finally(() => {
        loudActive -= 1;
        scheduleListRefresh();
        pumpLoudness();
      });
    }
  }

  /** 测量完成后合并刷新列表，避免每条都重绘一次 */
  function scheduleListRefresh() {
    if (listRefreshTimer) return;
    listRefreshTimer = setTimeout(() => {
      listRefreshTimer = null;
      if ((S.tab === 'sounds' || S.tab === 'music') && !document.querySelector('.modal-mask, .busy') && !document.activeElement?.closest?.('input, textarea, select')) renderSounds();
    }, 800);
  }

  function probeDurations(list) {
    const todo = list.filter((s) => s.exists && !s.duration && s.url && !probing.has(s.id)).slice(0, 30);
    let active = 0;
    const next = () => {
      while (active < 3 && todo.length) {
        const s = todo.shift();
        probing.add(s.id);
        active += 1;
        const a = new Audio();
        a.preload = 'metadata';
        const done = () => {
          active -= 1;
          a.src = '';
          next();
        };
        a.onloadedmetadata = () => {
          if (Number.isFinite(a.duration)) {
            s.duration = a.duration;
            api.setDuration(s.id, a.duration);
            const row = document.querySelector(`.sound[data-id="${s.id}"] .meta`);
            if (row && !row.textContent.includes(':') && !row.textContent.includes('<1s')) {
              const cat = row.querySelector('.dot');
              row.innerHTML = '';
              row.appendChild(cat);
              row.insertAdjacentText('beforeend', `${s.category} · ${s.duration < 1 ? '<1s' : clock(s.duration)}${s.useCount ? ` · 用过 ${s.useCount} 次` : ''}`);
            }
          }
          done();
        };
        a.onerror = done;
        a.src = s.url;
      }
    };
    next();
  }

  function soundMenu(anchor, s) {
    const items = [
      { label: '放到时间线（播放头位置）', onClick: () => placeSound(s, 'playhead') },
      { label: '　↳ 开头对齐放置', onClick: () => placeSound(s, 'playhead', 'head') },
      { label: '　↳ 最响点对齐放置', onClick: () => placeSound(s, 'playhead', 'peak') },
      { label: '　↳ 结尾对齐放置', onClick: () => placeSound(s, 'playhead', 'tail') },
      { label: '放到时间线开头', onClick: () => placeSound(s, 'start') },
      { label: '找相似的' + KIND_NAME[kindOf(s)], onClick: () => { S.similarTo = s.id; S.soundSearch = ''; renderSounds(); } },
      { label: '加入素材包…', onClick: () => collectionPicker([s.id]) },
      { label: '移动到分类…', onClick: () => moveDialog(s) }
    ];
    if (s.kind !== 'music') items.push({ label: '用它铺底（循环铺满一段范围）…', onClick: () => ambienceDialog(s) });
    if (s.kind === 'music') items.push({ label: '编辑音乐信息（BPM、调性、情绪、授权）…', onClick: () => metaDialog(s) });
    items.push(
      {
        label: '重命名',
        onClick: async () => {
          const v = await prompt('重命名', '显示名称（不改动文件）', s.name);
          if (v) applyState(await run(api.updateSound(s.id, { name: v })));
        }
      },
      { label: '在资源管理器中显示', onClick: () => api.revealSound(s.id) },
      '-',
      {
        label: '从库中移除',
        danger: true,
        onClick: async () => {
          const inLib = !/^([a-zA-Z]:|\\\\|\/)/.test(s.file);
          modal({
            title: '移除',
            body: `<p>从库中移除「${esc(s.name)}」？</p>${inLib ? '<label class="check"><input type="checkbox" id="delFile" checked><span>同时删除库里的文件副本</span></label>' : ''}`,
            actions: [
              { label: '取消' },
              { label: '移除', danger: true, onClick: async (b) => applyState(await run(api.deleteSound(s.id, Boolean($('#delFile', b)?.checked)))) }
            ]
          });
        }
      }
    );
    menu(anchor, items);
  }

  function moveDialog(s) {
    const cats = S.library.categories.filter((c) => kindOf(c) === kindOf(s));
    modal({
      title: `移动「${esc(s.name)}」`,
      body: `<div class="field"><label>目标分类</label><select id="mCat">${cats.map((c) => `<option ${c.name === s.category ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
             ${S.settings.learnOnMove ? '<div class="faint">移动后会记住这个文件名的特征，以后类似文件自动归到这里。</div>' : ''}`,
      actions: [
        { label: '取消' },
        { label: '移动', primary: true, onClick: async (b) => updateOne(s, { category: $('#mCat', b).value }, `移到「${$('#mCat', b).value}」`) }
      ]
    });
  }

  function metaDialog(s) {
    const cats = S.library.categories.filter((c) => kindOf(c) === 'music');
    modal({
      title: `音乐信息：${esc(s.name)}`,
      wide: true,
      body: `
        <div class="grid2">
          <div class="field"><label>名称</label><input type="text" id="mName" value="${esc(s.name)}"></div>
          <div class="field"><label>分类</label><select id="mCat">${cats.map((c) => `<option ${c.name === s.category ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
          <div class="field"><label>BPM（节拍）</label><input type="number" id="mBpm" min="1" max="300" value="${s.bpm || ''}" placeholder="如 120"></div>
          <div class="field"><label>调性</label><input type="text" id="mKey" value="${esc(s.key || '')}" placeholder="如 C 大调、A 小调"></div>
          <div class="field"><label>情绪</label><input type="text" id="mMood" value="${esc(s.mood || '')}" placeholder="如 紧张、温暖、欢快"></div>
          <div class="field"><label>授权 / 许可</label><input type="text" id="mLicense" value="${esc(s.license || '')}" placeholder="如 版权免费、买断、CC-BY"></div>
          <div class="field" style="grid-column:1 / -1"><label>来源</label><input type="text" id="mSource" value="${esc(s.source || '')}" placeholder="如 某音乐库、作曲者、委托制作"></div>
        </div>
        <div class="faint">这些信息会显示在音乐行里，并可以在搜索框中搜索调性和情绪。</div>`,
      actions: [
        { label: '取消' },
        {
          label: '保存',
          primary: true,
          onClick: async (b) => {
            const v = (id) => $(`#${id}`, b).value;
            const bpm = Number(v('mBpm'));
            const patch = {
              name: v('mName').trim() || s.name,
              category: v('mCat'),
              bpm: bpm > 0 ? bpm : null,
              key: v('mKey'),
              mood: v('mMood'),
              license: v('mLicense'),
              source: v('mSource')
            };
            applyState(await run(api.updateSound(s.id, patch)));
          }
        }
      ]
    });
  }

  const needsMeasure = (s) => Boolean(s.exists && (s.loudness == null || s.peakOffsetSec == null || !s.waveform) && !loudFailed.has(s.id));

  /** 放置前确保这些音效都测过响度和最响点（逐个测，显示进度） */
  async function ensureMeasured(list) {
    const todo = (list || []).filter(needsMeasure);
    for (let i = 0; i < todo.length; i += 1) {
      busy(`正在分析音频（响度 / 最响点）${i + 1} / ${todo.length}…`);
      await measureSound(todo[i]);
    }
    if (todo.length) busy(null);
  }

  async function placeSound(s, position = 'playhead', align) {
    await ensureMeasured([s]);
    const al = align || S.settings.placeAlign || 'auto';
    const r = await run(api.soundToTimeline(s.id, S.settings.soundTarget || 'route', position, { align: al }), '正在放到时间线…');
    if (!r) return;
    applyState(r.state);
    const where = position === 'start' ? '时间线开头' : '播放头';
    const a = r.audio || {};
    const gainTxt = a.gainDb ? `，音量 ${a.gainDb > 0 ? '+' : ''}${a.gainDb} dB` : (a.gainReason === 'no-loudness' ? '，未测量响度，未调音量' : '');
    const alignTxt = r.alignLabel ? `，${r.alignLabel}${r.alignFallback ? '（没测到最响点）' : ''}` : '';
    toast(`「${s.name}」→ A${r.trackIndex}${r.trackName ? ` ${r.trackName}` : ''}${r.createdTrack ? '（新建）' : ''}，${where}${alignTxt}${gainTxt}`, 'ok');
    if (r.createdTrack) refreshStatus(true);
  }

  function manageCategories() {
    const cats = libCategories();
    modal({
      title: `管理${KIND_NAME[S.lib]}分类与关键词`,
      wide: true,
      body: `
        <div class="note info">文件名里包含某个分类的关键词，就会被自动归到那个分类。用逗号分隔。「学到的词」来自你手动调整分类，可以随时清理。<br><b>放到音轨</b>：选“按分类固定轨”放置时，这个分类的${KIND_NAME[S.lib]}会进名字相同的音轨（没有就新建；位置被占就用“名字 2”“名字 3”）。<b>默认对齐</b>：开头 / 最响点 / 结尾哪一处对准播放头或标记。</div>
        ${cats
          .map(
            (c) => `
          <div class="section" style="padding:10px;margin-bottom:8px" data-cid="${c.id}">
            <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px">
              <input type="color" value="${esc(c.color)}" data-f="color" style="width:28px;height:24px;padding:0;border:0;background:none">
              <input type="text" value="${esc(c.name)}" data-f="name" style="flex:1" ${isUncat(c.name) ? 'disabled' : ''}>
              <span class="faint">${c.count} 个</span>
              ${isUncat(c.name) ? '' : `<button class="btn small danger" data-del="${c.id}">删除</button>`}
            </div>
            <div class="grid2" style="grid-template-columns:1.4fr 1fr 1fr">
              <div class="field"><label>放到音轨</label><input type="text" data-f="trackName" value="${esc(c.trackName || '')}" placeholder="如 FX 转场"></div>
              <div class="field"><label>默认对齐</label><select data-f="align" title="${esc(ALIGN_HELP[c.align] || '')}">${alignOptions(c.align || 'head', false)}</select></div>
              <div class="field"><label>片段颜色</label><select data-f="clipColor"><option value="">不设置</option>${CLIP_COLORS.map(([v, l]) => `<option value="${v}" ${c.clipColor === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
            </div>
            ${isUncat(c.name) ? '<div class="faint">没有匹配到任何关键词的${KIND_NAME[S.lib]}会放在这里。</div>' : `
            <textarea data-f="keywords" placeholder="关键词，逗号分隔" style="min-height:40px">${esc(c.keywords.join(', '))}</textarea>
            <div class="faint" style="margin-top:4px">学到的词：</div>
            <textarea data-f="learned" placeholder="（暂无）" style="min-height:32px">${esc(c.learned.join(', '))}</textarea>`}
          </div>`
          )
          .join('')}`,
      actions: [
        { label: '取消' },
        {
          label: '保存',
          primary: true,
          onClick: async (b) => {
            const split = (v) => v.split(/[,，、\n]/).map((x) => x.trim()).filter(Boolean);
            let last = null;
            for (const box of b.querySelectorAll('[data-cid]')) {
              const c = cats.find((x) => x.id === box.dataset.cid);
              const patch = {};
              const name = box.querySelector('[data-f=name]').value.trim();
              const color = box.querySelector('[data-f=color]').value;
              if (name && name !== c.name) patch.name = name;
              if (color !== c.color) patch.color = color;
              const trackName = box.querySelector('[data-f=trackName]').value.trim();
              if (trackName !== (c.trackName || '')) patch.trackName = trackName;
              const al = box.querySelector('[data-f=align]').value;
              if (al !== (c.align || 'head')) patch.align = al;
              const cc = box.querySelector('[data-f=clipColor]').value;
              if (cc !== (c.clipColor || '')) patch.clipColor = cc;
              const kw = box.querySelector('[data-f=keywords]');
              const ln = box.querySelector('[data-f=learned]');
              if (kw && kw.value !== c.keywords.join(', ')) patch.keywords = split(kw.value);
              if (ln && ln.value !== c.learned.join(', ')) patch.learned = split(ln.value);
              if (Object.keys(patch).length) {
                const st = await run(api.updateCategory(c.id, patch));
                if (st) last = st;
              }
            }
            if (last) {
              applyState(last);
              toast('分类已更新', 'ok');
            }
          }
        }
      ],
      onMount: (b) => {
        b.querySelectorAll('[data-del]').forEach((btn) => {
          btn.onclick = async () => {
            const c = cats.find((x) => x.id === btn.dataset.del);
            closeModal();
            if (await confirmBox('删除分类', `<p>删除分类「${esc(c.name)}」？其中的 ${c.count} 个会移到「${isUncat(c.name) ? '' : (kindOf(c) === 'music' ? UNCAT_MUSIC : UNCAT)}」。</p>`, '删除', true)) {
              applyState(await run(api.deleteCategory(c.id)));
            }
            manageCategories();
          };
        });
      }
    });
  }

  // ---------- 批量放置：按标记 / 画面切点（v1.3.0） ----------

  const frameClock = (frame, fps, start) => clock(Math.max(0, (frame - start) / (fps || 25)));

  async function batchPlaceDialog() {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    const bp = S.settings.batchPlace || { source: 'markers', markerColor: '', preFrames: 0, rotate: true, align: 'auto' };
    const pts = await run(api.timelinePoints({ videoTrack: 1 }), '正在读取时间线的标记和切点…');
    if (!pts) return;
    const kname = KIND_NAME[S.lib];
    const selIds = [...S.sel];
    const listIds = filteredSounds().filter((x) => x.exists).map((x) => x.id);
    const colorOpts = ['<option value="">全部颜色</option>', ...pts.colors.map((c) => `<option value="${esc(c)}" ${bp.markerColor === c ? 'selected' : ''}>${esc(c)}</option>`)].join('');
    const vtOpts = Array.from({ length: Math.max(1, pts.videoTrackCount || 1) }, (_, i) => `<option value="${i + 1}" ${pts.videoTrack === i + 1 ? 'selected' : ''}>V${i + 1}</option>`).join('');
    const catName = S.cat === '__fav' ? '★ 收藏' : S.cat === '__hot' ? '常用' : S.cat === '__all' ? '全部' : S.cat;
    const markerCount = (color) => pts.markers.filter((m) => !color || m.color === color).length;
    modal({
      title: `按标记 / 切点批量放置${kname}`,
      wide: true,
      body: `
        <div class="field"><label>放在哪些时间点</label><div class="radio-group">
          <label class="check"><input type="radio" name="bpSrc" value="markers" ${bp.source !== 'cuts' ? 'checked' : ''}><span>时间线标记 <b id="bpMarkerN">${markerCount(bp.markerColor)}</b> 个 <select id="bpColor" style="width:auto;margin-left:6px">${colorOpts}</select><small>先在达芬奇时间线上按 M 打标记；可以只用某种颜色的标记</small></span></label>
          <label class="check"><input type="radio" name="bpSrc" value="cuts" ${bp.source === 'cuts' ? 'checked' : ''}><span>画面切点 <b id="bpCutN">${pts.cuts.length}</b> 个 <select id="bpVT" style="width:auto;margin-left:6px">${vtOpts}</select><small>视频轨上每个片段的开头（和后面有空隙的结尾）</small></span></label>
        </div></div>
        <div class="field"><label>用哪些${kname}（多个时轮流使用，相邻两个点不会重复）</label><div class="radio-group">
          <label class="check"><input type="radio" name="bpCand" value="sel" ${selIds.length ? 'checked' : 'disabled'}><span>已勾选的 ${selIds.length} 个${selIds.length ? '' : '<small>列表里用复选框勾选后可用</small>'}</span></label>
          <label class="check"><input type="radio" name="bpCand" value="list" ${selIds.length ? '' : 'checked'}><span>当前列表「${esc(catName)}」里的 ${listIds.length} 个${S.soundSearch.trim() ? '（已按搜索过滤）' : ''}</span></label>
        </div></div>
        <div class="grid2">
          <div class="field"><label>提前几帧（负数 = 延后）</label><input type="number" id="bpPre" step="1" min="-250" max="250" value="${bp.preFrames || 0}"></div>
          <div class="field"><label>对齐方式</label><select id="bpAlign">${alignOptions(bp.align || 'auto')}</select></div>
        </div>
        <label class="check"><input type="checkbox" id="bpRotate" ${bp.rotate !== false ? 'checked' : ''}><span>打乱顺序轮换使用<small>关闭则按列表顺序依次使用</small></span></label>
        <div class="note info">放到：${esc(targetLabel())}。按分类固定轨时，位置被占会自动放到下一条同名轨；每个${kname}仍按响度自动调音量。${S.settings.autoSaveBeforeApply ? '开始前会自动保存项目。' : ''}</div>`,
      actions: [
        { label: '取消' },
        {
          label: '开始放置',
          primary: true,
          onClick: async (b) => {
            const src = b.querySelector('input[name=bpSrc]:checked').value;
            const color = $('#bpColor', b).value;
            const points = src === 'cuts' ? pts.cuts : pts.markers.filter((m) => !color || m.color === color).map((m) => m.frame);
            const candSel = b.querySelector('input[name=bpCand]:checked')?.value === 'sel';
            const cand = candSel ? selIds : listIds;
            const preFrames = Math.round(Number($('#bpPre', b).value) || 0);
            const align = $('#bpAlign', b).value;
            const rotate = $('#bpRotate', b).checked;
            if (!points.length) { toast(src === 'cuts' ? '这条视频轨上没有切点' : '没有符合条件的标记', 'err'); return true; }
            if (!cand.length) { toast(`没有可用的${kname}`, 'err'); return true; }
            closeModal();
            const st2 = await run(api.saveSettings({ batchPlace: { source: src, markerColor: color, preFrames, rotate, align } }));
            if (st2) S.settings = st2.settings;
            await ensureMeasured(cand.map((id) => S.library.sounds.find((x) => x.id === id)).filter(Boolean));
            const r = await run(api.placeBatch(cand, points, { preFrames, align, rotate }), `正在把 ${kname}放到 ${points.length} 个点上…`);
            if (!r) return;
            applyState(r.state);
            refreshStatus(true);
            showBatchResult(r, pts);
          }
        }
      ],
      onMount: (b) => {
        $('#bpColor', b).onchange = () => { $('#bpMarkerN', b).textContent = markerCount($('#bpColor', b).value); b.querySelector('input[name=bpSrc][value=markers]').checked = true; };
        $('#bpVT', b).onchange = async () => {
          const p2 = await run(api.timelinePoints({ videoTrack: Number($('#bpVT', b).value) }));
          if (p2) { pts.cuts = p2.cuts; $('#bpCutN', b).textContent = p2.cuts.length; }
          b.querySelector('input[name=bpSrc][value=cuts]').checked = true;
        };
      }
    });
  }

  function showBatchResult(r, pts) {
    const where = r.trackNames?.length ? `音轨 ${r.trackNames.join('、')}` : `A${(r.tracks || []).join('、A')}`;
    const head = `已放置 ${r.placed} / ${r.points} 个 → ${where}${r.createdTracks ? `（新建 ${r.createdTracks} 条音轨）` : ''}`;
    if (!r.failed?.length) return toast(head, 'ok');
    modal({
      title: '批量放置结果',
      body: `<p style="margin:0 0 8px">${esc(head)}</p><p style="margin:0 0 6px;color:var(--err)">${r.failed.length} 个点没有放上去：</p>
        <table class="clip-table"><thead><tr><th>位置</th><th>${esc(KIND_NAME[S.lib])}</th><th>原因</th></tr></thead><tbody>
        ${r.failed.slice(0, 40).map((f) => `<tr><td>${frameClock(f.frame, pts.fps, pts.startFrame)}</td><td class="n">${esc(f.name)}</td><td class="n" title="${esc(f.error)}">${esc(f.error)}</td></tr>`).join('')}
        </tbody></table>${r.failed.length > 40 ? `<div class="faint">…还有 ${r.failed.length - 40} 个</div>` : ''}`,
      wide: true,
      actions: [{ label: '知道了', primary: true }]
    });
  }

  // ---------- 音乐避让对白（v1.3.0） ----------

  function duckDialog() {
    const tl = S.status.timeline;
    if (!S.status.connected || !tl) return toast('请先在达芬奇里打开时间线', 'err');
    const tracks = tl.tracks || [];
    if (tracks.length < 2) return toast('时间线上至少要有音乐轨和对白轨两条音轨', 'err');
    const d = S.settings.ducking || { reduceDb: 9, preMs: 150, postMs: 250, fadeMs: 250, mergeGapMs: 700 };
    const isMusicName = (n) => /音乐|mx|music|bgm|配乐|歌/i.test(n || '');
    const isDlgName = (n) => /对白|dx|dialog|vo\b|人声|台词|采访|voice|说话|口播|解说/i.test(n || '');
    const musicGuess = tracks.find((t) => isMusicName(t.name) && t.clipCount) || tracks.find((t) => isMusicName(t.name)) || tracks.find((t) => t.clipCount);
    modal({
      title: '音乐避让对白',
      wide: true,
      body: `
        <div class="field"><label>音乐在哪条轨</label><select id="dkMusic">${tracks.map((t) => `<option value="${t.index}" ${musicGuess && t.index === musicGuess.index ? 'selected' : ''} ${t.locked ? 'disabled' : ''}>A${t.index} ${esc(t.name)}（${t.clipCount} 个片段${t.locked ? '，已锁定' : ''}）</option>`).join('')}</select></div>
        <div class="field"><label>对白在哪些轨（可多选）</label>
          ${tracks.map((t) => `<label class="check"><input type="checkbox" class="dkDlg" value="${t.index}" ${isDlgName(t.name) && t.clipCount ? 'checked' : ''}><span>A${t.index} ${esc(t.name)}<small>${t.clipCount} 个片段</small></span></label>`).join('')}
        </div>
        <div class="grid2">
          <div class="field"><label>有对白时音乐降低（dB）</label><input type="number" id="dkDb" min="1" max="40" step="0.5" value="${d.reduceDb}"></div>
          <div class="field"><label>压低 / 抬起的过渡时长（毫秒）</label><input type="number" id="dkFade" min="0" step="50" value="${d.fadeMs}"></div>
          <div class="field"><label>对白开始前提前（毫秒）</label><input type="number" id="dkPre" min="0" step="50" value="${d.preMs}"></div>
          <div class="field"><label>对白结束后延后（毫秒）</label><input type="number" id="dkPost" min="0" step="50" value="${d.postMs}"></div>
          <div class="field"><label>两句话间隔小于多少毫秒就不抬起来</label><input type="number" id="dkGap" min="0" step="100" value="${d.mergeGapMs}"></div>
        </div>
        <div class="note info">做法：有对白的那几段音乐会被切出来，放到音乐轨下方新建的「<b>音乐轨名 避让</b>」轨上并降低音量，两头和音乐轨上的片段交叉淡化，听起来是平滑地压低再抬起。音乐轨上对应位置变成空档。<br>事后想微调：直接改避让轨上片段的音量；想撤销：删掉分段后重新放音乐，${S.settings.autoSaveBeforeApply ? '处理前也会自动保存项目' : '建议先保存项目'}。整段都在对白里的音乐片段只降音量，不切分。</div>`,
      actions: [
        { label: '取消' },
        {
          label: '开始处理',
          primary: true,
          onClick: async (b) => {
            const musicTrack = Number($('#dkMusic', b).value);
            const dialogueTracks = [...b.querySelectorAll('.dkDlg:checked')].map((x) => Number(x.value));
            if (!dialogueTracks.length) { toast('请勾选对白所在的音轨', 'err'); return true; }
            if (dialogueTracks.includes(musicTrack)) { toast('对白轨不能和音乐轨是同一条', 'err'); return true; }
            const num = (id) => Number($(`#${id}`, b).value);
            const opts = { musicTrack, dialogueTracks, reduceDb: Math.abs(num('dkDb')) || 9, fadeMs: num('dkFade'), preMs: num('dkPre'), postMs: num('dkPost'), mergeGapMs: num('dkGap') };
            closeModal();
            const r = await run(api.duckMusic(opts), '正在切分音乐并处理避让…');
            if (!r) return;
            const st2 = await run(api.state());
            applyState(st2);
            refreshStatus(true);
            const parts = [];
            if (r.clips) parts.push(`${r.clips} 个音乐片段切成 ${r.fullSegments + r.duckedSegments} 段，其中 ${r.duckedSegments} 段降低 ${Math.abs(r.reduceDb)} dB 放到 A${r.duckTrack}「${r.duckTrackName}」${r.duckTrackCreated ? '（新建）' : ''}`);
            if (r.wholeDucked) parts.push(`${r.wholeDucked} 个整段在对白里的片段直接降低音量`);
            if (r.untouched) parts.push(`${r.untouched} 个片段没有对白，未改动`);
            if (!r.clips && !r.wholeDucked) parts.push('音乐和对白没有重叠的地方，没有改动');
            if (r.skipped?.length) {
              modal({ title: '避让结果（部分未处理）', body: `<p style="margin:0 0 8px">${esc(parts.join('；'))}</p><p style="margin:0 0 6px;color:var(--err)">未处理：</p><ul style="margin:0;padding-left:18px">${r.skipped.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`, actions: [{ label: '知道了', primary: true }] });
            } else toast(parts.join('；'), 'ok');
          }
        }
      ]
    });
  }

  // ---------- 音效套餐（v1.3.0） ----------

  function stackCardsHtml(all = false) {
    const stacks = (S.library.stacks || []).slice().sort((a, b) => (b.useCount - a.useCount) || String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
    if (!stacks.length) return '<div class="empty">还没有组合。在达芬奇时间线上选中几个音效片段后点上面的按钮，<br>或在音效库里勾选几个音效新建套餐。</div>';
    return stacks.slice(0, all ? stacks.length : 8).map((k) => `
      <div class="tpl" data-stack="${k.id}">
        <div class="tpl-top"><div class="tpl-name" title="${esc(k.note || '')}">${esc(k.name)}</div><span class="tag">${k.layers.length} 层</span>${k.layers.some((l) => l.missing) ? '<span class="tag" style="background:var(--err-soft);color:var(--err)">有文件缺失</span>' : ''}</div>
        <div class="tpl-meta">${k.layers.map((l) => `${esc(l.name)}${l.offsetMs ? `（${l.offsetMs > 0 ? '+' : ''}${l.offsetMs}ms）` : ''}`).join(' + ')}${k.useCount ? ` · 用过 ${k.useCount} 次` : ''}</div>
        <div class="tpl-actions">
          <button class="btn primary small" data-act="stack-place" title="整套放到播放头，各层按分类进固定音轨">放到播放头</button>
          <button class="btn small" data-act="stack-edit">编辑</button>
          <span class="spacer"></span>
          <button class="btn small danger" data-act="stack-delete">删除</button>
        </div>
      </div>`).join('') + (!all && stacks.length > 8 ? `<div class="faint">还有 ${stacks.length - 8} 个，见「管理全部组合 / 套餐」</div>` : '');
  }

  function stackFromSelectionDialog() {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    modal({
      title: '把时间线选中的音效存为组合',
      body: `
        <div class="note info">请确认已在达芬奇时间线上选中要组合的音频片段（可跨多条音轨，最多 12 个）。不在库里的文件会自动加入音效库${S.settings.copyFiles !== false ? '（复制一份）' : ''}；与画面链接的对白不会被收录。</div>
        <div class="field"><label>组合名称</label><input type="text" id="scName" placeholder="例如：重转场（嗖+砰+低频）"></div>
        <div class="field"><label>备注（可选）</label><input type="text" id="scNote" placeholder="适合什么场景"></div>
        <div class="field"><label>新入库的文件归为</label><select id="scKind"><option value="sfx">音效</option><option value="music">音乐</option></select></div>`,
      actions: [{ label: '取消' }, {
        label: '读取选中并保存', primary: true,
        onClick: async (b) => {
          const name = $('#scName', b).value.trim();
          if (!name) { toast('请填写组合名称', 'err'); return true; }
          const r = await run(api.stackFromSelection({ name, note: $('#scNote', b).value.trim(), kind: $('#scKind', b).value }), '正在读取时间线选中的片段…');
          if (!r) return true;
          applyState(r.state);
          toast(`已保存组合「${name}」：${r.layers} 层，跨度 ${r.spanSec} 秒${r.added.length ? `，${r.added.length} 个文件已入库` : ''}${r.skipped.length ? `；跳过 ${r.skipped.length} 个（${r.skipped.map((x) => x.reason).join('、')}）` : ''}`, 'ok');
        }
      }]
    });
  }

  // ---------- 一键整理音轨（v1.6.0） ----------

  async function tidyDialog() {
    const tl = S.status.timeline;
    if (!S.status.connected || !tl) return toast('请先在达芬奇里打开时间线', 'err');
    const td = S.settings.tidy || { mode: 'detailed', backup: true, deleteEmpty: true, gapFrames: 0 };
    const tracks = tl.tracks || [];
    modal({
      title: '一键整理音轨',
      wide: true,
      body: `
        <div class="field"><label>整理方式</label><div class="radio-group">
          <label class="check"><input type="radio" name="tdMode" value="detailed" ${td.mode !== 'simple' && td.mode !== 'compact' ? 'checked' : ''}><span>按分类细分<small>FX 转场 / FX 打击 / FX 提示音 / BG 氛围 / MX 音乐…（用分类设置里的音轨名），每类各自尽量少轨</small></span></label>
          <label class="check"><input type="radio" name="tdMode" value="simple" ${td.mode === 'simple' || td.mode === 'compact' ? 'checked' : ''}><span>最少轨道：只分四类<small>对白 / FX 音效 / BG 氛围（背景音） / MX 音乐。所有音效混在一起装箱、背景音单独装箱、音乐单独装箱，互不重叠的全部合并，轨道最少</small></span></label>
        </div></div>
        <div class="field"><label>这些音轨不要动（可多选；锁定轨、避让 / 试听轨、与画面链接的对白本来就不会动）</label>
          <div style="max-height:150px;overflow:auto;border:1px solid var(--line);border-radius:8px;padding:4px 8px">
            ${tracks.map((t) => `<label class="check" style="margin:4px 0"><input type="checkbox" class="tdProtect" value="${t.index}" ${t.locked ? 'checked disabled' : ''}><span>A${t.index} ${esc(t.name)}<small>${t.clipCount} 个片段${t.locked ? ' · 已锁定' : ''}</small></span></label>`).join('')}
          </div>
        </div>
        <div class="grid2">
          <div class="field"><label>同轨两个片段至少间隔（帧）</label><input type="number" id="tdGap" min="0" max="100" value="${td.gapFrames || 0}"></div>
        </div>
        <label class="check"><input type="checkbox" id="tdBackup" ${td.backup !== false ? 'checked' : ''}><span>执行前复制一条“整理前备份”时间线<small>强烈建议保留；不满意直接切回备份</small></span></label>
        <label class="check"><input type="checkbox" id="tdDelete" ${td.deleteEmpty !== false ? 'checked' : ''}><span>删除整理后空出来的音轨</span></label>
        <label class="check"><input type="checkbox" id="tdDrop" ${td.dropDisabled !== false ? 'checked' : ''}><span>舍弃未启用的音效片段<small>直接删除（不会单独给它们留轨）；取消勾选则原地保留。只影响要整理的轨，对白 / 锁定 / 受保护轨不受影响</small></span></label>
        <div class="note">会搬动的片段会被重新放置，<b>音量、声像、淡入淡出、颜色、启用状态会保留</b>；但片段上的音量关键帧、片段效果器、交叉淡化无法保留。有这类处理的片段，建议把它所在的轨勾为“不要动”。</div>`,
      actions: [{ label: '取消' }, {
        label: '生成方案', primary: true,
        onClick: async (b) => {
          const opts = { mode: b.querySelector('input[name=tdMode]:checked').value, protectTracks: [...b.querySelectorAll('.tdProtect:checked')].map((x) => Number(x.value)), gapFrames: Number($('#tdGap', b).value) || 0, backup: $('#tdBackup', b).checked, deleteEmpty: $('#tdDelete', b).checked, dropDisabled: $('#tdDrop', b).checked };
          closeModal();
          const plan = await run(api.tidyPlan(opts), '正在分析时间线…');
          if (plan) tidyPreviewDialog(plan, opts);
          return true;
        }
      }]
    });
  }

  function tidyPreviewDialog(plan, opts) {
    const fps = plan.fps || 25;
    const tcOf = (f) => clock((f - plan.startFrame) / fps);
    const before = plan.tracksBefore.map((t) => `<tr><td>A${t.index}</td><td class="n">${esc(t.name)}</td><td>${t.clipCount}</td><td>${t.reason ? `<span class="faint">${esc(t.reason)}</span>` : t.movable ? `${t.movable} 个将搬走` : t.clipCount ? '<span class="faint">片段保留原位</span>' : '<span class="faint">空轨</span>'}</td></tr>`).join('');
    const after = plan.newTracks.map((t) => `<tr><td class="n"><b>${esc(t.name)}</b></td><td>${t.clips.length}</td><td class="n" title="${esc(t.clips.map((c) => `${c.name} @${tcOf(c.start)}`).join('\n'))}">${esc(t.clips.slice(0, 4).map((c) => c.name.replace(/\.[^.]+$/, '')).join('、'))}${t.clips.length > 4 ? ` …等 ${t.clips.length} 个` : ''}</td></tr>`).join('');
    const nothing = !plan.moves && !plan.drops;
    modal({
      title: `整理方案 · ${esc(plan.timelineName)}`,
      wide: true,
      body: `
        <div class="note ${nothing ? '' : 'ok'}">${nothing ? '没有可以搬动或删除的片段（都是对白、锁定轨或受保护的轨）。' : `将搬动 <b>${plan.moves}</b> 个片段到 <b>${plan.newTracks.length}</b> 条新轨${plan.drops ? `；<b style="color:var(--err)">删除 ${plan.drops} 个未启用的片段</b>` : ''}；${plan.keep} 个片段原地不动；${plan.willEmpty.length + plan.alreadyEmpty.length} 条空轨${opts.deleteEmpty ? '会被删除' : '保留'}。整理后约 <b>${plan.tracksAfterCount}</b> 条音轨（现在 ${plan.tracksBefore.length} 条）。`}</div>
        ${plan.drops ? `<div class="faint" style="margin-bottom:8px">将删除的未启用片段：${plan.dropList.slice(0, 8).map((d) => `${esc(d.name)}（A${d.track}）`).join('、')}${plan.drops > 8 ? ` …共 ${plan.drops} 个` : ''}</div>` : ''}
        ${plan.keepReasons.length ? `<div class="faint" style="margin-bottom:8px">不动的原因：${plan.keepReasons.map((r) => `${esc(r.reason)} ×${r.count}`).join('；')}</div>` : ''}
        <div class="field"><label>整理后的新音轨</label>
          <table class="clip-table"><thead><tr><th>音轨</th><th>片段</th><th>内容</th></tr></thead><tbody>${after || '<tr><td colspan="3" class="faint">无</td></tr>'}</tbody></table>
        </div>
        <div class="field"><label>现在的音轨</label>
          <table class="clip-table"><thead><tr><th></th><th>名称</th><th>片段</th><th>处理</th></tr></thead><tbody>${before}</tbody></table>
        </div>
        ${plan.immovable.length ? `<div class="faint">无法搬动的片段：${plan.immovable.slice(0, 6).map((x) => `${esc(x.name)}（${esc(x.reason)}）`).join('、')}${plan.immovable.length > 6 ? ' …' : ''}</div>` : ''}
        <div class="faint" style="margin-top:6px">${opts.backup ? '执行前会复制一条“整理前备份”时间线。' : '<span style="color:var(--err)">没有勾选备份：执行后只能靠撤销或重新放置恢复。</span>'}</div>`,
      actions: [
        { label: '返回修改', onClick: () => { closeModal(); tidyDialog(); return true; } },
        { label: '取消' },
        ...(nothing ? [] : [{
          label: `执行整理（搬 ${plan.moves} 个${plan.drops ? `、删 ${plan.drops} 个` : ''}）`, primary: true,
          onClick: async () => {
            closeModal();
            const r = await run(api.tidyApply(opts), '正在整理音轨（备份 → 新建轨 → 搬运 → 清理）…');
            if (!r) return;
            refreshStatus(true);
            const lines = [`已搬动 ${r.moved} 个片段${r.dropped ? `，删除 ${r.dropped} 个未启用的片段` : ''}，新建 ${r.createdTracks.length} 条音轨${r.deletedTracks.length ? `，删除 ${r.deletedTracks.length} 条空轨` : ''}${r.renamed.length ? `，${r.renamed.map((x) => `A${x.index} 改名为「${x.to}」`).join('，')}` : ''}。`];
            if (r.backupTimeline) lines.push(`备份时间线：「${r.backupTimeline}」（不满意可切回去）。`);
            lines.push(`现在的音轨：${r.tracksAfter.map((n, i) => `A${i + 1} ${n}`).join('，')}`);
            if (r.failed.length) lines.push(`<span style="color:var(--err)">${r.failed.length} 个没有搬成：${r.failed.map((f) => `${esc(f.name)}（${esc(f.reason)}）`).join('、')}</span>`);
            modal({ title: r.failed.length ? '整理完成（有未搬动的片段）' : '整理完成', body: lines.map((l) => `<p style="margin:0 0 8px">${l}</p>`).join(''), actions: [{ label: '知道了', primary: true }] });
          }
        }])
      ]
    });
  }

  function stacksDialog() {
    const stacks = S.library.stacks || [];
    const selN = S.sel.size;
    const rows = stacks
      .map((k) => `
        <div class="section" style="padding:10px;margin-bottom:8px">
          <div style="display:flex;gap:8px;align-items:center">
            <div style="flex:1;min-width:0">
              <div class="tpl-name" title="${esc(k.note || '')}">${esc(k.name)}</div>
              <div class="faint">${k.layers.length} 层：${k.layers.map((l) => `${esc(l.name)}${l.offsetMs ? `（${l.offsetMs > 0 ? '+' : ''}${l.offsetMs}ms）` : ''}`).join(' + ')}${k.useCount ? ` · 用过 ${k.useCount} 次` : ''}${k.layers.some((l) => l.missing) ? ' · <span style="color:var(--err)">有一层文件缺失</span>' : ''}</div>
            </div>
            <button class="btn small primary" data-sp="${k.id}" title="整套放到播放头位置，各层按自己的分类进固定音轨">放到播放头</button>
            <button class="btn small" data-se="${k.id}">编辑</button>
            <button class="btn small danger" data-sd="${k.id}">删除</button>
          </div>
        </div>`)
      .join('');
    modal({
      title: '音效套餐',
      wide: true,
      body: `
        <div class="note info">套餐 = 几个音效叠在一起用，比如「重转场 = 嗖 + 砰 + 低频」。每层可以设相对偏移、对齐方式、额外增益；放置时各层按自己的分类去固定音轨，互不覆盖。</div>
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px">
          <button class="btn small primary" id="skNew" ${selN ? '' : 'disabled'}>用已勾选的 ${selN} 个音效新建套餐</button>
          <span class="faint">${selN ? '' : '先在列表里勾选 2～4 个音效，再打开这里'}</span>
        </div>
        ${rows || '<div class="empty">还没有套餐</div>'}`,
      actions: [{ label: '关闭' }],
      onMount: (b) => {
        $('#skNew', b).onclick = () => {
          const layers = [...S.sel].map((id) => ({ soundId: id, offsetMs: 0, align: 'auto', gainDb: 0 }));
          closeModal();
          stackEditDialog({ name: '', note: '', layers });
        };
        b.querySelectorAll('[data-sp]').forEach((btn) => { btn.onclick = () => { closeModal(); placeStack(btn.dataset.sp); }; });
        b.querySelectorAll('[data-se]').forEach((btn) => { btn.onclick = () => { const k = stacks.find((x) => x.id === btn.dataset.se); closeModal(); stackEditDialog({ id: k.id, name: k.name, note: k.note, layers: k.layers.map((l) => ({ soundId: l.soundId, offsetMs: l.offsetMs, align: l.align, gainDb: l.gainDb })) }); }; });
        b.querySelectorAll('[data-sd]').forEach((btn) => {
          btn.onclick = async () => {
            const k = stacks.find((x) => x.id === btn.dataset.sd);
            closeModal();
            if (await confirmBox('删除套餐', `<p>删除套餐「${esc(k.name)}」？不会删除里面的音效。</p>`, '删除', true)) applyState(await run(api.deleteStack(k.id)));
            stacksDialog();
          };
        });
      }
    });
  }

  function stackEditDialog(k) {
    const layers = k.layers.map((l) => ({ ...l }));
    const renderRows = (b) => {
      const body = $('#skLayers', b);
      body.innerHTML = layers.length
        ? layers.map((l, i) => {
          const snd = S.library.sounds.find((x) => x.id === l.soundId);
          return `<tr data-i="${i}">
            <td class="n" title="${esc(snd?.absPath || '')}">${esc(snd?.name || '（已移除的音效）')}<div class="faint">${esc(snd?.category || '')}</div></td>
            <td><input type="number" data-k="offsetMs" step="10" value="${l.offsetMs}" style="width:84px">${l.durationSec ? `<div class="faint" title="从时间线保存时的裁切">裁切 ${l.inSec}s + ${l.durationSec}s</div>` : ''}${l.fadeInMs || l.fadeOutMs ? `<div class="faint">淡入出 ${l.fadeInMs}/${l.fadeOutMs}ms</div>` : ''}</td>
            <td><select data-k="align" style="width:auto">${alignOptions(l.align || 'auto')}</select></td>
            <td><input type="number" data-k="gainDb" step="0.5" min="-24" max="12" value="${l.gainDb}" style="width:70px"></td>
            <td style="white-space:nowrap"><button class="icon-btn" data-up="${i}" title="上移" ${i ? '' : 'disabled'}>▲</button><button class="icon-btn" data-rm="${i}" title="移除这一层">${ICON.close}</button></td>
          </tr>`;
        }).join('')
        : '<tr><td colspan="5" class="faint">还没有层，用下面的按钮把勾选的音效加进来</td></tr>';
      body.querySelectorAll('[data-k]').forEach((inp) => {
        inp.onchange = () => {
          const i = Number(inp.closest('tr').dataset.i);
          layers[i][inp.dataset.k] = inp.dataset.k === 'align' ? inp.value : Number(inp.value) || 0;
        };
      });
      body.querySelectorAll('[data-up]').forEach((btn) => { btn.onclick = () => { const i = Number(btn.dataset.up); [layers[i - 1], layers[i]] = [layers[i], layers[i - 1]]; renderRows(b); }; });
      body.querySelectorAll('[data-rm]').forEach((btn) => { btn.onclick = () => { layers.splice(Number(btn.dataset.rm), 1); renderRows(b); }; });
    };
    modal({
      title: k.id ? `编辑套餐：${k.name}` : '新建音效套餐',
      wide: true,
      body: `
        <div class="field"><label>套餐名称</label><input type="text" id="skName" value="${esc(k.name || '')}" placeholder="例如：重转场（嗖 + 砰 + 低频）"></div>
        <table class="clip-table"><thead><tr><th>音效（按顺序）</th><th>偏移(毫秒)</th><th>对齐</th><th>增益(dB)</th><th></th></tr></thead><tbody id="skLayers"></tbody></table>
        <div style="display:flex;gap:6px;margin-top:8px;align-items:center">
          <button class="btn small" id="skAddSel" ${S.sel.size ? '' : 'disabled'}>把已勾选的 ${S.sel.size} 个加为新层</button>
          <span class="faint">${S.sel.size ? '' : '关闭后在列表里勾选音效，再回来编辑即可添加'}</span>
        </div>
        <div class="field" style="margin-top:8px"><label>备注（可选）</label><input type="text" id="skNote" value="${esc(k.note || '')}" placeholder="适合什么场景"></div>
        <div class="faint">偏移：相对放置点，正数靠后、负数靠前（毫秒）。对齐「分类默认」= 用该音效分类设定的对齐方式。增益是在响度自动调整之后再加减。</div>`,
      actions: [
        { label: '取消', onClick: () => { closeModal(); stacksDialog(); } },
        {
          label: '保存',
          primary: true,
          onClick: async (b) => {
            const name = $('#skName', b).value.trim();
            if (!name) { toast('请填写套餐名称', 'err'); return true; }
            if (!layers.length) { toast('套餐至少要有一层音效', 'err'); return true; }
            const payload = { name, note: $('#skNote', b).value.trim(), layers: layers.map(({ soundId, offsetMs, align, gainDb, inSec, durationSec, fadeInMs, fadeOutMs, pan }) => ({ soundId, offsetMs, align, gainDb, inSec, durationSec, fadeInMs, fadeOutMs, pan })) };
            const st = await run(k.id ? api.updateStack(k.id, payload) : api.addStack(payload));
            if (!st) return true;
            applyState(st);
            toast(k.id ? '套餐已更新' : `已新建套餐「${name}」`, 'ok');
            closeModal();
            stacksDialog();
          }
        }
      ],
      onMount: (b) => {
        renderRows(b);
        $('#skAddSel', b).onclick = () => {
          for (const id of S.sel) if (!layers.some((l) => l.soundId === id)) layers.push({ soundId: id, offsetMs: 0, align: 'auto', gainDb: 0 });
          renderRows(b);
        };
      }
    });
  }

  async function placeStack(id) {
    const k = (S.library.stacks || []).find((x) => x.id === id);
    if (!k) return;
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    await ensureMeasured(k.layers.map((l) => S.library.sounds.find((x) => x.id === l.soundId)).filter(Boolean));
    const r = await run(api.placeStack(id, 'playhead'), `正在放置套餐「${k.name}」…`);
    if (!r) return;
    applyState(r.state);
    refreshStatus(true);
    const head = `套餐「${k.name}」已放置 ${r.placed} / ${r.total} 层${r.createdTracks ? `（新建 ${r.createdTracks} 条音轨）` : ''}：${(r.results || []).map((x) => `${x.name} → A${x.trackIndex}${x.trackName ? ` ${x.trackName}` : ''}`).join('，')}`;
    if (!r.failed?.length) return toast(head, 'ok');
    modal({ title: '套餐放置结果', body: `<p style="margin:0 0 8px">${esc(head)}</p><p style="margin:0 0 6px;color:var(--err)">没放上去的层：</p><ul style="margin:0;padding-left:18px">${r.failed.map((f) => `<li>${esc(f.name)}：${esc(f.error)}</li>`).join('')}</ul>`, actions: [{ label: '知道了', primary: true }] });
  }

  // ---------- 条件筛选（v1.4.0） ----------

  function filtersDialog() {
    const f = S.filters;
    const opt = (name, value, list) => `<select id="${name}">${list.map(([v, l]) => `<option value="${v}" ${value === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    modal({
      title: '筛选条件',
      body: `
        <div class="grid2">
          <div class="field"><label>时长</label>${opt('fDur', f.duration, [['', '不限'], ['short', '短于 1 秒'], ['medium', '1 ~ 5 秒'], ['long', '5 ~ 30 秒'], ['xlong', '30 秒以上']])}</div>
          <div class="field"><label>声道</label>${opt('fCh', f.channels, [['', '不限'], ['1', '单声道'], ['2+', '双声道 / 多声道']])}</div>
          <div class="field"><label>采样率</label>${opt('fRate', f.rate, [['', '不限'], ['48k', '48 kHz（工程标准）'], ['other', '非 48 kHz（需注意）']])}</div>
          <div class="field"><label>响度</label>${opt('fLoud', f.loud, [['', '不限'], ['quiet', '安静（< -24 LUFS）'], ['mid', '中等（-24 ~ -14）'], ['loud', '响（> -14 LUFS）']])}</div>
        </div>
        <div class="faint">声道、采样率、响度来自后台分析，还没分析完的条目会被这些条件过滤掉。搜索词支持中英同义词：搜“转场”也能找到 whoosh / swoosh。</div>`,
      actions: [
        { label: '清除', onClick: () => { S.filters = { duration: '', channels: '', rate: '', loud: '' }; renderSounds(); } },
        { label: '应用', primary: true, onClick: (b) => { S.filters = { duration: $('#fDur', b).value, channels: $('#fCh', b).value, rate: $('#fRate', b).value, loud: $('#fLoud', b).value }; renderSounds(); } }
      ]
    });
  }

  // ---------- 素材包（v1.4.0） ----------

  async function newCollectionDialog(ids) {
    const name = await prompt(`新建素材包${ids.length ? `（放入已勾选的 ${ids.length} 个）` : ''}`, '素材包名称，例如：综艺常用包 / 恐怖片包');
    if (!name) return;
    const st = await run(api.addCollection(name, ids, ''));
    if (!st) return;
    applyState(st);
    const c = (S.library.collections || []).find((x) => x.name === name);
    if (c) { S.cat = `__coll:${c.id}`; S.sel.clear(); renderSounds(); }
    toast(`已新建素材包「${name}」${ids.length ? `，放入 ${ids.length} 个` : ''}`, 'ok');
  }

  function collectionPicker(ids) {
    const colls = S.library.collections || [];
    if (!colls.length) return newCollectionDialog(ids);
    modal({
      title: `加入素材包（${ids.length} 个）`,
      body: `<div class="radio-group">${colls.map((c, i) => `<label class="check"><input type="radio" name="cp" value="${c.id}" ${i ? '' : 'checked'}><span>${esc(c.name)}<small>${c.soundIds.length} 个${c.note ? ` · ${esc(c.note)}` : ''}</small></span></label>`).join('')}</div>`,
      actions: [
        { label: '新建素材包…', onClick: () => { closeModal(); newCollectionDialog(ids); return true; } },
        { label: '取消' },
        {
          label: '加入', primary: true,
          onClick: async (b) => {
            const id = b.querySelector('input[name=cp]:checked')?.value;
            const c = colls.find((x) => x.id === id);
            if (!c) return true;
            const st = await run(api.updateCollection(c.id, { add: ids }));
            if (st) { applyState(st); toast(`已加入素材包「${c.name}」`, 'ok'); }
          }
        }
      ]
    });
  }

  function collectionRenameDialog(c) {
    modal({
      title: '素材包',
      body: `<div class="field"><label>名称</label><input type="text" id="cName" value="${esc(c.name)}"></div><div class="field"><label>备注</label><input type="text" id="cNote" value="${esc(c.note || '')}" placeholder="什么时候用这一包"></div>`,
      actions: [{ label: '取消' }, { label: '保存', primary: true, onClick: async (b) => { const st = await run(api.updateCollection(c.id, { name: $('#cName', b).value, note: $('#cNote', b).value })); if (st) applyState(st); } }]
    });
  }

  // ---------- 时间线试听（v1.4.0） ----------

  let auditionTimer = null;
  async function auditionStart(s) {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    if (!s || !s.exists) return toast('先在列表里选中一个要试听的音效（点一下这一行）', 'err');
    await ensureMeasured([s]);
    const r = await run(api.auditionPlace(s.id, { align: S.settings.placeAlign || 'auto' }), '正在放到试听轨…');
    if (!r) return;
    S.audition = { soundId: s.id, trackIndex: r.trackIndex, anchorFrame: r.anchorFrame };
    S.focusId = s.id;
    renderSounds();
    refreshStatus(true);
    toast(`「${s.name}」已放到 A${r.trackIndex}「试听」轨。到达芬奇里按空格听；回到面板按 ↑↓ 换一个，Enter 确认，Esc 取消`, 'ok');
  }
  function auditionSwapLater(s) {
    clearTimeout(auditionTimer);
    auditionTimer = setTimeout(async () => {
      if (!S.audition || !s || !s.exists) return;
      await ensureMeasured([s]);
      const r = await run(api.auditionPlace(s.id, { align: S.settings.placeAlign || 'auto' }));
      if (!r) return;
      S.audition = { soundId: s.id, trackIndex: r.trackIndex, anchorFrame: r.anchorFrame };
      renderSounds();
    }, 300);
  }
  async function auditionConfirm() {
    if (!S.audition) return;
    const r = await run(api.auditionConfirm({ align: S.settings.placeAlign || 'auto' }), '正在正式放置…');
    S.audition = null;
    if (r) {
      applyState(r.state);
      toast(`已放到 A${r.trackIndex}${r.trackName ? ` ${r.trackName}` : ''}${r.createdTrack ? '（新建）' : ''}，${r.alignLabel}`, 'ok');
    } else renderSounds();
    refreshStatus(true);
  }
  async function auditionCancel(silent) {
    if (!S.audition) return;
    S.audition = null;
    await run(api.auditionCancel());
    renderSounds();
    if (!silent) toast('已取消试听，试听轨上的片段已移除');
  }

  // ---------- 氛围铺底（v1.4.0） ----------

  function ambienceDialog(preset) {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    const amb = S.settings.ambience || { crossfadeMs: 1500, fadeInMs: 500, fadeOutMs: 1000 };
    const cands = S.library.sounds.filter((x) => kindOf(x) === 'sfx' && x.exists && (x.duration == null || x.duration >= 1.5));
    const focus = preset || S.library.sounds.find((x) => x.id === S.focusId) || cands.find((x) => x.category === '氛围') || cands[0];
    if (!cands.length) return toast('库里还没有可用的音效', 'err');
    const byCat = {};
    for (const x of cands) (byCat[x.category] ||= []).push(x);
    const order = Object.keys(byCat).sort((a, b) => (a === '氛围' ? -1 : b === '氛围' ? 1 : a.localeCompare(b, 'zh-CN')));
    modal({
      title: '氛围铺底',
      wide: true,
      body: `
        <div class="field"><label>用哪个环境声</label><select id="amSound">${order.map((c) => `<optgroup label="${esc(c)}">${byCat[c].map((x) => `<option value="${x.id}" ${focus && x.id === focus.id ? 'selected' : ''}>${esc(x.name)}${x.duration ? `（${clock(x.duration)}）` : ''}</option>`).join('')}</optgroup>`).join('')}</select></div>
        <div class="field"><label>铺哪一段</label><div class="radio-group">
          <label class="check"><input type="radio" name="amRange" value="auto" checked><span>自动<small>设置了入点/出点就铺入出点之间；否则从播放头铺到时间线最后一个片段结束</small></span></label>
          <label class="check"><input type="radio" name="amRange" value="secs"><span>从播放头开始铺 <input type="number" id="amSecs" value="60" min="1" step="5" style="width:80px;margin:0 4px"> 秒</span></label>
        </div></div>
        <div class="grid2">
          <div class="field"><label>接缝交叉淡化（毫秒）</label><input type="number" id="amXf" min="0" step="100" value="${amb.crossfadeMs}"></div>
          <div class="field"><label>开头淡入（毫秒）</label><input type="number" id="amIn" min="0" step="100" value="${amb.fadeInMs}"></div>
          <div class="field"><label>结尾淡出（毫秒）</label><input type="number" id="amOut" min="0" step="100" value="${amb.fadeOutMs}"></div>
        </div>
        <div class="note info">做法：同一个环境声一段接一段放，相邻两段重叠“交叉淡化”这么长，交替放在「BG 氛围」和「BG 氛围 2」两条轨上（名字按分类设置），听不出循环接缝。音量按响度设置自动调整。</div>`,
      actions: [
        { label: '取消' },
        {
          label: '开始铺底', primary: true,
          onClick: async (b) => {
            const id = $('#amSound', b).value;
            const snd = S.library.sounds.find((x) => x.id === id);
            const opts = { crossfadeMs: Number($('#amXf', b).value), fadeInMs: Number($('#amIn', b).value), fadeOutMs: Number($('#amOut', b).value) };
            if (b.querySelector('input[name=amRange]:checked').value === 'secs') opts.seconds = Math.max(1, Number($('#amSecs', b).value) || 60);
            closeModal();
            if (snd) await ensureMeasured([snd]);
            const r = await run(api.fillAmbience(id, opts), '正在铺底…');
            if (!r) return;
            applyState(r.state);
            refreshStatus(true);
            const secs = Math.round((r.end - r.start) / r.fps);
            toast(`已铺 ${secs} 秒：${r.segments} 段放在 ${r.trackNames.join(' / ')}${r.createdTracks ? `（新建 ${r.createdTracks} 条轨）` : ''}，接缝交叉淡化 ${Math.round((r.crossfadeFrames / r.fps) * 1000)} 毫秒${r.failed.length ? `；${r.failed.length} 段没放上` : ''}`, r.failed.length ? 'err' : 'ok');
          }
        }
      ]
    });
  }

  // ---------- 音频使用清单（v1.4.0） ----------

  function cueSheetDialog() {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    modal({
      title: '导出音频使用清单',
      body: `<div class="radio-group">
          <label class="check"><input type="radio" name="csScope" value="music" checked><span>音乐清单<small>库里的音乐 + 时间线上不在库里的音频（防止漏掉外来的配乐）</small></span></label>
          <label class="check"><input type="radio" name="csScope" value="all"><span>全部音频<small>时间线上每一条音频片段</small></span></label>
        </div>
        <div class="faint">导出为 CSV 表格（Excel / WPS 可直接打开）：轨道、片段名、入点、出点、时长、类型、库内名称、分类、来源、授权、BPM、调性、情绪、音量、文件路径。</div>`,
      actions: [{ label: '取消' }, {
        label: '选择保存位置并导出', primary: true,
        onClick: async (b) => {
          const scope = b.querySelector('input[name=csScope]:checked').value;
          closeModal();
          const r = await run(api.exportCueSheet({ scope }), '正在扫描时间线…');
          if (r) toast(`已导出 ${r.rows} 条（时间线共 ${r.total} 个音频片段）：${r.file}`, 'ok');
        }
      }]
    });
  }

  // ---------- 一键建立标准音轨（v1.4.0） ----------

  function standardTracksDialog() {
    if (!S.status.connected || !S.status.timeline) return toast('请先在达芬奇里打开时间线', 'err');
    const existing = new Set((S.status.timeline.tracks || []).map((t) => String(t.name || '').trim()));
    const names = ['对白'];
    for (const c of S.library.categories) if (c.trackName && !names.includes(c.trackName)) names.push(c.trackName);
    modal({
      title: '一键建立标准音轨',
      body: `<div class="faint" style="margin-bottom:8px">按分类设置里的音轨名建立空轨（已存在的会跳过）。顺序：对白 → 音效 → 音乐。</div>
        ${names.map((n) => `<label class="check"><input type="checkbox" class="stdT" value="${esc(n)}" ${existing.has(n) ? 'disabled' : 'checked'}><span>${esc(n)}${existing.has(n) ? '<small>已存在</small>' : ''}</span></label>`).join('')}`,
      actions: [{ label: '取消' }, {
        label: '建立', primary: true,
        onClick: async (b) => {
          const picked = [...b.querySelectorAll('.stdT:checked')].map((x) => x.value);
          if (!picked.length) { toast('没有需要新建的音轨'); return; }
          closeModal();
          const r = await run(api.createStandardTracks(picked), '正在建立音轨…');
          if (!r) return;
          refreshStatus(true);
          toast(`已新建 ${r.created.length} 条音轨：${r.created.map((x) => `A${x.trackIndex} ${x.name}`).join('、')}${r.skipped.length ? `；已存在 ${r.skipped.length} 条` : ''}`, 'ok');
        }
      }]
    });
  }

  // ---------- 库健康检查（v1.4.0） ----------

  async function healthDialog() {
    const h = await run(api.libraryHealth(), '正在检查音效库…');
    if (!h) return;
    const li = (arr, f) => (arr.length ? `<ul style="margin:4px 0 0;padding-left:18px">${arr.slice(0, 30).map(f).join('')}${arr.length > 30 ? `<li class="faint">…还有 ${arr.length - 30} 个</li>` : ''}</ul>` : '<div class="faint">无</div>');
    modal({
      title: `库健康检查（共 ${h.total} 条）`,
      wide: true,
      body: `
        <div class="field"><label>文件丢失（${h.missing.length}）</label>${li(h.missing, (x) => `<li>${esc(x.name)} <span class="faint">${esc(x.file)}</span></li>`)}</div>
        <div class="field"><label>疑似重复：大小和时长相同（${h.duplicates.length} 组）</label>${li(h.duplicates, (g) => `<li>${g.map((x) => `${esc(x.name)}（${esc(x.category)}）`).join(' = ')}</li>`)}</div>
        <div class="field"><label>非 48 kHz（${h.nonStandardRate.length}）<small class="faint"> 放进 48k 工程会被重采样，一般没问题，但建议统一</small></label>${li(h.nonStandardRate, (x) => `<li>${esc(x.name)} · ${x.sampleRate / 1000} kHz</li>`)}</div>
        <div class="field"><label>静音 / 无法测量（${h.silent.length}）</label>${li(h.silent, (x) => `<li>${esc(x.name)}</li>`)}</div>
        <div class="field"><label>空分类（${h.emptyCategories.length}）</label>${li(h.emptyCategories, (x) => `<li>${esc(x.name)}（${x.kind === 'music' ? '音乐' : '音效'}）</li>`)}</div>
        ${h.unmeasured ? `<div class="faint">还有 ${h.unmeasured} 条没分析过（打开音效库页会在后台自动分析）。</div>` : ''}`,
      actions: [
        { label: '关闭' },
        ...(h.missing.length ? [{ label: `移除 ${h.missing.length} 条丢失的记录`, danger: true, onClick: async () => { const r = await run(api.removeMissing(), '正在清理…'); if (r) { applyState(r.state); toast(`已移除 ${r.removed} 条`, 'ok'); } } }] : [])
      ]
    });
  }

  // ---------- 主题（v1.4.0） ----------

  const mqLight = window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;
  function applyTheme() {
    const t = S.settings.theme || 'dark';
    const eff = t === 'system' ? (mqLight && mqLight.matches ? 'light' : 'dark') : t;
    document.documentElement.dataset.theme = eff;
  }
  if (mqLight) mqLight.addEventListener('change', () => { if ((S.settings.theme || 'dark') === 'system') applyTheme(); });

  // ---------- 检查更新（v1.5.0） ----------

  const UPD = { info: null, result: null, downloading: false, progress: null };

  function updateBanner(result) {
    const el = document.getElementById('updateBanner');
    if (!el) return;
    const r = result || UPD.result;
    const show = r && r.status === 'available' && r.isNewer && !r.skipped && r.info;
    if (!show) { el.hidden = true; el.innerHTML = ''; return; }
    const v = r.info;
    const prog = UPD.downloading && UPD.progress ? (UPD.progress.total ? ` ${Math.round((UPD.progress.got / UPD.progress.total) * 100)}%` : ` ${Math.round(UPD.progress.got / 1024)} KB`) : '';
    el.innerHTML = `
      <span class="ub-dot"></span>
      <span class="ub-text"><b>有新版本 ${esc(v.version)}</b>${v.releasedAt ? ` · ${esc(v.releasedAt)}` : ''}${v.notes && v.notes.length ? ` · ${esc(v.notes[0])}` : ''}</span>
      <button class="btn small ghost" data-act="upd-notes">更新内容</button>
      ${v.downloadUrl ? `<button class="btn small primary" data-act="upd-download" ${UPD.downloading ? 'disabled' : ''}>${UPD.downloading ? `下载中${prog}` : '下载'}</button>` : (v.pageUrl ? '<button class="btn small primary" data-act="upd-page">前往下载</button>' : '')}
      <button class="icon-btn" data-act="upd-skip" title="跳过这个版本，不再提示">${ICON.close}</button>`;
    el.hidden = false;
  }

  function updateNotesDialog() {
    const r = UPD.result;
    const v = r && r.info;
    if (!v) return;
    modal({
      title: `${esc(v.name || '音效轨道库')} ${esc(v.version)} 更新内容`,
      body: `
        <div class="faint" style="margin-bottom:8px">当前 ${esc(UPD.info?.currentVersion || '')} → 新版 ${esc(v.version)}${v.releasedAt ? ` · 发布于 ${esc(v.releasedAt)}` : ''}${v.minResolve ? ` · 需要达芬奇 ${esc(v.minResolve)}+` : ''}${v.size ? ` · ${Math.round(v.size / 1024)} KB` : ''}</div>
        ${v.notes && v.notes.length ? `<ul style="margin:0;padding-left:18px;line-height:1.8">${v.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : '<div class="faint">这个版本没有附带要点说明。</div>'}
        <div class="note info" style="margin-top:12px">下载的安装包会保存到「下载」文件夹并核对 SHA256；之后关闭达芬奇，解压并双击 Install.bat 即可升级，音效库和设置都会保留。</div>`,
      actions: [
        { label: '跳过此版本', onClick: () => skipUpdate(v.version) },
        ...(v.notesUrl || v.pageUrl ? [{ label: '打开网页', onClick: () => { api.openUpdatePage('notes'); return true; } }] : []),
        { label: '关闭' },
        ...(v.downloadUrl ? [{ label: '下载', primary: true, onClick: () => downloadUpdate() }] : [])
      ]
    });
  }

  async function skipUpdate(version) {
    const r = await run(api.skipUpdate(version));
    if (r) { if (UPD.result) UPD.result.skipped = true; updateBanner(); toast(`已跳过 ${version}，下次有更新时再提示`); }
  }

  async function downloadUpdate() {
    if (UPD.downloading) return;
    UPD.downloading = true; UPD.progress = { got: 0, total: UPD.result?.info?.size || 0 };
    updateBanner();
    const r = await run(api.downloadUpdate());
    UPD.downloading = false; UPD.progress = null;
    updateBanner();
    if (r) {
      modal({
        title: '下载完成',
        body: `<p style="margin:0 0 8px">安装包已保存${r.verified ? '，<b>SHA256 校验通过</b>' : ''}：</p><div class="path-box"><div class="path">${esc(r.file)}</div></div>
          <ol style="margin:12px 0 0;padding-left:20px;line-height:1.8"><li>关闭达芬奇</li><li>解压这个 zip，双击里面的 <b>Install.bat</b></li><li>重新打开达芬奇即可，音效库和设置都会保留</li></ol>`,
        actions: [{ label: '知道了', primary: true }]
      });
    }
  }

  async function checkUpdateNow() {
    const r = await run(api.checkUpdate(), '正在检查更新…');
    if (!r) return;
    UPD.result = r;
    updateBanner();
    if (S.tab === 'settings') renderSettings();
    if (r.status === 'available' && r.isNewer) toast(r.skipped ? `有新版本 ${r.info.version}（你之前选择了跳过）` : `发现新版本 ${r.info.version}`, 'ok');
    else if (r.status === 'latest') toast(`已是最新版本 ${r.currentVersion}`, 'ok');
    else if (r.status === 'unconfigured') toast('没有设置更新源地址，请在下方填写或使用安装包自带的地址', 'err');
    else toast(`检查更新失败：${r.message || '未知错误'}`, 'err');
  }

  function updateSectionHtml() {
    const u = UPD.info || {};
    const su = S.settings.update || { auto: true, url: '', skippedVersion: '', lastCheckedAt: null, lastResult: null };
    const last = UPD.result || su.lastResult;
    const effective = (su.url || (u.builtin && u.builtin.url) || '');
    let lastTxt = '还没有检查过';
    if (last) {
      const when = last.checkedAt ? new Date(last.checkedAt).toLocaleString('zh-CN', { hour12: false }) : '';
      if (last.status === 'available') lastTxt = `${when} · 有新版本 <b>${esc(last.info.version)}</b>${last.skipped ? '（已跳过）' : ''}`;
      else if (last.status === 'latest') lastTxt = `${when} · 已是最新`;
      else if (last.status === 'unconfigured') lastTxt = `${when} · 没有更新源地址`;
      else lastTxt = `${when} · <span style="color:var(--err)">失败：${esc(last.message || '')}</span>`;
    }
    return `
      <div class="section">
        <div class="section-head"><h2>更新</h2><span class="muted">当前版本 ${esc(u.currentVersion || '')}</span></div>
        <label class="check"><input type="checkbox" data-set-update="auto" ${su.auto ? 'checked' : ''}><span>自动检查更新<small>打开面板时静默检查一次，每天最多一次；只请求一个 version.json，不上传任何数据</small></span></label>
        <div class="field" style="margin-top:8px"><label>更新源地址（留空 = 使用安装包自带的地址${u.builtin && u.builtin.url ? '' : '；当前安装包没有自带地址'}）</label><input type="text" id="updUrl" value="${esc(su.url)}" placeholder="${esc((u.builtin && u.builtin.url) || 'https://…/version.json')}"></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
          <button class="btn small primary" data-act="upd-check" ${effective ? '' : 'disabled'}>立即检查</button>
          ${last && last.status === 'available' && last.info ? `<button class="btn small" data-act="upd-notes">查看 ${esc(last.info.version)} 更新内容</button>` : ''}
          ${su.skippedVersion ? `<button class="btn small ghost" data-act="upd-unskip" title="取消跳过 ${esc(su.skippedVersion)}">取消跳过 ${esc(su.skippedVersion)}</button>` : ''}
          ${u.builtin && u.builtin.pageUrl ? '<button class="btn small ghost" data-act="upd-page">打开下载页</button>' : ''}
        </div>
        <div class="hint">上次检查：${lastTxt}${effective ? `<br>检查地址：${esc(effective)}` : ''}</div>
      </div>`;
  }

  // ---------- 设置页 ----------

  function renderSettings() {
    const page = $('#tab-settings');
    const st = S.settings;
    const pa = st.placeAudio || { normalize: true, targetLufs: { sfx: -18, music: -20 }, fadeIn: { sfx: 0, music: 500 }, fadeOut: { sfx: 0, music: 1500 } };
    const rs = S.status;
    const f = rs.features || {};
    const feat = (ok, text) => `<span class="${ok ? 'feature-ok' : 'feature-no'}">${ok ? '✓' : '✗'} ${text}</span>`;
    page.innerHTML = `
      <div class="section">
        <div class="section-head"><h2>音效库位置</h2></div>
        <div class="field">
          <div class="path-box"><div class="path">${esc(S.library.root)}</div></div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn small" data-act="lib-open">打开文件夹</button>
          <button class="btn small" data-act="lib-choose">更换 / 打开其他库…</button>
        </div>
        <div class="hint">音效库是电脑上的一个普通文件夹，不属于任何项目，所以新建项目、切换项目都能直接用。<br>把它放到网盘/NAS 同步目录，多台电脑就能共用同一个库。</div>
      </div>

      <div class="section">
        <div class="section-head"><h2>导入 / 导出</h2></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn small" data-act="lib-export">导出整个音效库…</button>
          <button class="btn small" data-act="lib-import">导入并合并其他音效库…</button>
          <button class="btn small primary" data-act="sync-pool">导入到当前项目媒体池</button>
        </div>
        <div class="hint">导出会把音效、模板和分类复制成一个文件夹，拷到别的电脑后用「导入并合并」即可。<br>「导入到当前项目媒体池」会在媒体池建立「${esc(st.poolRootName)} › 音效 / 音乐 › 各分类」文件夹，已导入过的不会重复。</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:10px"><button class="btn small" data-act="health">库健康检查…</button></div>
        <div class="hint">检查丢失的文件、疑似重复、非 48 kHz、静音文件和空分类。</div>
      </div>

      <div class="section">
        <div class="section-head"><h2>选项</h2></div>
        <div class="field"><label>媒体池里的根文件夹名称</label><input type="text" id="setPool" value="${esc(st.poolRootName)}" style="width:100%"></div>
        <label class="check"><input type="checkbox" data-set="copyFiles" ${st.copyFiles ? 'checked' : ''}><span>添加音效时复制文件到音效库<small>推荐。关闭后只记录原始路径，原文件移动后会失效</small></span></label>
        <label class="check"><input type="checkbox" data-set="learnOnMove" ${st.learnOnMove ? 'checked' : ''}><span>手动调整分类时学习我的习惯<small>记住文件名特征，以后自动归类更准</small></span></label>
        <label class="check"><input type="checkbox" data-set="autoSaveBeforeApply" ${st.autoSaveBeforeApply ? 'checked' : ''}><span>应用模板前自动保存项目</span></label>
        <label class="check"><input type="checkbox" data-set="alwaysOnTop" ${st.alwaysOnTop ? 'checked' : ''}><span>面板窗口置顶<small>让面板一直浮在达芬奇上面，像内置面板一样使用；位置和大小会记住</small></span></label>
        <div class="field" style="margin-top:10px"><label>外观</label>
          <select id="setTheme" style="width:100%">
            <option value="dark" ${(st.theme || 'dark') === 'dark' ? 'selected' : ''}>深色（和达芬奇一致）</option>
            <option value="light" ${st.theme === 'light' ? 'selected' : ''}>浅色</option>
            <option value="system" ${st.theme === 'system' ? 'selected' : ''}>跟随系统</option>
          </select>
        </div>
        <div class="field" style="margin-top:10px"><label>点 ⤓ / 按 Enter 放置时放到哪条音轨</label>
          <select id="setTarget" style="width:100%">
            <option value="route" ${!st.soundTarget || st.soundTarget === 'route' ? 'selected' : ''}>按分类固定轨（推荐：转场进 FX 转场、打击进 FX 打击…，位置被占自动用下一条同名轨）</option>
            <option value="new" ${st.soundTarget === 'new' ? 'selected' : ''}>每次新建一条音轨</option>
            ${st.soundTarget && st.soundTarget !== 'route' && st.soundTarget !== 'new' ? `<option value="${esc(String(st.soundTarget))}" selected>指定音轨 A${esc(String(st.soundTarget))}（在音效库页顶部选择）</option>` : ''}
          </select>
          <div class="faint">每个分类对应的音轨名、默认对齐方式（开头 / 最响点 / 结尾）在「管理分类、音轨与关键词」里修改。</div>
        </div>
        <div class="field" style="margin-top:10px"><label>应用模板时默认开始位置</label>
          <select id="setPos" style="width:100%">
            <option value="original" ${st.defaultPosition === 'original' ? 'selected' : ''}>与原时间线相同的位置</option>
            <option value="playhead" ${st.defaultPosition === 'playhead' ? 'selected' : ''}>当前播放头</option>
            <option value="start" ${st.defaultPosition === 'start' ? 'selected' : ''}>时间线开头</option>
          </select>
        </div>
      </div>

      <div class="section">
        <div class="section-head"><h2>放入时间线的音频</h2></div>
        <label class="check"><input type="checkbox" id="paNorm" ${pa.normalize ? 'checked' : ''}><span>放入时按响度自动调整音量<small>根据每条音效测得的响度计算增益，让它接近目标值；峰值不会超过 -1 dBFS</small></span></label>
        <div class="grid2">
          <div class="field"><label>音效目标响度（LUFS）</label><input type="number" id="paTSfx" step="0.5" value="${pa.targetLufs.sfx}"></div>
          <div class="field"><label>音乐目标响度（LUFS）</label><input type="number" id="paTMusic" step="0.5" value="${pa.targetLufs.music}"></div>
          <div class="field"><label>音效淡入（毫秒）</label><input type="number" id="paInSfx" min="0" step="50" value="${pa.fadeIn.sfx}"></div>
          <div class="field"><label>音效淡出（毫秒）</label><input type="number" id="paOutSfx" min="0" step="50" value="${pa.fadeOut.sfx}"></div>
          <div class="field"><label>音乐淡入（毫秒）</label><input type="number" id="paInMusic" min="0" step="50" value="${pa.fadeIn.music}"></div>
          <div class="field"><label>音乐淡出（毫秒）</label><input type="number" id="paOutMusic" min="0" step="50" value="${pa.fadeOut.music}"></div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
          <button class="btn small primary" data-act="pa-save">保存放入设置</button>
          <select id="paPreset" style="width:auto" title="按交付平台快速填入目标响度">
            <option value="">按平台填入目标…</option>
            <option value="-14,-16">短视频 / 网络平台（-14 / 音乐 -16）</option>
            <option value="-18,-20">综艺 / 日常剪辑（-18 / 音乐 -20，默认）</option>
            <option value="-23,-26">电视播出 EBU R128（-23 / 音乐 -26）</option>
            <option value="-27,-30">影院（-27 / 音乐 -30）</option>
          </select>
        </div>
        <div class="hint">目标值是参考值，可按项目调整：对白较多的综艺通常在 -18 LUFS 左右，背景音乐可以更低。增益限制在 -24 到 +12 dB 之间；峰值保护使用真峰值估计（采样间插值）。</div>
      </div>

      ${updateSectionHtml()}

      <div class="section">
        <div class="section-head"><h2>达芬奇连接</h2></div>
        <div class="kv">
          <div>状态</div><div>${rs.connected ? '<span class="feature-ok">已连接</span>' : `<span style="color:var(--err)">${esc(rs.error || '未连接')}</span>`}</div>
          <div>版本</div><div>${esc(rs.product || '')} ${esc(rs.version || '')}</div>
          <div>功能支持</div>
          <div>
            ${feat(f.audioProps, '片段音量/声像/音高/淡入淡出（21.1+）')}<br>
            ${feat(f.timelineSelection, '从时间线选中添加（21.0.4+）')}<br>
            ${feat(f.fairlightPresets, 'Fairlight 预设（20.2.2+）')}<br>
            ${feat(f.audioTrackIndexFix, '指定音轨放置（20.2.2+）')}
          </div>
        </div>
      </div>`;

    page.querySelectorAll('[data-set]').forEach((cb) => {
      cb.onchange = async () => {
        const st2 = await run(api.saveSettings({ [cb.dataset.set]: cb.checked }));
        if (st2) S.settings = st2.settings;
      };
    });
    $('#setPool', page).onchange = async (e) => {
      const st2 = await run(api.saveSettings({ poolRootName: e.target.value }));
      if (st2) {
        S.settings = st2.settings;
        toast('已保存', 'ok');
      }
    };
    $('#setPos', page).onchange = async (e) => {
      const st2 = await run(api.saveSettings({ defaultPosition: e.target.value }));
      if (st2) S.settings = st2.settings;
    };
    $('#setTarget', page).onchange = async (e) => {
      const st2 = await run(api.saveSettings({ soundTarget: e.target.value }));
      if (st2) S.settings = st2.settings;
    };
    page.querySelectorAll('[data-set-update]').forEach((cb) => {
      cb.onchange = async () => {
        const st2 = await run(api.saveSettings({ update: { [cb.dataset.setUpdate]: cb.checked } }));
        if (st2) S.settings = st2.settings;
      };
    });
    const updUrl = $('#updUrl', page);
    if (updUrl) updUrl.onchange = async (e) => {
      const v = e.target.value.trim();
      if (v && !/^https?:\/\//i.test(v)) return toast('地址要以 http:// 或 https:// 开头', 'err');
      const st2 = await run(api.saveSettings({ update: { url: v } }));
      if (st2) { S.settings = st2.settings; toast(v ? '已保存更新源地址' : '已改回安装包自带的地址', 'ok'); renderSettings(); }
    };
    $('#setTheme', page).onchange = async (e) => {
      const st2 = await run(api.saveSettings({ theme: e.target.value }));
      if (st2) { S.settings = st2.settings; applyTheme(); }
    };
    $('#paPreset', page).onchange = (e) => {
      const v = e.target.value;
      if (!v) return;
      const [sfx, music] = v.split(',').map(Number);
      $('#paTSfx').value = sfx;
      $('#paTMusic').value = music;
      e.target.value = '';
      toast('已填入目标响度，点「保存放入设置」生效');
    };
  }

  // ---------- 事件委托 ----------

  document.addEventListener('click', async (e) => {
    // 点击音效行的空白处：设置焦点 / 多选（按钮和复选框保持原有行为）
    const rowEl = e.target.closest('.sound[data-id]');
    if (rowEl && !e.target.closest('button, input, select, textarea')) {
      return pickRow(rowEl.dataset.id, e);
    }
    const el = e.target.closest('[data-act], [data-cat], [data-tab]');
    if (!el) return;

    if (el.dataset.tab) return switchTab(el.dataset.tab);
    if (el.dataset.cat && !el.dataset.act) {
      S.cat = el.dataset.cat;
      return renderSounds();
    }

    const act = el.dataset.act;
    const tplEl = el.closest('.tpl');
    const tpl = tplEl && S.library.templates.find((t) => t.id === tplEl.dataset.id);
    const soundEl = el.closest('.sound');
    const sound = soundEl && S.library.sounds.find((s) => s.id === soundEl.dataset.id);

    switch (act) {
      case 'save-track':
        e.preventDefault();
        return saveTrackDialog([Number(el.dataset.track)]);
      case 'save-selected':
        return saveTrackDialog([...S.selectedTracks]);
      case 'tracks-all':
        S.selectedTracks = new Set((S.status.timeline?.tracks || []).filter(t => t.clipCount).map(t => t.index));
        return renderTemplates();
      case 'tracks-clear':
        S.selectedTracks.clear();
        return renderTemplates();
      case 'tpl-apply':
        return tpl && quickApply(tpl);
      case 'tpl-options':
        return tpl && applyDialog(tpl);
      case 'tpl-detail':
        return tpl && detailDialog(tpl);
      case 'tpl-more':
        return tpl && tplMenu(el, tpl);
      case 'tpl-fav':
        return tpl && applyState(await run(api.updateTemplate(tpl.id, { favorite: !tpl.favorite })));
      case 'play':
        return sound && togglePlay(sound);
      case 'fav':
        return sound && updateOne(sound, { favorite: !sound.favorite }, sound.favorite ? '取消收藏' : '收藏');
      case 'place':
        return sound && placeSound(sound);
      case 'more':
        return sound && soundMenu(el, sound);
      case 'sel':
        if (sound) {
          if (S.sel.has(sound.id)) S.sel.delete(sound.id);
          else S.sel.add(sound.id);
          S.anchorId = sound.id;
          S.focusId = sound.id;
          return syncSelectionUI();
        }
        return;
      case 'sel-all':
        S.sel = new Set(filteredSounds().map((s) => s.id));
        return syncSelectionUI();
      case 'sel-clear':
        S.sel.clear();
        return syncSelectionUI();
      case 'pa-save': {
        const num = (id) => Number($(`#${id}`).value);
        const placeAudio = {
          normalize: $('#paNorm').checked,
          targetLufs: { sfx: num('paTSfx'), music: num('paTMusic') },
          fadeIn: { sfx: num('paInSfx'), music: num('paInMusic') },
          fadeOut: { sfx: num('paOutSfx'), music: num('paOutMusic') }
        };
        const st2 = await run(api.saveSettings({ placeAudio }));
        if (st2) {
          S.settings = st2.settings;
          toast('已保存放入时间线的音频设置', 'ok');
        }
        return;
      }
      case 'b-cat':
        return batchCategoryDialog();
      case 'b-tag':
        return batchTagDialog();
      case 'b-fav':
        return batchAct('favorite', { value: true }, '已收藏');
      case 'b-unfav':
        return batchAct('favorite', { value: false }, '已取消收藏');
      case 'b-del':
        return batchDeleteDialog();
      case 'cat-add': {
        const name = await prompt(`新建${KIND_NAME[S.lib]}分类`, '分类名称');
        if (name) {
          const st = await run(api.addCategory(name, S.lib));
          if (st) {
            S.cat = name;
            applyState(st);
          }
        }
        return;
      }
      case 'manage-cats':
        return manageCategories();
      case 'batch-place':
        return batchPlaceDialog();
      case 'duck':
        return duckDialog();
      case 'stacks':
        return stacksDialog();
      case 'filters':
        return filtersDialog();
      case 'similar-off':
        S.similarTo = null;
        return renderSounds();
      case 'seek': {
        if (!sound) return;
        const box = el.getBoundingClientRect();
        const frac = box.width ? Math.max(0, Math.min(1, (e.clientX - box.left) / box.width)) : 0;
        return seekPlay(sound, sound.waveform ? frac : 0);
      }
      case 'coll-new':
        return newCollectionDialog([...S.sel]);
      case 'coll-add':
        return S.sel.size ? collectionPicker([...S.sel]) : toast('先勾选要加入的条目', 'err');
      case 'coll-sync': {
        const c = activeCollection();
        if (!c) return;
        const r = await run(api.syncCollection(c.id), `正在把素材包「${c.name}」导入媒体池…`);
        if (r) toast(`素材包已导入媒体池：新导入 ${r.imported} 个，已存在 ${r.already} 个${r.missingFiles ? `，${r.missingFiles} 个文件丢失` : ''}`, r.missingFiles ? 'err' : 'ok');
        return;
      }
      case 'coll-rename': {
        const c = activeCollection();
        return c && collectionRenameDialog(c);
      }
      case 'coll-remove-sel': {
        const c = activeCollection();
        if (!c || !S.sel.size) return;
        const st = await run(api.updateCollection(c.id, { remove: [...S.sel] }));
        if (st) { const n = S.sel.size; S.sel.clear(); applyState(st); toast(`已从素材包移出 ${n} 个（不会删除${KIND_NAME[S.lib]}）`, 'ok'); }
        return;
      }
      case 'coll-delete': {
        const c = activeCollection();
        if (!c) return;
        if (await confirmBox('删除素材包', `<p>删除素材包「${esc(c.name)}」？里面的${KIND_NAME[S.lib]}不会被删除。</p>`, '删除', true)) {
          const st = await run(api.deleteCollection(c.id));
          if (st) { S.cat = '__all'; applyState(st); }
        }
        return;
      }
      case 'audition-toggle':
        if (S.audition) return auditionCancel();
        return auditionStart(S.library.sounds.find((x) => x.id === S.focusId) || (S.sel.size === 1 ? S.library.sounds.find((x) => x.id === [...S.sel][0]) : null));
      case 'audition-confirm':
        return auditionConfirm();
      case 'audition-cancel':
        return auditionCancel();
      case 'ambience':
        return ambienceDialog();
      case 'cuesheet':
        return cueSheetDialog();
      case 'stack-from-selection':
        return stackFromSelectionDialog();
      case 'tidy':
        return tidyDialog();
      case 'stack-place': {
        const id = el.closest('[data-stack]')?.dataset.stack;
        return id && placeStack(id);
      }
      case 'stack-edit': {
        const id = el.closest('[data-stack]')?.dataset.stack;
        const k = (S.library.stacks || []).find((x) => x.id === id);
        return k && stackEditDialog({ id: k.id, name: k.name, note: k.note, layers: k.layers.map((l) => ({ ...l })) });
      }
      case 'stack-delete': {
        const id = el.closest('[data-stack]')?.dataset.stack;
        const k = (S.library.stacks || []).find((x) => x.id === id);
        if (k && await confirmBox('删除组合', `<p>删除「${esc(k.name)}」？不会删除里面的音效。</p>`, '删除', true)) applyState(await run(api.deleteStack(k.id)));
        return;
      }
      case 'std-tracks':
        return standardTracksDialog();
      case 'health':
        return healthDialog();
      case 'upd-check':
        return checkUpdateNow();
      case 'upd-notes':
        return updateNotesDialog();
      case 'upd-download':
        return downloadUpdate();
      case 'upd-page':
        return api.openUpdatePage('page');
      case 'upd-skip':
        return UPD.result?.info && skipUpdate(UPD.result.info.version);
      case 'upd-unskip': {
        const r = await run(api.skipUpdate(''));
        if (r) { if (UPD.result) UPD.result.skipped = false; const st2 = await run(api.state()); applyState(st2); updateBanner(); toast('已取消跳过', 'ok'); }
        return;
      }
      case 'add-browse': {
        const r = await run(api.pickFiles());
        if (r && r.length) addFiles(r);
        return;
      }
      case 'add-pool':
      case 'add-timeline': {
        const cat = currentCategory();
        const r = await run(api.addFromResolve(act === 'add-pool' ? 'mediapool' : 'timeline', cat ? cat.name : null, S.lib), '正在从达芬奇读取选中项…');
        if (r) reportAdd(r);
        return;
      }
      case 'sync-pool': {
        const r = await run(api.syncPool(), '正在导入到媒体池…');
        if (r) toast(`媒体池已同步：新导入 ${r.imported} 个，已存在 ${r.already} 个${r.moved ? `，调整分类 ${r.moved} 个` : ''}${r.missingFiles ? `，${r.missingFiles} 个文件丢失` : ''}${r.moveFailed ? `，${r.moveFailed} 个分类移动失败` : ''}`, r.missingFiles || r.moveFailed ? 'err' : 'ok');
        return;
      }
      case 'lib-open':
        return api.openLibrary();
      case 'lib-choose': {
        const st = await run(api.chooseLibrary());
        if (st) {
          applyState(st);
          toast('已切换音效库', 'ok');
        }
        return;
      }
      case 'lib-export': {
        const dest = await run(api.exportLibrary(), '正在导出音效库…');
        if (dest) toast(`已导出到：${dest}`, 'ok');
        return;
      }
      case 'lib-import': {
        const r = await run(api.importLibrary(), '正在合并音效库…');
        if (r) {
          applyState(r.state);
          const x = r.result;
          toast(`合并完成：新增音效 ${x.sounds} 个、模板 ${x.templates} 个、分类 ${x.categories} 个（跳过重复 ${x.soundsSkipped + x.templatesSkipped} 项）`, 'ok');
        }
        return;
      }
      default:
    }
  });

  // 双击音效行：直接放到播放头
  document.addEventListener('dblclick', (e) => {
    const rowEl = e.target.closest('.sound[data-id]');
    if (!rowEl || e.target.closest('button, input, select, textarea')) return;
    const snd = S.library.sounds.find((x) => x.id === rowEl.dataset.id);
    if (snd && snd.exists) placeSound(snd, 'playhead');
  });

  $('#btnRefresh').onclick = async () => {
    await refreshStatus();
    const st = await run(api.state());
    applyState(st);
    if (S.status.connected) toast('已刷新', 'ok');
  };

  function switchTab(tab) {
    if (tab === 'sounds' || tab === 'music') {
      const lib = tab === 'music' ? 'music' : 'sfx';
      if (S.lib !== lib) {
        S.lib = lib;
        S.cat = '__all';
        S.sel.clear();
        S.focusId = null;
        S.anchorId = null;
      }
    }
    S.tab = tab;
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
    document.querySelectorAll('.tab-page').forEach((p) => p.classList.toggle('active', p.id === `tab-${tab}`));
    render();
  }
  function render() {
    renderStatus();
    if (S.tab === 'templates') renderTemplates();
    else if (S.tab === 'sounds' || S.tab === 'music') renderSounds();
    else renderSettings();
  }
  // 回到窗口时刷新时间线信息（切换了项目/时间线）
  let lastFocusRefresh = 0;
  window.addEventListener('focus', () => {
    if (Date.now() - lastFocusRefresh < 1500) return;
    lastFocusRefresh = Date.now();
    refreshStatus(true);
  });
  setInterval(() => {
    if (document.visibilityState === 'visible' && S.tab === 'templates' && !document.querySelector('.modal-mask, .busy')) refreshStatus(true);
  }, 8000);

  // ---------- 启动 ----------

  (async function init() {
    const st = await run(api.state());
    applyState(st);
    applyTheme();
    await refreshStatus(true);
    // 更新：读当前版本/更新源，接收主进程的自动检查结果
    try {
      const ui = await api.updateInfo();
      if (ui && ui.ok) { UPD.info = ui.data; UPD.result = ui.data.settings && ui.data.settings.lastResult; updateBanner(); }
      if (api.onUpdateResult) api.onUpdateResult((r) => { UPD.result = r; updateBanner(); if (S.tab === 'settings') renderSettings(); });
      if (api.onUpdateProgress) api.onUpdateProgress((p) => { UPD.progress = p; if (UPD.downloading) updateBanner(); });
    } catch {}
  })();

  // ---------- 浏览器预览用的模拟数据（在达芬奇中不会用到） ----------

  function createMockApi() {
    const ok = (data) => Promise.resolve({ ok: true, data });
    const cats = [
      ['转场', '#4f9cf9', 6], ['打击', '#f2655c', 4], ['提示音', '#46c28e', 5], ['搞笑综艺', '#f5b83d', 3],
      ['氛围', '#9b7bf0', 2], ['上升悬疑', '#e86fb6', 1], ['拟音', '#5fc4d6', 0], ['音乐片段', '#c2d64b', 0], ['未分类', '#8a8f98', 1]
    ].map(([name, color, count], i) => ({ id: `c${i}`, name, color, count, keywords: ['whoosh', '转场'], learned: [], trackName: name === '氛围' ? 'BG 氛围' : `FX ${name}`, align: ['转场', '打击'].includes(name) ? 'peak' : name === '上升悬疑' ? 'tail' : 'head', clipColor: '' }));
    const names = [['Whoosh_Fast_01', '转场', 12, true], ['嗖-快速转场', '转场', 9, false], ['Cinematic Boom Hit', '打击', 7, true], ['UI Pop Click', '提示音', 5, false], ['综艺 尴尬乌鸦', '搞笑综艺', 4, true], ['Riser Tension 8s', '上升悬疑', 2, false], ['叮-提示音', '提示音', 1, false], ['Room Tone Office', '氛围', 0, false]];
    const lib = {
      root: 'D:\\音效库',
      collections: [{ id: 'c1', name: '综艺常用包', note: '花字、尴尬、转场', soundIds: ['s0', 's2', 's4'], useCount: 2 }],
      categories: cats,
      sounds: names.map(([name, category, useCount, favorite], i) => ({ id: `s${i}`, name, category, useCount, favorite, exists: true, duration: [0.8, 1.2, 3.4, 0.3, 2.1, 8, 0.6, 30][i], absPath: `C:\\音效库\\${name}.wav`, url: '', file: `sounds/${name}.wav`, addedAt: `2026-10-${10 + i}`, loudness: -18 + i, peakDb: -2, peakOffsetSec: [0.3, 0.4, 0.1, 0.02, 0.5, 1.9, 0.05, 1][i], channels: i % 3 ? 2 : 1, sampleRate: i === 3 ? 44100 : 48000, zcr: 0.1 + i * 0.05, usedIn: i < 3 ? { '综艺第二季': { count: 2 + i, lastUsed: '2026-10-21' } } : {}, waveform: Array.from({ length: 140 }, (_, k) => Math.round(100 * Math.exp(-Math.pow((k / 140 - [0.3, 0.4, 0.1, 0.02, 0.5, 0.95, 0.05, 0.5][i]) / 0.18, 2)) * (0.6 + 0.4 * Math.abs(Math.sin(k * 1.7 + i))))) })),
      stacks: [{ id: 'k1', name: '重转场（嗖+砰+低频）', note: '', useCount: 3, layers: [{ soundId: 's0', name: 'Whoosh_Fast_01', category: '转场', offsetMs: 0, align: 'auto', gainDb: 0 }, { soundId: 's2', name: 'Cinematic Boom Hit', category: '打击', offsetMs: 0, align: 'peak', gainDb: -2 }] }],
      templates: [
        { id: 't1', tracks: [{sourceIndex:3,name:'转场',subType:'stereo'},{sourceIndex:4,name:'打击',subType:'stereo'},{sourceIndex:5,name:'氛围',subType:'stereo'}], trackCount:3, name: '通用三轨音效组合', group: '综艺节目', note: '片头转场 + 笑点音效，结构适合每一集', drt: { file: 'x' }, clipCount: 46, lengthSec: 1325, useCount: 6, createdAt: '2026-10-12T10:00:00Z', anchorOffsetSec: 3, source: { timeline: '第3集 精剪' }, favorite: true },
        { id: 't2', name: '片头 30 秒音效包', group: '片头片尾', note: '', drt: null, clipCount: 9, lengthSec: 30, useCount: 2, createdAt: '2026-10-15T10:00:00Z', anchorOffsetSec: 0, source: { timeline: '片头' }, favorite: false }
      ]
    };
    const status = {
      connected: true, product: 'DaVinci Resolve Studio', version: '21.1.0', project: '综艺第二季', fairlightPresets: ['综艺混音'],
      features: { audioProps: true, timelineSelection: true, fairlightPresets: true, audioTrackIndexFix: true },
      timeline: { name: '第4集 精剪', fps: 25, tracks: [
        { index: 1, name: '对白', subType: 'mono', clipCount: 212, enabled: true },
        { index: 2, name: '音乐', subType: 'stereo', clipCount: 14, enabled: true },
        { index: 3, name: '转场', subType: 'stereo', clipCount: 24, enabled: true },
        { index: 4, name: '打击', subType: 'stereo', clipCount: 20, enabled: true },
        { index: 5, name: '氛围', subType: 'stereo', clipCount: 14, enabled: true }
      ] }
    };
    const settings = { update: { auto: true, url: '', skippedVersion: '', lastCheckedAt: null, lastResult: null }, poolRootName: '音效库', copyFiles: true, learnOnMove: true, autoSaveBeforeApply: true, alwaysOnTop: true, defaultPosition: 'original', soundTarget: 'route', placeAlign: 'auto', ducking: { reduceDb: 9, preMs: 150, postMs: 250, fadeMs: 250, mergeGapMs: 700 }, batchPlace: { source: 'markers', markerColor: '', preFrames: 0, rotate: true, align: 'auto' } };
    const stateObj = () => ({ settings, library: lib });
    const handler = { get: (_t, k) => {
      if (k === 'state') return () => ok(stateObj());
      if (k === 'status') return () => ok(status);
      if (k === 'saveSettings') return (patch) => { Object.assign(settings, patch); return ok(stateObj()); };
      if (k === 'soundToTimeline') return (id, target, position, o) => ok({ trackIndex: 3, trackName: 'FX 转场', createdTrack: false, alignLabel: `${{ head: '开头', peak: '最响点', tail: '结尾' }[o?.align] || '最响点'}对齐`, audio: { gainDb: -2.5 }, state: stateObj() });
      if (k === 'timelinePoints') return (o) => ok({ fps: 25, startFrame: 0, playhead: 250, markers: [{ frame: 100, color: 'Blue', name: '' }, { frame: 275, color: 'Red', name: '' }, { frame: 410, color: 'Blue', name: '' }], cuts: [50, 120, 300, 520], videoTrack: o?.videoTrack || 1, videoTrackCount: 2, colors: ['Blue', 'Red'] });
      if (k === 'placeBatch') return (ids, points) => ok({ placed: points.length - 1, points: points.length, failed: [{ frame: points[0], name: 'Whoosh_Fast_01', error: '演示：该位置已有片段' }], createdTracks: 1, tracks: [6], trackNames: ['FX 转场'], results: [], state: stateObj() });
      if (k === 'duckMusic') return () => ok({ clips: 2, untouched: 1, wholeDucked: 0, fullSegments: 5, duckedSegments: 3, duckTrack: 3, duckTrackName: '音乐 避让', duckTrackCreated: true, reduceDb: -9, skipped: [] });
      if (k === 'placeStack') return (id) => { const k2 = lib.stacks.find((x) => x.id === id); return ok({ placed: k2.layers.length, total: k2.layers.length, failed: [], createdTracks: 2, results: k2.layers.map((l, i) => ({ name: l.name, trackIndex: 6 + i, trackName: i ? 'FX 打击' : 'FX 转场' })), state: stateObj() }); };
      if (k === 'addStack') return (p) => { lib.stacks.unshift({ id: 'k' + Date.now(), useCount: 0, ...p, layers: p.layers.map((l) => ({ ...l, name: lib.sounds.find((x) => x.id === l.soundId)?.name || '?', category: '' })) }); return ok(stateObj()); };
      if (k === 'updateStack') return (id, p) => { const k2 = lib.stacks.find((x) => x.id === id); Object.assign(k2, p, { layers: p.layers.map((l) => ({ ...l, name: lib.sounds.find((x) => x.id === l.soundId)?.name || '?', category: '' })) }); return ok(stateObj()); };
      if (k === 'deleteStack') return (id) => { lib.stacks = lib.stacks.filter((x) => x.id !== id); return ok(stateObj()); };
      if (k === 'addCollection') return (name, ids) => { lib.collections.unshift({ id: 'c' + Date.now(), name, note: '', soundIds: ids.slice(), useCount: 0 }); return ok(stateObj()); };
      if (k === 'updateCollection') return (id, p) => { const c = lib.collections.find((x) => x.id === id); if (p.name) c.name = p.name; if (p.note !== undefined) c.note = p.note; if (p.add) for (const x of p.add) if (!c.soundIds.includes(x)) c.soundIds.push(x); if (p.remove) c.soundIds = c.soundIds.filter((x) => !p.remove.includes(x)); return ok(stateObj()); };
      if (k === 'deleteCollection') return (id) => { lib.collections = lib.collections.filter((x) => x.id !== id); return ok(stateObj()); };
      if (k === 'syncCollection') return () => ok({ imported: 3, already: 1, missingFiles: 0 });
      if (k === 'libraryHealth') return () => ok({ total: 8, missing: [{ id: 's7', name: 'Room Tone Office', file: 'C:\\x\\Room Tone Office.wav' }], duplicates: [[{ name: 'Whoosh_Fast_01', category: '转场' }, { name: '嗖-快速转场', category: '转场' }]], nonStandardRate: [{ id: 's3', name: 'UI Pop Click', sampleRate: 44100 }], silent: [], emptyCategories: [{ name: '拟音', kind: 'sfx' }], unmeasured: 2 });
      if (k === 'removeMissing') return () => ok({ removed: 1, state: stateObj() });
      if (k === 'fillAmbience') return () => ok({ start: 0, end: 1500, fps: 25, segments: 3, failed: [], trackNames: ['BG 氛围', 'BG 氛围 2'], createdTracks: 2, crossfadeFrames: 37, state: stateObj() });
      if (k === 'auditionPlace') return (id) => ok({ trackIndex: 9, trackName: '试听', anchorFrame: 250, recordFrame: 240, align: 'peak', alignLabel: '最响点对齐' });
      if (k === 'auditionConfirm') return () => ok({ trackIndex: 3, trackName: 'FX 转场', createdTrack: false, alignLabel: '最响点对齐', state: stateObj() });
      if (k === 'auditionCancel') return () => ok({ removed: true });
      if (k === 'exportCueSheet') return () => ok({ file: 'C:\\Users\\demo\\Documents\\清单.csv', rows: 5, total: 12 });
      if (k === 'createStandardTracks') return (names) => ok({ created: names.map((n, i) => ({ name: n, trackIndex: 6 + i })), skipped: [] });
      if (k === 'updateInfo') return () => ok({ currentVersion: '1.5.0', builtin: { url: 'https://example.com/sfxlib/version.json', pageUrl: 'https://example.com/sfxlib/' }, effectiveUrl: 'https://example.com/sfxlib/version.json', settings: settings.update });
      if (k === 'checkUpdate') return () => { const r = { checkedAt: new Date().toISOString(), currentVersion: '1.5.0', status: 'available', isNewer: true, skipped: false, info: { name: '音效轨道库', version: '1.6.0', releasedAt: '2026-11-20', minResolve: '20.2.2', downloadUrl: 'https://example.com/sfxlib/downloads/sfx-track-library-v1.6.0.zip', pageUrl: 'https://example.com/sfxlib/', notesUrl: '', sha256: '', size: 170000, notes: ['演示：波形预览支持缩放', '演示：新增浅色主题细节'] } }; settings.update.lastResult = r; return ok(r); };
      if (k === 'downloadUpdate') return () => new Promise((res) => setTimeout(() => res({ ok: true, data: { file: 'C:\\Users\\demo\\Downloads\\sfx-track-library-v1.6.0.zip', size: 170000, sha256: 'abc', verified: true } }), 600));
      if (k === 'skipUpdate') return (v) => { settings.update.skippedVersion = v; return ok(settings.update); };
      if (k === 'openUpdatePage') return () => ok(true);
      if (k === 'onUpdateResult' || k === 'onUpdateProgress') return () => {};
      if (k === 'stackFromSelection') return (o) => { lib.stacks.unshift({ id: 'k' + Date.now(), name: o.name, note: o.note, useCount: 0, layers: [{ soundId: 's0', name: 'Whoosh_Fast_01', category: '转场', offsetMs: 0, align: 'head', gainDb: -3, inSec: 0, durationSec: 0, fadeInMs: 0, fadeOutMs: 200, pan: 0 }, { soundId: 's2', name: 'Cinematic Boom Hit', category: '打击', offsetMs: 400, align: 'head', gainDb: 2, inSec: 0.08, durationSec: 0.4, fadeInMs: 0, fadeOutMs: 0, pan: -30 }] }); return ok({ layers: 2, spanSec: 1.6, added: ['ding'], skipped: [], state: stateObj() }); };
      if (k === 'tidyPlan') return (o) => ok({ timelineName: status.timeline.name, fps: 25, startFrame: 0, mode: o.mode, moves: 14, keep: 212, keepReasons: [{ reason: '与画面链接的声音（对白 / 同期声），不移动', count: 212 }], immovable: [], drops: o.dropDisabled ? 2 : 0, dropList: o.dropDisabled ? [{ name: 'old_take.wav', track: 3 }, { name: 'unused_whoosh.wav', track: 4 }] : [], tracksBefore: status.timeline.tracks.map((t) => ({ index: t.index, name: t.name, clipCount: t.clipCount, movable: t.index === 1 ? 0 : t.clipCount, reason: t.index === 1 ? '' : '' })), newTracks: [{ name: 'FX 转场', clips: [{ name: 'Whoosh_Fast_01.wav', start: 100 }, { name: '嗖-快速转场.wav', start: 900 }] }, { name: 'FX 打击', clips: [{ name: 'Cinematic Boom Hit.wav', start: 300 }] }, { name: 'BG 氛围', clips: [{ name: 'Room Tone Office.wav', start: 0 }] }, { name: 'MX 音乐', clips: [{ name: 'bgm.mp3', start: 0 }] }], willEmpty: [2, 3, 4, 5], alreadyEmpty: [], tracksAfterCount: 5 });
      if (k === 'tidyApply') return (o) => ok({ moved: 14, dropped: o.dropDisabled ? 2 : 0, failed: [], createdTracks: [{ name: 'FX 转场' }, { name: 'FX 打击' }, { name: 'BG 氛围' }, { name: 'MX 音乐' }], deletedTracks: ['音乐', '转场', '打击', '氛围'], renamed: [], backupTimeline: '第4集 精剪 整理前备份 10-26 1530', tracksAfter: ['对白', 'FX 转场', 'FX 打击', 'BG 氛围', 'MX 音乐'] });
      if (k === 'applyTemplate') return (id, opts) => {
        const t = lib.templates.find(x => x.id === id);
        const source = templateTrackList(t);
        const targets = source.map((x, i) => ({sourceIndex:x.sourceIndex, trackIndex:status.timeline.tracks.length+i+1, name:x.name, created:true, expected:opts.mode === 'nested' ? 1 : Math.ceil(t.clipCount/source.length), placed:opts.mode === 'nested' ? 1 : Math.ceil(t.clipCount/source.length)}));
        status.timeline.tracks.push(...targets.map(x=>({index:x.trackIndex,name:x.name,subType:'stereo',enabled:true,clipCount:x.placed})));
        const placed = opts.mode === 'nested' ? source.length : t.clipCount;
        return ok({mode:opts.mode,trackIndex:targets[0].trackIndex,trackIndices:targets.map(x=>x.trackIndex),tracks:targets,createdTracks:targets.length,createdTrack:true,expected:placed,placed,notPlaced:[],missingFiles:[],propsOk:0,propsFail:0,state:stateObj()});
      };
      if (k === 'saveTemplate') return (indices, opts) => {
        const ts = status.timeline.tracks.filter(x=>indices.includes(x.index));
        const count=ts.reduce((n,t)=>n+t.clipCount,0);
        const t={id:'t'+Date.now(),...opts,createdAt:new Date().toISOString(),useCount:0,favorite:false,trackCount:ts.length,tracks:ts.map(x=>({sourceIndex:x.index,name:x.name,subType:x.subType})),clipCount:count,lengthSec:30,anchorOffsetSec:1,drt:opts.fullBackup?{file:'demo.drt'}:null,drtReady:opts.fullBackup,source:{timeline:status.timeline.name}};
        lib.templates.push(t);return ok({template:t,skipped:[],drtError:null,state:stateObj()});
      };
      if (k === 'pathForFile') return () => '';
      if (k === 'startDrag') return () => {};
      if (k === 'getTemplate') return () => ok({ ...lib.templates[0], fps: 25, track: { name: '音效', subType: 'stereo' }, propsCaptured: true, skipped: [], clips: [{ relStartSec: 0, name: 'Whoosh_Fast_01', durationSec: 1, props: { AudioVolume: -6 }, fades: { FadeIn: 0, FadeOut: 5 } }] });
      return () => ok(stateObj());
    } };
    return new Proxy({}, handler);
  }
})();
