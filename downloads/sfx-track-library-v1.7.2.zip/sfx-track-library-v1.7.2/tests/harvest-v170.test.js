// v1.7.0：从已交付项目抓取音效 —— 名字解析、挑最终版、跨项目扫描、入库与使用记录
const assert = require('assert');
const path = require('path'), fs = require('fs'), os = require('os');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve');
const { Library } = require(P + '/lib/library');
const { ResolveBridge } = require(P + '/lib/resolve-bridge');
const harvest = require(P + '/lib/harvest');
const { MPI, TI, Timeline, Project, ProjectManager } = require('./mock-resolve-lib');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx-hv-'));
const media = path.join(tmp, 'media'); fs.mkdirSync(media);
const wav = (n, kb = 2) => { const f = path.join(media, n); fs.writeFileSync(f, Buffer.alloc(kb * 1024, 1)); return f; };

(async () => {
  // ---- 1. 名字解析 / 挑最终版
  const picked = harvest.pickFinalTimelines(['EP35_1016', 'EP35_1018', 'EP36_1020', 'EP36_1020_备份', '第4集 精剪 v2', '第4集 精剪 v3', 'S01E05 2025-10-01', 'S01E05 final', '随手剪', '第十二集', 'EP35_1018 整理前备份 10-26 1441']);
  const sel = picked.filter((p) => p.selected).map((p) => p.name);
  assert.deepEqual(sel, ['EP35_1018', 'EP36_1020', '第4集 精剪 v3', 'S01E05 final', '随手剪', '第十二集'], sel.join(','));
  assert.equal(picked[0].ep, 35); assert.equal(picked[0].date.text, '10-16'); assert.equal(picked[9].ep, 12);
  assert.ok(/备份/.test(picked[3].reason)); assert.ok(/备份/.test(picked[10].reason));
  assert.equal(harvest.pickFinalTimelines(['EP01_1010', 'EP01_1012', 'EP02_1011', '随手剪 copy']).map((p) => p.selected).join(','), 'false,true,true,false', '单独一条的备份也不自动勾');
  assert.equal(harvest.parseTimelineName('2025年10月16日 第3期 v2').date.key, 20251016);
  assert.equal(harvest.parseTimelineName('EP07 251016').date.key, 20251016);
  console.log('PASS 名字解析 / 挑最终版');

  // ---- 2. 假项目管理器：两个项目 + 子文件夹
  const lib = await new Library(path.join(tmp, 'lib')).load();
  const fWhoosh = wav('Whoosh_Fast_01.wav'), fHit = wav('Cinematic Boom Hit.wav', 3), fRoom = wav('city_night_ambience.wav', 9), fBgm = wav('Happy Ukulele bgm.mp3', 30), fRec = wav('rec_0421.wav'), fLost = path.join(media, 'lost.wav');
  await lib.addSounds([fHit], null, { copy: true });
  const hitSnd = lib.data.sounds[0];
  const mk = (file, frames) => new MPI(file, 25, frames);
  const mpW = mk(fWhoosh, 30), mpH = mk(fHit, 60), mpR = mk(fRoom, 2400), mpB = mk(fBgm, 3750), mpRec = mk(fRec, 15), mpLost = mk(fLost, 20), mpVid = new MPI(path.join(media, 'cam.mov'), 25, 500, 'Video + Audio');
  const tlWith = (name, clips) => { const t = new Timeline(name, 25, 0); t.audio = [[], [], []]; t.names = ['对白', '音效', '音乐']; t.sub = ['mono', 'stereo', 'stereo']; for (const [tr, mp, st, dur, extra] of clips) { const it = new TI(mp, st, dur, 0); Object.assign(it, extra || {}); t.audio[tr - 1].push(it); } return t; };
  const pA = new Project('综艺 A');
  pA.timelines = [
    tlWith('EP35_1016', [[2, mpW, 10, 30], [2, mpRec, 50, 15]]),                                   // 旧版：不扫
    tlWith('EP35_1018', [[2, mpVid, 0, 500], [2, mpW, 10, 30], [2, mpW, 100, 30], [2, mpH, 200, 60], [3, mpB, 0, 3750], [2, mpLost, 400, 20], [2, mpRec, 600, 15, { enabled: false }]]),
    tlWith('EP36_1020', [[2, mpW, 10, 30], [2, mpR, 0, 2400], [3, mpB, 0, 3750]]),
    tlWith('EP36_1020 备份', [[2, mpRec, 10, 15]])
  ];
  pA.tl = pA.timelines[1];
  const pB = new Project('纪录片 B');
  pB.timelines = [tlWith('第1集 v2', [[2, mpH, 0, 60], [2, mpRec, 100, 15]])];
  pB.tl = pB.timelines[0];
  const pCur = new Project('当前项目');
  pCur.timelines = [tlWith('EP01', [[2, mpW, 0, 30]])]; pCur.tl = pCur.timelines[0];
  const root = { name: 'Root', projects: [pCur, pA], folders: [{ name: '旧片', projects: [pB], folders: [] }] };
  const pm = new ProjectManager(root, pCur);
  const resolve = { GetProjectManager: () => pm, GetVersion: () => [21, 1, 0, 0], GetProductName: () => 'DaVinci Resolve Studio', GetVersionString: () => '21.1.0' };
  const b = new ResolveBridge();
  b.resolve = resolve; b.version = [21, 1, 0, 0]; b.get = async () => resolve;

  // 列项目 / 进子文件夹
  let L = await b.harvestProjects();
  assert.deepEqual(L.projects.map((p) => p.name), ['当前项目', '综艺 A']); assert.deepEqual(L.folders, ['旧片']); assert.equal(L.currentProject, '当前项目');
  L = await b.harvestProjects({ open: '旧片' });
  assert.deepEqual(L.projects.map((p) => p.name), ['纪录片 B']); assert.equal(L.depth, 1);

  // 在子文件夹里分析 B → 结束后应回到根目录并切回当前项目
  const prog = [];
  let plan = await b.harvestAnalyze(lib, { projects: ['纪录片 B'] }, (p) => prog.push(p.phase));
  assert.equal(pm.current, pCur, '切回当前项目'); assert.equal(pm.cur.name, 'Root', '回到原文件夹'); assert.ok(prog.includes('restore'));
  assert.equal(plan.summary.files, 2); assert.equal(plan.files.find((f) => /Boom/.test(f.name)).inLibrary.id, hitSnd.id);
  console.log('PASS 项目列表 / 子文件夹 / 切回');

  // 再分析 A + 当前项目（根目录）
  prog.length = 0;
  plan = await b.harvestAnalyze(lib, { projects: ['综艺 A', '当前项目'] }, (p) => prog.push(p));
  const A = plan.projects.find((p) => p.project === '综艺 A');
  assert.deepEqual(A.timelines.map((t) => [t.name, t.selected]), [['EP35_1016', false], ['EP35_1018', true], ['EP36_1020', true], ['EP36_1020 备份', false]]);
  assert.equal(A.skippedDialogue, 1, '带画面的片段跳过');
  assert.ok(A.skippedTracks.some((x) => /对白/.test(x)));
  const names = plan.files.map((f) => f.name);
  assert.ok(!names.includes('rec_0421.wav'), '禁用片段 / 旧版 / 备份里的不算');
  const w = plan.files.find((f) => f.name === 'Whoosh_Fast_01.wav');
  assert.equal(w.uses, 4, 'A 两条时间线 3 次 + 当前项目 1 次'); assert.deepEqual(w.projects, { '综艺 A': 3, '当前项目': 1 });
  assert.deepEqual([...new Set(w.timelines.map((t) => t.ep))], [35, 36, 1]);
  assert.equal(plan.files.find((f) => f.name === 'lost.wav').exists, false);
  const bgm = plan.files.find((f) => /Ukulele/.test(f.name)); assert.equal(bgm.kind, 'music'); assert.equal(bgm.durationSec, 150);
  const room = plan.files.find((f) => /ambience/.test(f.name)); assert.equal(room.kind, 'sfx'); assert.ok(room.category, '长文件归氛围类：' + room.category);
  assert.equal(plan.summary.newFiles, 3); assert.equal(plan.summary.inLibrary, 1); assert.equal(plan.summary.missing, 1);
  assert.equal(pm.current, pCur); assert.equal(pm.saves >= 2, true, '切换前保存');
  console.log('PASS 跨项目扫描 / 最终版 / 去重 / 归类');

  // 同名同大小、不同路径 → 合并成一条
  const media2 = path.join(tmp, 'media2'); fs.mkdirSync(media2); fs.copyFileSync(fWhoosh, path.join(media2, 'Whoosh_Fast_01.wav'));
  const dupItem = new TI(mk(path.join(media2, 'Whoosh_Fast_01.wav'), 30), 300, 30, 0);
  pA.timelines[2].audio[1].push(dupItem);
  plan = await b.harvestAnalyze(lib, { projects: ['综艺 A', '当前项目'] });
  const wm = plan.files.filter((f) => f.name === 'Whoosh_Fast_01.wav');
  assert.equal(wm.length, 1, '同名同大小应合并'); assert.equal(wm[0].uses, 5); assert.equal(wm[0].altPaths.length, 1); assert.equal(plan.summary.newFiles, 3);
  pA.timelines[2].audio[1].pop();
  // 用户改勾选：加上旧版 EP35_1016 → rec 出现
  plan = await b.harvestAnalyze(lib, { projects: ['综艺 A'], timelines: { '综艺 A': ['EP35_1016', 'EP35_1018'] } });
  assert.ok(plan.files.some((f) => f.name === 'rec_0421.wav'));
  assert.deepEqual(plan.projects[0].timelines.map((t) => t.selected), [true, true, false, false]);
  // allTimelines：备份除外
  plan = await b.harvestAnalyze(lib, { projects: ['综艺 A'], allTimelines: true });
  assert.deepEqual(plan.projects[0].timelines.map((t) => t.selected), [true, true, true, false]);
  console.log('PASS 手动勾选 / 全部时间线');

  // ---- 2b. 路径映射：Mac 项目里的 /Volumes/share/... 在本机对应别的位置
  const macRoot = path.join(tmp, 'nas', 'share4'); fs.mkdirSync(path.join(macRoot, 'sfx'), { recursive: true });
  fs.copyFileSync(fWhoosh, path.join(macRoot, 'sfx', 'mac_whoosh.wav'));
  const pMac = new Project('Mac 剪的项目');
  pMac.timelines = [tlWith('EP01', [[2, mk('\\Volumes\\share4\\sfx\\mac_whoosh.wav', 30), 0, 30], [2, mk('/Volumes/share4/sfx/mac_whoosh.wav', 30), 100, 30], [2, mk('\\Volumes\\other\\x.wav', 30), 200, 30]])];
  pMac.tl = pMac.timelines[0];
  root.projects.push(pMac);
  plan = await b.harvestAnalyze(lib, { projects: ['Mac 剪的项目'] });
  // Windows 上 path.normalize 会把正反斜杠两种写法并成一条，Linux 上是两条；只要求都“读不到”
  assert.equal(plan.summary.newFiles, 0); assert.equal(plan.summary.missing, plan.files.length); assert.ok(plan.summary.missing >= 2);
  const rootOf = (name) => plan.missingRoots.find((m) => m.root.toLowerCase().endsWith(name));
  assert.ok(rootOf('share4') && rootOf('other'), JSON.stringify(plan.missingRoots));
  assert.equal(rootOf('share4').suggested, '', '没有已知位置时不该有建议');
  // 用户指定本机位置 → 立刻核对，不用重扫；正反斜杠两种写法都算同一个根 → 两条合并
  const plan2 = await b.harvestRemap(lib, { from: '\\Volumes\\share4', to: macRoot, pathMaps: [] });
  assert.equal(plan2.summary.missing, 1, JSON.stringify(plan2.missingRoots));
  const mws = plan2.files.filter((f) => f.name === 'mac_whoosh.wav');
  assert.equal(mws.length, 1); assert.equal(mws[0].uses, 2);
  assert.ok(mws[0].exists && mws[0].filePath.startsWith(macRoot) && mws[0].rawPath.startsWith('\\Volumes'), '映射后 filePath 变本机路径、rawPath 保留');
  assert.deepEqual(plan2.appliedMaps, [{ from: '\\Volumes\\share4', to: macRoot }]);
  // 已知位置里有同名共享（记住的映射目标 …/share4）→ 自动建议
  plan = await b.harvestAnalyze(lib, { projects: ['Mac 剪的项目'], pathMaps: [{ from: '\\Volumes\\zzz', to: macRoot }] });
  assert.equal(plan.summary.missing, plan.files.length);
  assert.equal(rootOf('share4').suggested, macRoot, JSON.stringify(plan.missingRoots));
  assert.equal(rootOf('other').suggested, '');
  // 记住的映射在下次分析时自动套用
  plan = await b.harvestAnalyze(lib, { projects: ['Mac 剪的项目'], pathMaps: plan2.pathMaps });
  assert.equal(plan.summary.missing, 1); assert.equal(plan.appliedMaps.length, 1); assert.equal(plan.summary.newFiles, 1);
  root.projects.pop();
  console.log('PASS 路径映射 / 建议 / 记住');

  // ---- 3. 入库
  plan = await b.harvestAnalyze(lib, { projects: ['综艺 A', '当前项目'] });
  const keys = plan.files.filter((f) => f.selected).map((f) => f.key);
  const r = await b.harvestImport(lib, { keys, copy: true, markUsed: true, overrides: { [w.key]: { kind: 'sfx', category: '转场' } } });
  assert.equal(r.added.length, 3, JSON.stringify(r)); assert.equal(r.duplicates, 1); assert.equal(r.failed.length, 0);
  const w2 = lib.data.sounds.find((s) => s.name === 'Whoosh_Fast_01');
  assert.equal(w2.category, '转场'); assert.equal(w2.useCount, 4); assert.deepEqual(w2.usedIn['综艺 A'].count, 3); assert.ok(/抓取自项目/.test(w2.source));
  assert.ok(fs.existsSync(lib.abs(w2.file)) && lib.abs(w2.file) !== fWhoosh, '已复制进库');
  const bgm2 = lib.data.sounds.find((s) => /Ukulele/.test(s.name)); assert.equal(bgm2.kind, 'music');
  const hit2 = lib.sound(hitSnd.id); assert.equal(hit2.useCount, 1); assert.equal(hit2.usedIn['综艺 A'].count, 1);
  assert.equal(b.pendingHarvest, null);
  // 再抓一次：全部已在库
  plan = await b.harvestAnalyze(lib, { projects: ['综艺 A'] });
  assert.equal(plan.summary.newFiles, 0); assert.equal(plan.summary.inLibrary, 4);
  console.log('PASS 入库 / 使用记录 / 二次抓取全部已在库');

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log('HARVEST v1.7.0 OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
