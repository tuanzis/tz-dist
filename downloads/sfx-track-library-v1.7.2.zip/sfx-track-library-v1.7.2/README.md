# 音效轨道库 · SFX Track Library for DaVinci Resolve

嵌在 **DaVinci Resolve Studio（Windows）** 里的音效 / 配乐工作台。一个浮动面板，帮剪辑师把"找声音、放声音、管轨道、铺配乐"这几件事做快、做准。

> 下载与说明页：见 `docs/`（发布后即为站点首页）。许可证：MIT。本项目与 Blackmagic Design 无关。

## 能做什么

| | |
|---|---|
| **放得准** | 开头 / 最响点 / 结尾三种对齐，按分类有默认值：打击、转场"砰"的那一下对准播放头，上升音收在切点 |
| **轨道不乱** | 按分类进固定音轨（FX 转场 / FX 打击 / BG 氛围 / MX 音乐…），位置被占自动用下一条同名轨 |
| **一键批量** | 按时间线标记或画面切点批量放置，多个候选轮流用、相邻不重复 |
| **配乐避让对白** | 有对白处音乐自动切到「避让」轨并压低，交叉淡化过渡 |
| **音效套餐 / 组合** | 嗖 + 砰 + 低频存成一套，一键整套放下，各层各进自己的轨；也可以直接把时间线上选中的几个片段存成组合 |
| **一键整理音轨** | 乱轨按分类归组、互不重叠的合并、自动命名、删空轨；对白 / 锁定轨不动，先预览再执行，自动备份时间线 |
| **从老项目抓取** | 勾选多个已交付项目，自动找每集最终版时间线，把用过的音效 / 氛围 / 音乐汇总去重入库，并记下在哪用过几次 |
| **轨道模板** | 任选 N 条音轨合存为一份模板，任何项目一键新建对应音轨并还原位置 / 音量 / 淡入淡出，跨帧率换算，可带 DRT 逐轨嵌套 |
| **找声音更快** | 波形缩略图点哪听哪、中英同义词搜索、时长 / 响度筛选、找相似、本片用过、素材包 |
| **时间线试听** | 候选放到「试听」轨，↑↓ 换着听，Enter 正式放置 |
| **氛围铺底** | 环境声循环铺满一段范围，接缝交叉淡化、两轨交替 |
| **交付清单** | 一键导出音乐 / 音频使用清单 CSV（入出点、时长、来源、授权） |
| **响度标准化** | 后台测 LUFS 与真峰值，放入时按目标响度补增益、防削波，按平台一键切换目标 |
| **库是你的** | 音效库就是一个普通文件夹，可放网盘 / NAS 多机共用；导出 / 合并 / 健康检查；深色 / 浅色主题；可选的联网检查更新 |

## 安装

1. Windows 版 **DaVinci Resolve Studio**（官网下载版，20.2.2 以上，推荐 21.1+）。免费版、Mac App Store 版没有"工作流集成"菜单。
2. 下载发布包并解压，关闭达芬奇，双击 `Install.bat`（需要管理员权限）。
3. 打开达芬奇：**工作区 › 工作流集成 › 音效轨道库**。

升级：解压新版再运行一次 `Install.bat`；音效库和设置保留。升级达芬奇后也请重新运行一次（它会重新复制与达芬奇版本匹配的 `WorkflowIntegration.node`）。

## 目录结构

```
Install.bat / Uninstall.bat      一键安装 / 卸载（调用 scripts/*.ps1）
plugin/com.sfxlib.resolve/       插件本体（Electron，达芬奇 Workflow Integration）
  main.js / preload.js           主进程 / 安全桥接
  index.html, css/, js/          面板界面（renderer.js）、响度与波形（loudness.js）、搜索（search.js）
  lib/resolve-bridge.js          与达芬奇交互：放置、模板、避让、铺底、试听、清单
  lib/library.js                 库数据（library.json）：分类、音效、音乐、模板、套餐、素材包
  lib/classify.js                自动分类与学习；分类默认音轨 / 对齐
  lib/update.js                  检查更新的纯逻辑
tests/                           模拟测试：node tests/<name>.test.js
docs/                            对外站点（下载页、version.json、更新说明）
scripts/make-release.ps1         生成发布包（Make-Release.bat）
```

## 开发

- 不需要安装依赖：插件运行在达芬奇自带的 Electron 里，测试只用 Node.js。
- 跑测试：`node tests/mock-resolve.test.js`、`node tests/place-v130.test.js`、`node tests/features-v140.test.js`、`node tests/update-v150.test.js`、`node tests/tidy-v160.test.js`、`node tests/harvest-v170.test.js` 等。
- 调试界面：直接用浏览器打开 `plugin/com.sfxlib.resolve/index.html`，会加载一套模拟数据。

## 发布

源码仓库可以保持私有；对外只公开一个“发布站”仓库（只有安装包、version.json 和下载页，带 noindex / robots 禁止收录）。

1. 改 `plugin/com.sfxlib.resolve/package.json` 与 `manifest.xml` 的版本号，在 `更新说明.md` 顶部新增 `## <版本>` 小节（以 `- ` 开头的行会成为更新要点）。
2. `release.config.json`：`siteBaseUrl` = 发布站根地址（如 `https://<user>.github.io/<dist-repo>`），`publishRepoUrl` / `publishRepoDir` = 发布站仓库及本地目录。可选：`release.private.json`（不入库）里列出本机路径、项目名等关键词，打包时发现即中止；`gitPath` 指定 git.exe。
3. 双击 `Make-Release.bat`：生成 zip + SHA256 + `version.json` → 同步到 `docs/` → 镜像到发布站仓库并推送（`-NoPublish` 只打包不推送）。
4. 发布站的 GitHub Pages 从 `main` 根目录发布；1～2 分钟后生效。插件启动时读取 `<siteBaseUrl>/version.json`，有新版会显示横幅。

## 隐私

插件不收集、不上传任何数据。唯一的网络请求是可选的"检查更新"（读取一个 `version.json`，可在设置里关闭，也可以改成自己的地址）。

## 许可证

MIT，见 `LICENSE`。DaVinci Resolve 是 Blackmagic Design Pty. Ltd. 的商标；发布包不包含 DaVinci Resolve 的任何文件。
