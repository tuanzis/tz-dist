const path = require('path'), fs = require('fs'), os = require('os');
const assert = require('assert');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve');
const L = require(P + '/js/loudness.js');
const { ResolveBridge } = require(P + '/lib/resolve-bridge');
const { Library } = require(P + '/lib/library');

// 1. 标准参考：单声道 1 kHz 正弦（RMS -23 dBFS）→ -23 LUFS；双声道相同信号 +3 dB
const fs48 = 48000, n = fs48 * 5;
const sine = (amp) => Float64Array.from({ length: n }, (_, i) => amp * Math.sin((2 * Math.PI * 1000 * i) / fs48));
const mono = L.measureChannels([sine(Math.SQRT2 * Math.pow(10, -23 / 20))], fs48);
assert.ok(Math.abs(mono.lufs - -23) < 0.05, 'mono ' + mono.lufs);
const stereo = L.measureChannels([sine(Math.SQRT2 * Math.pow(10, -23 / 20)), sine(Math.SQRT2 * Math.pow(10, -23 / 20))], fs48);
assert.ok(Math.abs(stereo.lufs - (-20)) < 0.05, 'stereo ' + stereo.lufs);
// 2. 幅度翻倍 → +6 dB；采样峰值
const a = L.measureChannels([sine(0.1)], fs48), b = L.measureChannels([sine(0.2)], fs48);
assert.ok(Math.abs(b.lufs - a.lufs - 6.02) < 0.05);
assert.ok(Math.abs(a.peakDb - -20) < 0.01);
// 3. 静音与极短
assert.equal(L.measureChannels([new Float64Array(48000)], fs48).lufs, -Infinity);
assert.equal(L.measureChannels([], fs48).lufs, -Infinity);
assert.ok(Number.isFinite(L.measureChannels([sine(0.1).slice(0, 2000)], fs48).lufs), '短于 400ms 也要能测');
// 4. 采样率 44.1 kHz 与 48 kHz 结果接近
const s441 = Float64Array.from({ length: 44100 * 5 }, (_, i) => 0.1 * Math.sin((2 * Math.PI * 1000 * i) / 44100));
assert.ok(Math.abs(L.measureChannels([s441], 44100).lufs - a.lufs) < 0.1);

// 5. 放置增益
assert.equal(L.placementGain({ loudness: -23, peakDb: -10 }, -18).gainDb, 5);
assert.equal(L.placementGain({ loudness: -40, peakDb: -30 }, -18).gainDb, 12, '最多提升 12 dB');
assert.equal(L.placementGain({ loudness: -10, peakDb: -20 }, -18).gainDb, -8);
assert.equal(L.placementGain({ loudness: -10, peakDb: -20 }, -18, { maxCutDb: -6 }).gainDb, -6);
const pk = L.placementGain({ loudness: -30, peakDb: -3 }, -18);
assert.equal(pk.gainDb, 2, '峰值不超过 -1 dBFS');
assert.equal(pk.limitedByPeak, true);
assert.equal(L.placementGain({ loudness: null, peakDb: -3 }, -18).gainDb, 0);
assert.equal(L.placementGain({ loudness: -70, peakDb: -60 }, -18).reason, 'too-quiet-to-measure');

// 6. 库保存响度
(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx121-'));
  const lib = await new Library(path.join(tmp, 'lib')).load();
  const f = path.join(tmp, 'a.wav'); fs.writeFileSync(f, 'RIFFtest');
  const [r] = await lib.addSounds([f], null, { kind: 'sfx' });
  assert.equal(r.sound.loudness, null);
  await lib.setLoudness(r.sound.id, { lufs: -21.46, peakDb: -6.04 });
  assert.equal(lib.sound(r.sound.id).loudness, -21.5);
  assert.equal(lib.sound(r.sound.id).peakDb, -6);
  await lib.setLoudness(r.sound.id, { lufs: -Infinity, peakDb: -Infinity });
  assert.equal(lib.sound(r.sound.id).loudness, null);

  // 7. 放置后设置增益与淡入淡出：用假时间线验证
  const calls = [];
  const item = { GetStart: () => 1000, SetProperty: (k, v) => { calls.push(['prop', k, v]); return true; }, SetFades: (f) => { calls.push(['fades', f]); return true; } };
  const tl = { GetItemListInTrack: (t, i) => (t === 'audio' && i === 3 ? [{ GetStart: () => 500, SetProperty: () => true }, item] : []) };
  const bridge = Object.create(ResolveBridge.prototype);
  const res = await bridge.applyPlacementAudio(tl, 3, 1000, { gainDb: -4.5, fadeIn: 12, fadeOut: 30 });
  assert.equal(res.found, true); assert.equal(res.gainApplied, true); assert.equal(res.fadesApplied, true);
  assert.deepEqual(calls, [['prop', 'AudioVolume', -4.5], ['fades', { FadeIn: 12, FadeOut: 30 }]]);
  const none = await bridge.applyPlacementAudio(tl, 3, 2000, { gainDb: -4.5 });
  assert.equal(none.found, false);
  const zero = await bridge.applyPlacementAudio(tl, 3, 1000, { gainDb: 0, fadeIn: 0, fadeOut: 0 });
  assert.equal(zero.gainApplied, false); assert.equal(zero.fadesApplied, false);
  console.log('LOUDNESS v1.2.1 OK');
})().catch((e) => { console.error(e); process.exit(1); });
