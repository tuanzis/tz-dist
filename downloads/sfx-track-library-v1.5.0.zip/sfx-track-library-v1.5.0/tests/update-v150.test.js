// v1.5.0：联网检查更新的纯逻辑
const path = require('path');
const assert = require('assert');
const U = require(path.resolve(__dirname, '../plugin/com.sfxlib.resolve/lib/update'));

// 版本比较
assert.equal(U.compareVersions('1.5.0', '1.4.0'), 1);
assert.equal(U.compareVersions('1.4.0', '1.4.0'), 0);
assert.equal(U.compareVersions('1.4.0', '1.4.1'), -1);
assert.equal(U.compareVersions('1.10.0', '1.9.9'), 1, '按数字比较，不是按字符串');
assert.equal(U.compareVersions('2.0', '1.99.99'), 1);
assert.equal(U.compareVersions('1.4.0.1', '1.4.0'), 1);
assert.equal(U.compareVersions('v1.4.0', '1.4.0'), null, '带 v 前缀不接受');
assert.equal(U.compareVersions('', '1.4.0'), null);
assert.deepEqual(U.parseVersion('21.1.0.14'), [21, 1, 0, 14]);

// version.json 校验
const info = U.normalizeInfo({ version: ' 1.5.0 ', releasedAt: '2026-10-26', downloadUrl: 'https://example.com/d/sfx-track-library-v1.5.0.zip', pageUrl: 'https://example.com/', notesUrl: 'javascript:alert(1)', sha256: 'ABCDEF0123456789abcdef0123456789abcdef0123456789abcdef0123456789', size: '161234', notes: ['- 第一条', '  • 第二条  ', '', 42, '第三条'] });
assert.equal(info.version, '1.5.0');
assert.equal(info.notesUrl, '', '非 http(s) 链接被丢弃');
assert.equal(info.sha256, 'abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789');
assert.equal(info.size, 161234);
assert.deepEqual(info.notes, ['第一条', '第二条', '第三条']);
assert.equal(U.normalizeInfo({ version: '1.5.0', sha256: 'zz' }).sha256, '', '非法 sha256 被忽略');
assert.deepEqual(U.normalizeInfo({ version: '1.5.0', notes: '- a\n- b\n\nc' }).notes, ['a', 'b', 'c'], '字符串形式的 notes');
assert.throws(() => U.normalizeInfo(null), /格式不正确/);
assert.throws(() => U.normalizeInfo([]), /格式不正确/);
assert.throws(() => U.normalizeInfo({ version: 'latest' }), /version/);
assert.equal(U.normalizeInfo({ version: '1.5.0', notes: Array.from({ length: 30 }, (_, i) => `n${i}`) }).notes.length, 12, '最多 12 条');

// 评估
assert.deepEqual(U.evaluate({ version: '1.5.0' }, '1.4.0', ''), { status: 'available', isNewer: true, skipped: false });
assert.deepEqual(U.evaluate({ version: '1.5.0' }, '1.4.0', '1.5.0'), { status: 'available', isNewer: true, skipped: true });
assert.deepEqual(U.evaluate({ version: '1.4.0' }, '1.4.0', '1.5.0'), { status: 'latest', isNewer: false, skipped: false });
assert.deepEqual(U.evaluate({ version: '1.3.9' }, '1.4.0'), { status: 'latest', isNewer: false, skipped: false });
assert.equal(U.evaluate({ version: 'x' }, '1.4.0').status, 'error');

// 文件名与节流
assert.equal(U.fileNameFromUrl('https://example.com/a/b/sfx-track-library-v1.5.0.zip?x=1', 'fb.zip'), 'sfx-track-library-v1.5.0.zip');
assert.equal(U.fileNameFromUrl('https://example.com/%E9%9F%B3%E6%95%88.zip', 'fb.zip'), '音效.zip');
assert.equal(U.fileNameFromUrl('https://example.com/', 'fb.zip'), 'fb.zip');
assert.equal(U.fileNameFromUrl('not a url', 'fb.zip'), 'fb.zip');
assert.equal(U.shouldAutoCheck(null), true);
assert.equal(U.shouldAutoCheck('garbage'), true);
const now = Date.now();
assert.equal(U.shouldAutoCheck(new Date(now - 2 * 3600e3).toISOString(), now), false, '2 小时前查过，不再查');
assert.equal(U.shouldAutoCheck(new Date(now - 25 * 3600e3).toISOString(), now), true);
assert.ok(U.isHttpUrl('http://127.0.0.1:8080/version.json') && !U.isHttpUrl('file:///c:/x') && !U.isHttpUrl('ftp://x'));

console.log('UPDATE v1.5.0 OK');
