const path = require('path'), fs = require('fs'), os = require('os');
const assert = require('assert');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve/lib');
const { Library } = require(P + '/library');
const { classify, MUSIC_CATEGORIES } = require(P + '/classify');

(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx120-'));
  const mk = (n) => { const f = path.join(tmp, n); fs.writeFileSync(f, 'RIFFtest'); return f; };

  const lib = await new Library(path.join(tmp, 'lib')).load();
  // 1. 音乐默认分类与兜底分类
  assert.ok(lib.data.musicDefaultsSeeded);
  for (const c of MUSIC_CATEGORIES) assert.ok(lib.data.categories.some((x) => x.name === c.name && x.kind === 'music'), c.name);
  assert.ok(lib.data.categories.some((x) => x.name === '未分类音乐' && x.kind === 'music'));
  assert.ok(lib.data.categories.some((x) => x.name === '未分类' && x.kind === 'sfx'));

  // 2. 音乐分类判断：兜底名不能是音效的“未分类”
  assert.equal(classify('random_thing.wav', lib.data.categories.filter((c) => c.kind === 'music'), '未分类音乐').name, '未分类音乐');

  // 3. 添加音乐：进入 music/ 目录，分类自动归入音乐分类
  const [r1] = await lib.addSounds([mk('Opening_Theme_120bpm.wav')], null, { kind: 'music' });
  assert.equal(r1.status, 'added');
  const m1 = lib.sound(r1.sound.id);
  assert.equal(m1.kind, 'music');
  assert.equal(m1.category, '片头片尾');
  assert.ok(m1.file.startsWith('music' + path.sep) || m1.file.startsWith('music/'), m1.file);
  assert.ok(fs.existsSync(lib.abs(m1.file)));

  // 4. 音效不能放进音乐分类
  const [r2] = await lib.addSounds([mk('whoosh_a.wav')], '片头片尾', { kind: 'sfx' });
  assert.equal(r2.sound.category, '转场');
  await assert.rejects(lib.updateSound(r2.sound.id, { category: '片头片尾' }), /音效只能放进音效分类/);
  await assert.rejects(lib.updateSound(m1.id, { category: '转场' }), /音乐只能放进音乐分类/);

  // 5. 音乐元数据
  await lib.updateSound(m1.id, { bpm: 120.4, key: 'C 大调', mood: '欢快', license: '版权免费', source: '测试库' });
  assert.equal(m1.bpm, 120); assert.equal(m1.key, 'C 大调'); assert.equal(m1.mood, '欢快');
  await lib.updateSound(m1.id, { bpm: 'abc' });
  assert.equal(m1.bpm, null);

  // 6. 批量移动分类 + 撤销
  const [r3] = await lib.addSounds([mk('bell_ding.wav')], null, { kind: 'sfx' });
  const ids = [r2.sound.id, r3.sound.id];
  const before = ids.map((id) => { const s = lib.sound(id); return { id, category: s.category, tags: [...s.tags], favorite: s.favorite }; });
  const b1 = await lib.batch(ids, 'category', { category: '提示音' });
  assert.equal(b1.done, 2);
  assert.equal(lib.sound(r2.sound.id).category, '提示音');
  assert.equal(lib.sound(r3.sound.id).category, '提示音');
  // 批量移动音乐到音效分类：类型不符，跳过
  const b2 = await lib.batch([m1.id], 'category', { category: '提示音' });
  assert.equal(b2.skipped, 1); assert.equal(b2.done, 0);
  assert.equal(lib.sound(m1.id).category, '片头片尾');
  // 撤销
  await lib.restore(before);
  assert.equal(lib.sound(r2.sound.id).category, '转场');
  assert.equal(lib.sound(r3.sound.id).category, '提示音');

  // 7. 批量加标签、收藏；删除音乐文件后确实删除
  await lib.batch(ids, 'addTags', { tags: ['开场', '开场', '短'] });
  assert.deepEqual(lib.sound(r2.sound.id).tags, ['开场', '短']);
  await lib.batch(ids, 'favorite', { value: true });
  assert.ok(lib.sound(r2.sound.id).favorite && lib.sound(r3.sound.id).favorite);
  const musicFile = lib.abs(m1.file);
  await lib.deleteSound(m1.id, true);
  assert.ok(!fs.existsSync(musicFile), '音乐副本应被删除');

  // 8. 分类管理：音乐分类可以新建，音效/音乐分类名不能冲突
  await lib.addCategory('婚礼配乐', null, 'music');
  assert.equal(lib.category('婚礼配乐').kind, 'music');
  await assert.rejects(lib.addCategory('转场', null, 'music'), /同名/);

  // 9. 旧版本库（没有 kind、没有音乐分类）加载后自动补齐
  const old = path.join(tmp, 'old'); fs.mkdirSync(path.join(old, 'sounds', '转场'), { recursive: true });
  fs.writeFileSync(path.join(old, 'sounds', '转场', 'x.wav'), 'RIFF');
  fs.writeFileSync(path.join(old, 'library.json'), JSON.stringify({ version: 2, categories: [{ name: '转场', color: '#4f9cf9', keywords: [], learned: [] }], sounds: [{ id: 'a1', name: 'x', file: 'sounds/转场/x.wav', category: '转场' }], templates: [] }));
  const oldLib = await new Library(old).load();
  assert.equal(oldLib.sound('a1').kind, 'sfx');
  assert.ok(oldLib.data.categories.some((c) => c.name === '片头片尾' && c.kind === 'music'));
  assert.ok(oldLib.data.categories.some((c) => c.name === '未分类音乐'));

  console.log('LIB v1.2.0 OK');
})().catch((e) => { console.error(e); process.exit(1); });
