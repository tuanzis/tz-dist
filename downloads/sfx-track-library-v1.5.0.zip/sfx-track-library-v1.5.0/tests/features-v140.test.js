// v1.4.0：波形/特征存储、素材包、本片用过、库健康检查、同义词搜索与筛选/找相似、氛围铺底、时间线试听、使用清单、标准音轨
const path = require('path'), fs = require('fs'), os = require('os');
const assert = require('assert');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve');
const { Library } = require(P + '/lib/library');
const { ResolveBridge } = require(P + '/lib/resolve-bridge');
const L = require(P + '/js/loudness.js');
const S = require(P + '/js/search.js');
const { MPI, TI, Timeline, Project } = require('./mock-resolve-lib');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx140-'));
const media = path.join(tmp, 'media'); fs.mkdirSync(media);
for (const n of ['Whoosh_A.wav', 'Whoosh_B.wav', 'Boom Hit.wav', 'Room Tone Long.wav', 'Rain Loop.wav', 'bgm_calm.mp3']) fs.writeFileSync(path.join(media, n), 'RIFF' + n);

const project = new Project();
const resolve = { GetProjectManager: () => ({ GetCurrentProject: () => project, SaveProject: () => true }), GetVersion: () => [21, 1, 0, 0], GetProductName: () => 'DaVinci Resolve Studio', GetVersionString: () => '21.1.0' };
const byTrack = (tl, i) => tl.audio[i - 1].slice().sort((a, b) => a.start - b.start).map((x) => [x.start, x.start + x.dur]);

(async () => {
  // ---------- 1. loudness.js：波形、真峰值、过零率 ----------
  const sr = 48000, sig = new Float64Array(sr);
  for (let i = 0; i < sr; i += 1) sig[i] = 0.4 * Math.sin((2 * Math.PI * 440 * i) / sr) * Math.exp(-i / (sr * 0.3));
  const m = L.measureChannels([sig], sr);
  assert.ok(Math.abs(m.truePeakDb - m.peakDb) < 0.3, '真峰值接近采样峰值（低频正弦）');
  assert.ok(m.zcr > 0.01 && m.zcr < 0.05, 'zcr ' + m.zcr);
  const wf = L.waveformBins([sig], 50);
  assert.equal(wf.length, 50); assert.equal(wf[0], 100); assert.ok(wf[49] < 30 && wf[49] > 5, '衰减尾巴（平方根拉伸后仍能看见）');
  console.log('LOUDNESS: 波形/真峰值/过零率 OK');

  // ---------- 2. 库：新字段、素材包、本片用过、健康检查 ----------
  const lib = await new Library(path.join(tmp, 'lib')).load();
  await lib.addSounds(['Whoosh_A.wav', 'Whoosh_B.wav', 'Boom Hit.wav', 'Room Tone Long.wav', 'Rain Loop.wav'].map((n) => path.join(media, n)), null, { copy: true });
  await lib.addSounds([path.join(media, 'bgm_calm.mp3')], null, { copy: true, kind: 'music' });
  const snd = (n) => lib.data.sounds.find((s) => s.name === n);
  const wA = snd('Whoosh_A'), wB = snd('Whoosh_B'), hit = snd('Boom Hit'), room = snd('Room Tone Long'), rain = snd('Rain Loop'), bgm = snd('bgm_calm');
  await lib.setLoudness(wA.id, { lufs: -16, peakDb: -1, peakOffsetSec: 0.4, duration: 1.0, waveform: [0, 50, 100.4, 70, -3, 999], channels: 2, sampleRate: 48000, truePeakDb: -0.6, zcr: 0.31 });
  assert.deepEqual(wA.waveform, [0, 50, 100, 70, 0, 100]); assert.equal(wA.channels, 2); assert.equal(wA.sampleRate, 48000); assert.equal(wA.truePeakDb, -0.6); assert.equal(wA.zcr, 0.31);
  await lib.setLoudness(wB.id, { lufs: -17, peakDb: -1, peakOffsetSec: 0.3, duration: 1.2, channels: 1, sampleRate: 44100, zcr: 0.29 });
  await lib.setLoudness(hit.id, { lufs: -14, peakDb: -0.5, peakOffsetSec: 0.05, duration: 0.6, channels: 2, sampleRate: 48000, zcr: 0.12 });
  await lib.setLoudness(room.id, { lufs: -30, peakDb: -18, peakOffsetSec: 2, duration: 60, channels: 2, sampleRate: 48000, zcr: 0.2 });
  await lib.setLoudness(rain.id, { lufs: -26, peakDb: -12, peakOffsetSec: 5, duration: 20, channels: 2, sampleRate: 48000, zcr: 0.4 });
  await lib.setLoudness(bgm.id, { lufs: -20, peakDb: -4, peakOffsetSec: 10, duration: 120, channels: 2, sampleRate: 48000, zcr: 0.08 });
  // 本片用过
  await lib.markUsed(wA.id, '综艺A'); await lib.markUsed(wA.id, '综艺A'); await lib.markUsedMany([wA.id, hit.id], '综艺B');
  assert.equal(wA.useCount, 3); assert.equal(wA.usedIn['综艺A'].count, 2); assert.equal(wA.usedIn['综艺B'].count, 1); assert.equal(hit.usedIn['综艺B'].count, 1);
  await lib.markUsed(wB.id, '');
  assert.deepEqual(wB.usedIn, {});
  // 素材包
  const c = await lib.addCollection('综艺常用包', [wA.id, hit.id, 'nope'], '花字');
  assert.deepEqual(c.soundIds, [wA.id, hit.id]);
  await assert.rejects(lib.addCollection('综艺常用包', []), /同名/);
  await assert.rejects(lib.addCollection('   ', []), /不能为空/);
  await lib.updateCollection(c.id, { add: [wB.id, wA.id], note: '备注' });
  assert.deepEqual(lib.collection(c.id).soundIds, [wA.id, hit.id, wB.id]);
  await lib.updateCollection(c.id, { remove: [hit.id], name: '综艺包2' });
  assert.deepEqual(lib.collection(c.id).soundIds, [wA.id, wB.id]); assert.equal(lib.collection(c.id).name, '综艺包2');
  assert.equal(lib.snapshot().collections[0].count, 2);
  await lib.deleteSound(wB.id, false);
  assert.deepEqual(lib.collection(c.id).soundIds, [wA.id], '删除音效后从素材包移除');
  // 健康检查
  fs.unlinkSync(lib.abs(rain.file));
  const h = lib.health();
  assert.equal(h.missing.length, 1); assert.equal(h.missing[0].name, 'Rain Loop');
  assert.equal(h.nonStandardRate.length, 0, 'wB 已删除');
  assert.ok(h.emptyCategories.some((x) => x.name === '提示音'));
  assert.equal(await lib.removeMissing(), 1); assert.ok(!snd('Rain Loop'));
  // 导出合并保留素材包
  const exp = await lib.exportTo(tmp);
  const lib2 = await new Library(path.join(tmp, 'lib2')).load();
  const mr = await lib2.mergeFrom(exp);
  assert.equal(mr.collections, 1); assert.equal(lib2.data.collections[0].soundIds.length, 1);
  console.log('LIB: 新字段/本片用过/素材包/健康检查/合并 OK');

  // ---------- 3. search.js ----------
  const list = lib.data.sounds;
  const find = (q) => list.filter((s) => S.matchScore(s, S.tokenize(q)) > 0).map((s) => s.name).sort();
  assert.deepEqual(find('转场'), ['Whoosh_A']);
  assert.deepEqual(find('swoosh'), ['Whoosh_A']);
  assert.deepEqual(find('环境'), ['Room Tone Long']);
  assert.deepEqual(find('打击 boom'), ['Boom Hit']);
  assert.deepEqual(find('xyz'), []);
  assert.deepEqual(list.filter((s) => S.passFilters(s, { duration: 'short' })).map((s) => s.name), ['Boom Hit']);
  assert.deepEqual(list.filter((s) => S.passFilters(s, { loud: 'quiet' })).map((s) => s.name), ['Room Tone Long']);
  assert.equal(S.countActiveFilters({ duration: 'short', loud: '' }), 1);
  const sim = S.findSimilar(wA, list);
  assert.equal(sim[0].name, 'Boom Hit', '最像 whoosh 的是短促的 hit，而不是 60 秒的环境声');
  assert.equal(sim[sim.length - 1].kind, 'music', '音乐排最后');
  console.log('SEARCH: 同义词/筛选/找相似 OK');

  // ---------- 4. 氛围铺底 ----------
  const b = new ResolveBridge('x', '/nope'); b.resolve = resolve; b.version = [21, 1, 0];
  const settings = { poolRootName: '音效库', autoSaveBeforeApply: false, soundTarget: 'route' };
  const tl = new Timeline('铺底', 25, 0); project.tl = tl;
  // 媒体导入时的帧数：mock 的 ImportMedia 给 50 帧 @25fps = 2 秒；Room Tone 用更长的
  const origImport = project.mp.ImportMedia.bind(project.mp);
  project.mp.ImportMedia = (paths) => { const items = origImport(paths); for (const it of items) { if (it.file.includes('Room Tone')) { it.fps = 25; it.frames = 250; } if (it.file.includes('Boom')) { it.fps = 25; it.frames = 15; } } return items; };
  tl.video[0].push(new TI(null, 0, 2000, 0));
  tl.playhead = 100;
  const f = await b.fillAmbience(lib, room, { crossfadeMs: 1000, fadeInMs: 400, fadeOutMs: 800 }, settings, { gainDb: -3 });
  // 片段 250 帧，交叉 25 帧 → 步长 225；范围 [100, 2000) 共 1900 帧 → ceil((1900-25)/225)=9 段
  assert.equal(f.rangeSource, 'playhead-to-end'); assert.equal(f.start, 100); assert.equal(f.end, 2000);
  assert.equal(f.segments, 9); assert.equal(f.failed.length, 0); assert.deepEqual(f.trackNames, ['BG 氛围', 'BG 氛围 2']);
  const a = byTrack(tl, f.tracks[0]), bb = byTrack(tl, f.tracks[1]);
  assert.deepEqual(a[0], [100, 350]); assert.deepEqual(bb[0], [325, 575], '相邻段重叠 25 帧并交替放在两条轨');
  const last = [...a, ...bb].sort((x, y) => x[0] - y[0]).pop();
  assert.equal(last[1], 2000, '最后一段裁到范围结束');
  const firstItem = tl.audio[f.tracks[0] - 1].find((x) => x.start === 100);
  assert.deepEqual(firstItem.fades, { FadeIn: 10, FadeOut: 25 }); assert.equal(firstItem.props.AudioVolume, -3);
  const lastItem = [...tl.audio[f.tracks[0] - 1], ...tl.audio[f.tracks[1] - 1]].find((x) => x.start + x.dur === 2000);
  assert.equal(lastItem.fades.FadeOut, 20, '结尾淡出 800ms = 20 帧');
  // 指定秒数 + 入出点
  tl.playhead = 3000;
  const f2 = await b.fillAmbience(lib, room, { seconds: 10, crossfadeMs: 1000 }, settings, {});
  assert.equal(f2.rangeSource, 'seconds'); assert.equal(f2.end - f2.start, 250); assert.equal(f2.segments, 1);
  tl.GetMarkInOut = () => ({ video: { in: 4000, out: 4499 }, audio: { in: 4000, out: 4499 } });
  const f3 = await b.fillAmbience(lib, room, { crossfadeMs: 1000 }, settings, {});
  assert.equal(f3.rangeSource, 'inout'); assert.deepEqual([f3.start, f3.end], [4000, 4500]);
  delete tl.GetMarkInOut;
  await assert.rejects(b.fillAmbience(lib, hit, {}, settings, {}), /太短/);
  console.log('AMBIENCE: 分段/交替轨/交叉淡化/范围来源 OK');

  // ---------- 5. 时间线试听 ----------
  const t2 = new Timeline('试听', 25, 0); project.tl = t2; t2.playhead = 500;
  const a1 = await b.auditionPlace(lib, wA, settings, { gainDb: -1 }, { align: 'head' });
  assert.equal(t2.names[a1.trackIndex - 1], '试听'); assert.equal(a1.recordFrame, 500); assert.equal(wA.useCount, 3, '试听不计使用');
  const a2 = await b.auditionPlace(lib, hit, settings, {}, { align: 'peak' });
  assert.equal(a2.trackIndex, a1.trackIndex); assert.equal(t2.audio[a1.trackIndex - 1].length, 1, '换候选时上一个被移除');
  assert.equal(a2.recordFrame, 500 - 1, '最响点 0.05s = 1 帧');
  const cf = await b.auditionConfirm(lib, settings, { gainDb: -2 }, {});
  assert.equal(t2.audio[a1.trackIndex - 1].length, 0, '确认后试听轨清空');
  assert.equal(cf.trackName, 'FX 打击'); assert.equal(cf.recordFrame, 499); assert.equal(hit.useCount, 2);
  assert.equal(b.audition, null);
  await b.auditionPlace(lib, wA, settings, {}, {});
  const cc = await b.auditionCancel();
  assert.ok(cc.removed); assert.equal(t2.audio[a1.trackIndex - 1].length, 0);
  await assert.rejects(b.auditionConfirm(lib, settings, {}, {}), /没有在试听/);
  console.log('AUDITION: 放置/切换/确认/取消 OK');

  // ---------- 6. 使用清单 ----------
  const inv = await b.audioInventory(lib);
  assert.equal(inv.timeline, '试听');
  const row = inv.rows.find((r) => r.inLibrary);
  assert.ok(row && row.libName === 'Boom Hit' && row.kind === 'sfx' && row.startTc === '00:00:19:24');
  assert.equal(row.volumeDb, -2);
  // 外来音频
  t2.audio[0].push(new TI(new MPI(path.join(media, 'outside.wav'), 25, 50), 0, 50, 0));
  const inv2 = await b.audioInventory(lib);
  assert.ok(inv2.rows.some((r) => !r.inLibrary && r.filePath.includes('outside')));
  console.log('INVENTORY: 库内外片段与时间码 OK');

  // ---------- 7. 标准音轨 ----------
  const t3 = new Timeline('空', 25, 0); project.tl = t3;
  const st = await b.createStandardTracks(['对白', 'FX 转场', 'FX 打击', '音乐', '']);
  assert.deepEqual(st.created.map((x) => x.name), ['FX 转场', 'FX 打击']); assert.deepEqual(st.skipped, ['对白', '音乐']);
  assert.deepEqual(t3.names, ['对白', '音乐', 'FX 转场', 'FX 打击']);
  // 素材包同步
  const sy = await b.syncLibrary(lib, '音效库', { onlyIds: new Set([wA.id]) });
  assert.equal(sy.imported + sy.already, 1, '只处理素材包里的那一个');
  console.log('TRACKS/SYNC: 标准音轨、素材包同步 OK');

  console.log('FEATURES v1.4.0 OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
