const path = require('path'), fs = require('fs'), os = require('os');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve/lib');
const { Library } = require(P + '/library');
const { ResolveBridge } = require(P + '/resolve-bridge');
const tc = require(P + '/timecode');
const { classify } = require(P + '/classify');
const assert = require('assert');

// timecode
assert.equal(tc.tcToFrames('01:00:00:00', 25), 90000);
assert.equal(tc.tcToFrames('00:01:00;02', 29.97, true), 1800);
assert.equal(tc.tcToFrames('00:10:00;00', 29.97, true), 17982);

// ---- fake media
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx-'));
const media = path.join(tmp, 'media'); fs.mkdirSync(media);
for (const n of ['Whoosh_Fast.wav', 'Boom Hit.wav', '叮-提示音.wav', 'random.wav']) fs.writeFileSync(path.join(media, n), 'RIFF' + n);

// ---- mock Resolve
let uidc = 0;
class MPI { constructor(file, fps = 25, frames = 100) { this.file = file; this.fps = fps; this.frames = frames; this.id = ++uidc; }
  GetClipProperty(k) { return { 'File Path': this.file, FPS: String(this.fps), Frames: String(this.frames), Type: 'Audio' }[k]; }
  GetName() { return path.basename(this.file); } }
class Folder { constructor(name) { this.name = name; this.clips = []; this.subs = []; }
  GetName() { return this.name; } GetClipList() { return this.clips; } GetSubFolderList() { return this.subs; } }
class TI { constructor(mp, start, dur, srcStart) { Object.assign(this, { mp, start, dur, srcStart, props: { AudioVolume: -6.5, AudioPan: 10, AudioVolumeEnabled: true }, fades: { FadeIn: 3, FadeOut: 10 }, color: 'Orange', enabled: true }); }
  GetType() { return 'audio'; } GetName() { return this.mp ? this.mp.GetName() : ''; } GetStart() { return this.start; } GetEnd() { return this.start + this.dur; }
  GetMediaPoolItem() { return this.mp; } GetSourceStartFrame() { return this.srcStart; } GetLeftOffset() { return this.srcStart; }
  GetProperty(k) { return k ? this.props[k] : this.props; } SetProperty(k, v) { this.props[k] = v; return true; }
  GetFades() { return this.fades; } SetFades(f) { this.fades = f; return true; } GetClipColor() { return this.color; } SetClipColor(c) { this.color = c; return true; }
  GetClipEnabled() { return this.enabled; } SetClipEnabled(v) { this.enabled = v; return true; } }
class Timeline { constructor(name, fps, start) { Object.assign(this, { name, fps, start, audio: [[], []], video: [[]], names: ['对白', '音效'], sub: ['mono', 'stereo'], playhead: start }); }
  GetName() { return this.name; } GetSetting(k) { return k === 'timelineFrameRate' ? String(this.fps) : k === 'timelineDropFrameTimecode' ? '0' : null; }
  GetStartTimecode() { return tc.framesToTc(this.start, this.fps); } GetStartFrame() { return this.start; }
  GetCurrentTimecode() { return tc.framesToTc(this.playhead, this.fps); }
  GetTrackCount(t) { return t === 'audio' ? this.audio.length : t === 'video' ? this.video.length : 0; }
  GetItemListInTrack(t, i) { return (t === 'audio' ? this.audio : t === 'video' ? this.video : [])[i - 1] || []; }
  GetTrackName(t, i) { return this.names[i - 1]; } SetTrackName(t, i, n) { this.names[i - 1] = n; return true; }
  GetTrackSubType(t, i) { return this.sub[i - 1]; } GetIsTrackEnabled(t, i) { return this.enabled?.[i] !== false; } SetTrackEnable(t, i, v) { (this.enabled ||= {})[i] = v; return true; } GetIsTrackLocked() { return false; }
  AddTrack(t, s) { this.audio.push([]); this.names.push(''); this.sub.push(s); return true; }
  DuplicateTimeline(n) { const d = new Timeline(n, this.fps, this.start); d.audio = this.audio.map(a => a.slice()); d.video = this.video.map(a => a.slice()); return d; }
  DeleteClips(items) { for (const tr of [...this.audio, ...this.video]) for (const it of items) { const i = tr.indexOf(it); if (i >= 0) tr.splice(i, 1); } return true; }
  Export(file) { fs.writeFileSync(file, 'DRT'); return true; }
  GetMediaPoolItem() { return new MPI('', this.fps, 1000); } }
class MediaPool { constructor(project) { this.project = project; this.root = new Folder('Master'); this.cur = this.root; }
  GetRootFolder() { return this.root; } AddSubFolder(f, n) { const s = new Folder(n); f.subs.push(s); return s; }
  GetCurrentFolder() { return this.cur; } SetCurrentFolder(f) { this.cur = f; return true; }
  ImportMedia(paths) { const items = paths.map(p => new MPI(p, 30, 90)); this.cur.clips.push(...items); return items; }
  AppendToTimeline(infos) { const tl = this.project.tl; const out = [];
    for (const i of infos) { const tr = tl.audio[i.trackIndex - 1]; const dur = Math.round((i.endFrame - i.startFrame) / i.mediaPoolItem.fps * tl.fps);
      if (tr.some(x => i.recordFrame < x.start + x.dur && i.recordFrame + dur > x.start)) continue;
      const it = new TI(i.mediaPoolItem, i.recordFrame, dur, i.startFrame); it.props = {}; it.fades = { FadeIn: 0, FadeOut: 0 }; it.color = ''; tr.push(it); out.push(it); } return out; }
  DeleteTimelines() { return true; } GetSelectedClips() { return this.sel || []; }
  ImportTimelineFromFile(f) { return new Timeline('imported', 25, 90000); } }
class Project { constructor() { this.mp = new MediaPool(this); } GetName() { return '测试项目'; } GetMediaPool() { return this.mp; } GetCurrentTimeline() { return this.tl; } SetCurrentTimeline(t) { this.tl = t; return true; } GetSetting() { return '25'; }
  ApplyFairlightPresetToCurrentTimeline() { return true; } }
const project = new Project();
const resolve = { GetProjectManager: () => ({ GetCurrentProject: () => project, SaveProject: () => true }), GetVersion: () => [21, 1, 0, 0], GetProductName: () => 'DaVinci Resolve Studio', GetVersionString: () => '21.1.0', GetFairlightPresets: () => ['综艺'], EXPORT_DRT: 5, EXPORT_NONE: 0 };

(async () => {
  const lib = await new Library(path.join(tmp, 'lib')).load();
  // classify / add
  assert.equal(classify('Whoosh_Fast.wav', lib.data.categories).name, '转场');
  assert.equal(classify('叮-提示音.wav', lib.data.categories).name, '提示音');
  const res = await lib.addSounds(fs.readdirSync(media).map(n => path.join(media, n)), null, { copy: true });
  console.log('add:', res.map(r => `${r.status}:${r.sound?.category}`).join(' '));
  const dup = await lib.addSounds([path.join(media, 'Boom Hit.wav')], null, { copy: true });
  assert.equal(dup[0].status, 'duplicate');
  // move + learn
  const rnd = lib.data.sounds.find(s => s.name === 'random');
  const rndFile = rnd.file;
  await lib.updateSound(rnd.id, { category: '打击' });
  assert.ok(lib.category('打击').learned.includes('random'));
  assert.ok(fs.existsSync(lib.abs(rnd.file)) && rnd.file === rndFile, '分类不能改变音频路径');
  // rename category changes logical label, keeps media paths stable
  const whooshFile = lib.data.sounds.find(s => s.name === 'Whoosh_Fast').file;
  await lib.updateCategory(lib.category('转场').id, { name: '转场嗖' });
  const w = lib.data.sounds.find(s => s.name === 'Whoosh_Fast');
  assert.equal(w.category, '转场嗖'); assert.ok(fs.existsSync(lib.abs(w.file)) && w.file === whooshFile, '分类重命名不能改变音频路径');

  // ---- source timeline 25fps start 01:00:00:00, A2 has 3 clips
  const src = new Timeline('第3集', 25, 90000); project.tl = src;
  const m1 = new MPI(path.join(media, 'Whoosh_Fast.wav'), 25, 50), m2 = new MPI(path.join(media, 'Boom Hit.wav'), 25, 75);
  src.audio[1].push(new TI(m1, 90000 + 250, 25, 5), new TI(m2, 90000 + 500, 50, 0), new TI(m1, 90000 + 1000, 20, 10));
  src.audio[0].push(new TI(m2, 90000, 100, 0));
  src.video[0].push(new TI(null, 90000, 2000, 0));

  const b = new ResolveBridge('x', '/nope'); b.resolve = resolve; b.version = [21, 1, 0];
  const st = await b.status(); console.log('status:', st.timeline.name, st.timeline.fps, st.timeline.tracks.map(t => `A${t.index}:${t.clipCount}`).join(','));
  const cap = await b.captureTrack(lib, 2, { name: '音效模板', copyMedia: true, fullBackup: true });
  console.log('captured:', cap.template.clipCount, 'drt:', !!lib.template(cap.template.id).drt, cap.drtError || '');
  const tpl = lib.template(cap.template.id);
  assert.equal(tpl.clips.length, 3); assert.ok(tpl.clips[0].libFile); assert.equal(tpl.anchorOffsetSec, 10);
  assert.equal(src.audio[1].length, 3, 'original untouched');

  // ---- new project timeline 30fps, start 00:00:00:00 -> apply original position, new track
  const dst = new Timeline('第4集', 30, 0); dst.playhead = 300; project.tl = dst;
  const settings = { poolRootName: '音效库', autoSaveBeforeApply: true };
  const r1 = await b.applyTemplate(lib, tpl.id, { target: 'new', position: 'original', mode: 'rebuild', restoreProps: true }, settings);
  console.log('apply original:', JSON.stringify(r1));
  const t3 = dst.audio[2]; assert.equal(t3.length, 3);
  assert.deepEqual(t3.map(x => x.start), [300, 600, 1200]); // 10s,20s,40s at 30fps
  assert.equal(t3[0].props.AudioVolume, -6.5); assert.equal(t3[0].fades.FadeOut, 12);
  assert.equal(dst.names[2], '音效');
  // apply at playhead onto same track → clash expected
  let clash = null; try { await b.applyTemplate(lib, tpl.id, { target: 3, position: 'playhead', mode: 'rebuild', restoreProps: true }, settings); } catch (e) { clash = e.message; }
  console.log('clash:', clash);
  dst.playhead = 3000;
  const r2 = await b.applyTemplate(lib, tpl.id, { target: 3, position: 'playhead', mode: 'rebuild', restoreProps: false }, settings);
  assert.deepEqual(dst.audio[2].slice(3).map(x => x.start), [3000, 3300, 3900]);
  // media pool folders
  const rootF = project.mp.root.subs.find(f => f.name === '音效库');
  console.log('pool:', rootF.subs.map(f => f.name + '/' + f.subs.map(s => s.name + `(${s.clips.length})`)).join(' '));
  // JS enum fallback (official Windows 21.1 native values)
  const drtConst = resolve.EXPORT_DRT, noneConst = resolve.EXPORT_NONE;
  delete resolve.EXPORT_DRT; delete resolve.EXPORT_NONE;
  assert.equal(await b.getConst('EXPORT_DRT'), 1); assert.equal(await b.getConst('EXPORT_NONE'), -1);
  assert.equal(await b.getConst('NOT_A_CONSTANT'), null);
  resolve.EXPORT_DRT = drtConst; resolve.EXPORT_NONE = noneConst;
  // nested
  const r3 = await b.applyTemplate(lib, tpl.id, { target: 'new', position: 'playhead', mode: 'nested' }, settings);
  console.log('nested:', r3.placed, 'track', r3.trackIndex);
  // sync + place sound
  const sy = await b.syncLibrary(lib, '音效库'); console.log('sync:', JSON.stringify(sy));
  const sy2 = await b.syncLibrary(lib, '音效库'); assert.equal(sy2.imported, 0);
  dst.playhead = 6000;
  const ps = await b.placeSound(lib, lib.data.sounds[0], 'new', settings); console.log('placeSound:', JSON.stringify(ps));

  // ---- 多轨组合：非连续源轨道 -> 按顺序新建，保持共同时间锚点
  const multi = new Timeline('多轨源', 25, 90000);
  while (multi.audio.length < 6) multi.AddTrack('audio', 'stereo');
  multi.names = ['对白', '转场', '音乐', '打击', '氛围', '预留空轨'];
  multi.audio[0].push(new TI(m1, 90000, 25, 0));
  multi.audio[1].push(new TI(m1, 90050, 25, 0), new TI(m1, 90300, 20, 10));
  multi.audio[2].push(new TI(m2, 90000, 50, 0));
  multi.audio[3].push(new TI(m2, 90125, 35, 5), new TI(m2, 90325, 15, 0));
  multi.audio[4].push(new TI(m1, 90025, 15, 0), new TI(m2, 90225, 15, 0));
  multi.SetTrackEnable('audio', 5, false);
  project.tl = multi;
  const mt = await b.captureTracks(lib, [5, 2, 4, 2], { name: '三轨组合', copyMedia: true, fullBackup: true });
  const mtpl = lib.template(mt.template.id);
  assert.equal(mtpl.tracks.length, 3);
  assert.deepEqual(mtpl.tracks.map(t => t.sourceIndex), [2,4,5]);
  assert.equal(mtpl.clips.length, 6);
  assert.equal(mtpl.anchorOffsetSec, 1);
  assert.ok(mtpl.drt && mtpl.drtReady && mtpl.tracks.every(t => t.drt));
  assert.equal(fs.readdirSync(path.join(lib.templateDir(mtpl.id), 'media')).length, 2, '同源文件跨轨去重');
  assert.deepEqual(multi.audio.map(t => t.length), [1,2,1,2,2,0], '源时间线保持不变');
  const target = new Timeline('多轨目标', 30, 0);
  target.audio[0].push(new TI(m1, 0, 30, 0));
  project.tl = target;
  const mrr = await b.applyTemplate(lib, mtpl.id, {}, settings);
  assert.equal(mrr.createdTracks, 3); assert.equal(mrr.placed, 6);
  assert.deepEqual(mrr.trackIndices, [3,4,5]);
  assert.deepEqual(target.audio[2].map(x => x.start), [60,360]);
  assert.deepEqual(target.audio[3].map(x => x.start), [150,390]);
  assert.deepEqual(target.audio[4].map(x => x.start), [30,270]);
  assert.deepEqual(target.names.slice(2), ['转场','打击','氛围']);
  assert.equal(target.GetIsTrackEnabled('audio', 5), false);
  assert.equal(target.audio[0].length, 1, '不改变原轨');
  target.playhead = 600;
  const mpr = await b.applyTemplate(lib, mtpl.id, { position: 'playhead' }, settings);
  assert.deepEqual(target.audio[5].map(x => x.start), [630,930]);
  assert.deepEqual(target.audio[6].map(x => x.start), [720,960]);
  assert.deepEqual(target.audio[7].map(x => x.start), [600,840]);
  const mnr = await b.applyTemplate(lib, mtpl.id, { position: 'playhead', mode: 'nested' }, settings);
  assert.equal(mnr.createdTracks, 3); assert.equal(mnr.placed, 3);
  assert.deepEqual(mnr.trackIndices.map(i => target.audio[i - 1][0].start), [630,720,600]);
  const beforeMultiTarget = target.audio.length;
  await assert.rejects(b.applyTemplate(lib, mtpl.id, { target: 1 }, settings), /分别新建/);
  assert.equal(target.audio.length, beforeMultiTarget);
  project.tl = multi;
  await assert.rejects(b.captureTracks(lib, [], {}), /请选择/);
  await assert.rejects(b.captureTracks(lib, [6], {}), /都是空/);
  const et = await b.captureTracks(lib, [2,6], { name: '含空轨', copyMedia:true, fullBackup:true });
  project.tl = target;
  const er = await b.applyTemplate(lib, et.template.id, { mode:'nested' }, settings);
  assert.equal(er.createdTracks, 2); assert.equal(er.placed, 1);
  assert.equal(target.audio[er.trackIndices[1]-1].length, 0);
  // 旧的单轨模板（没有 tracks / sourceTrack）仍可应用。
  const legacy = { ...tpl, id:'legacy_test' };
  delete legacy.tracks; delete legacy.trackCount; delete legacy.schemaVersion;
  legacy.clips = tpl.clips.map(c => { const x = {...c}; delete x.sourceTrack; return x; });
  await lib.addTemplate(legacy);
  const lr = await b.applyTemplate(lib, legacy.id, {}, settings);
  assert.equal(lr.createdTracks, 1); assert.equal(lr.placed, 3);
  console.log('MULTI-TRACK OK: selection, shared anchor, per-track mapping, nested, empty tracks, legacy');

  // export / merge
  const exp = await lib.exportTo(tmp); const lib2 = await new Library(path.join(tmp, 'lib2')).load();
  const mr = await lib2.mergeFrom(exp); console.log('merge:', JSON.stringify(mr));
  console.log('snapshot templates:', lib2.snapshot().templates.map(t => t.name + ':' + t.clipCount));
  console.log('ALL OK');
})().catch(e => { console.error('FAIL', e); process.exit(1); });
