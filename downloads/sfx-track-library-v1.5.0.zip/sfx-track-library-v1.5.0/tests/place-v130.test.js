// v1.3.0：对齐方式（开头/最响点/结尾）、按分类固定轨、按标记/切点批量放置、音效套餐、音乐避让对白
const path = require('path'), fs = require('fs'), os = require('os');
const assert = require('assert');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve');
const { Library } = require(P + '/lib/library');
const { ResolveBridge } = require(P + '/lib/resolve-bridge');
const { defaultRoute } = require(P + '/lib/classify');
const L = require(P + '/js/loudness.js');
const tc = require(P + '/lib/timecode');

// ---------- 假媒体 ----------
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sfx130-'));
const media = path.join(tmp, 'media'); fs.mkdirSync(media);
for (const n of ['Whoosh_A.wav', 'Whoosh_B.wav', 'Whoosh_C.wav', 'Boom Hit.wav', 'Riser Up.wav', 'Room Tone.wav', 'bgm_happy.mp3']) fs.writeFileSync(path.join(media, n), 'RIFF' + n);

// ---------- 假达芬奇 ----------
let uidc = 0;
class MPI { constructor(file, fps = 25, frames = 50) { this.file = file; this.fps = fps; this.frames = frames; this.id = ++uidc; }
  GetClipProperty(k) { return { 'File Path': this.file, FPS: String(this.fps), Frames: String(this.frames), Type: 'Audio' }[k]; }
  GetName() { return path.basename(this.file); } }
class Folder { constructor(name) { this.name = name; this.clips = []; this.subs = []; }
  GetName() { return this.name; } GetClipList() { return this.clips; } GetSubFolderList() { return this.subs; } }
class TI { constructor(mp, start, dur, srcStart) { Object.assign(this, { mp, start, dur, srcStart, props: {}, fades: { FadeIn: 0, FadeOut: 0 }, color: '', enabled: true }); }
  GetType() { return 'audio'; } GetName() { return this.mp ? this.mp.GetName() : ''; } GetStart() { return this.start; } GetEnd() { return this.start + this.dur; }
  GetMediaPoolItem() { return this.mp; } GetSourceStartFrame() { return this.srcStart; } GetLeftOffset() { return this.srcStart; }
  GetProperty(k) { return k ? this.props[k] : this.props; } SetProperty(k, v) { this.props[k] = v; return true; }
  GetFades() { return this.fades; } SetFades(f) { this.fades = f; return true; } GetClipColor() { return this.color; } SetClipColor(c) { this.color = c; return true; }
  GetClipEnabled() { return this.enabled; } SetClipEnabled(v) { this.enabled = v; return true; } }
class Timeline {
  constructor(name, fps, start) { Object.assign(this, { name, fps, start, audio: [[], []], video: [[]], names: ['对白', '音乐'], sub: ['mono', 'stereo'], locked: {}, playhead: start, markers: {} }); }
  GetName() { return this.name; } GetSetting(k) { return k === 'timelineFrameRate' ? String(this.fps) : k === 'timelineDropFrameTimecode' ? '0' : null; }
  GetStartTimecode() { return tc.framesToTc(this.start, this.fps); } GetStartFrame() { return this.start; }
  GetCurrentTimecode() { return tc.framesToTc(this.playhead, this.fps); }
  GetTrackCount(t) { return t === 'audio' ? this.audio.length : t === 'video' ? this.video.length : 0; }
  GetItemListInTrack(t, i) { return (t === 'audio' ? this.audio : t === 'video' ? this.video : [])[i - 1] || []; }
  GetTrackName(t, i) { return this.names[i - 1]; } SetTrackName(t, i, n) { this.names[i - 1] = n; return true; }
  GetTrackSubType(t, i) { return this.sub[i - 1]; } GetIsTrackEnabled() { return true; } SetTrackEnable() { return true; }
  GetIsTrackLocked(t, i) { return Boolean(this.locked[i]); }
  AddTrack(t, opt) {
    // 20.x+：AddTrack('audio', { audioType, index }) 可以插在中间
    if (opt && typeof opt === 'object' && Number.isInteger(opt.index) && opt.index >= 1 && opt.index <= this.audio.length) {
      const at = opt.index - 1;
      this.audio.splice(at, 0, []); this.names.splice(at, 0, `Audio ${opt.index}`); this.sub.splice(at, 0, opt.audioType || 'stereo');
      const nl = {}; for (const [k, v] of Object.entries(this.locked)) nl[Number(k) >= opt.index ? Number(k) + 1 : Number(k)] = v; this.locked = nl;
      return true;
    }
    this.audio.push([]); this.names.push(`Audio ${this.audio.length}`); this.sub.push(typeof opt === 'string' ? opt : (opt && opt.audioType) || 'stereo'); return true;
  }
  DeleteClips(items) { let n = 0; for (const tr of [...this.audio, ...this.video]) for (const it of items) { const i = tr.indexOf(it); if (i >= 0) { tr.splice(i, 1); n += 1; } } return n > 0; }
  GetMarkers() { return this.markers; }
}
class MediaPool { constructor(project) { this.project = project; this.root = new Folder('Master'); this.cur = this.root; }
  GetRootFolder() { return this.root; } AddSubFolder(f, n) { const s = new Folder(n); f.subs.push(s); return s; }
  GetCurrentFolder() { return this.cur; } SetCurrentFolder(f) { this.cur = f; return true; }
  ImportMedia(paths) { const items = paths.map((p) => new MPI(p, p.includes('bgm') ? 30 : 25, p.includes('bgm') ? 3000 : p.includes('Riser') ? 100 : 50)); this.cur.clips.push(...items); return items; }
  AppendToTimeline(infos) { const tl = this.project.tl; const out = [];
    for (const i of infos) { const tr = tl.audio[i.trackIndex - 1]; if (!tr) continue;
      const mp = i.mediaPoolItem; const sf = i.startFrame || 0, ef = i.endFrame === undefined ? mp.frames : i.endFrame;
      const dur = Math.round((ef - sf) / mp.fps * tl.fps);
      if (tr.some((x) => i.recordFrame < x.start + x.dur && i.recordFrame + dur > x.start)) continue;
      const it = new TI(mp, i.recordFrame, dur, sf); tr.push(it); out.push(it); } return out; }
  DeleteTimelines() { return true; } }
class Project { constructor() { this.mp = new MediaPool(this); } GetName() { return '测试'; } GetMediaPool() { return this.mp; } GetCurrentTimeline() { return this.tl; } SetCurrentTimeline(t) { this.tl = t; return true; } GetSetting() { return '25'; } }
const project = new Project();
let saved = 0;
const resolve = { GetProjectManager: () => ({ GetCurrentProject: () => project, SaveProject: () => { saved += 1; return true; } }), GetVersion: () => [21, 1, 0, 0], GetProductName: () => 'DaVinci Resolve Studio', GetVersionString: () => '21.1.0' };
const byTrack = (tl, i) => tl.audio[i - 1].slice().sort((a, b) => a.start - b.start).map((x) => [x.start, x.start + x.dur]);

(async () => {
  // ---------- 1. 库：分类默认音轨/对齐、老库升级、套餐 ----------
  const lib = await new Library(path.join(tmp, 'lib')).load();
  assert.deepEqual(defaultRoute('转场'), { trackName: 'FX 转场', align: 'peak' });
  assert.equal(lib.category('转场').trackName, 'FX 转场'); assert.equal(lib.category('转场').align, 'peak');
  assert.equal(lib.category('上升悬疑').align, 'tail'); assert.equal(lib.category('氛围').trackName, 'BG 氛围');
  assert.equal(lib.category('欢快轻松').trackName, 'MX 音乐'); assert.equal(lib.category('未分类音乐').trackName, 'MX 音乐');
  // 老库（v3，没有音轨/对齐字段）升级
  const old = path.join(tmp, 'oldlib'); fs.mkdirSync(old);
  fs.writeFileSync(path.join(old, 'library.json'), JSON.stringify({ version: 3, musicDefaultsSeeded: true, categories: [{ id: 'c1', kind: 'sfx', name: '转场', color: '#4f9cf9', keywords: [], learned: [] }, { id: 'c2', kind: 'sfx', name: '我的分类', color: '#fff', keywords: [], learned: [] }], sounds: [{ id: 'a1', name: 'x', file: 'sounds/转场/x.wav', category: '转场', loudness: -20, peakDb: -3 }], templates: [] }));
  const oldLib = await new Library(old).load();
  assert.equal(oldLib.data.version, 5);
  assert.equal(oldLib.category('转场').trackName, 'FX 转场'); assert.equal(oldLib.category('转场').align, 'peak');
  assert.equal(oldLib.category('我的分类').trackName, 'FX 我的分类'); assert.equal(oldLib.category('我的分类').align, 'head');
  assert.equal(oldLib.data.sounds[0].peakOffsetSec, null, '老库音效的最响点为空，之后按需测量');
  assert.ok(Array.isArray(oldLib.data.stacks));
  // 分类字段修改与校验
  await lib.updateCategory(lib.category('提示音').id, { trackName: ' FX UI ', align: 'peak', clipColor: 'Teal' });
  assert.equal(lib.category('提示音').trackName, 'FX UI'); assert.equal(lib.category('提示音').align, 'peak'); assert.equal(lib.category('提示音').clipColor, 'Teal');
  await lib.updateCategory(lib.category('提示音').id, { align: 'nonsense', clipColor: 'NotAColor', trackName: '' });
  assert.equal(lib.category('提示音').align, 'peak', '非法对齐值被忽略'); assert.equal(lib.category('提示音').clipColor, ''); assert.equal(lib.category('提示音').trackName, 'FX 提示音', '空音轨名回到默认');
  await lib.updateCategory(lib.category('提示音').id, { align: 'head', clipColor: '' });
  const newCat = await lib.addCategory('脚步', null, 'sfx');
  assert.equal(newCat.trackName, 'FX 脚步'); assert.equal(newCat.align, 'head');

  // 音效入库 + 测量结果（含最响点）
  const res = await lib.addSounds(fs.readdirSync(media).filter((n) => !n.includes('bgm')).map((n) => path.join(media, n)), null, { copy: true });
  const music = await lib.addSounds([path.join(media, 'bgm_happy.mp3')], null, { copy: true, kind: 'music' });
  assert.equal(music[0].sound.kind, 'music');
  const snd = (n) => lib.data.sounds.find((s) => s.name === n);
  assert.equal(snd('Whoosh_A').category, '转场'); assert.equal(snd('Boom Hit').category, '打击'); assert.equal(snd('Riser Up').category, '上升悬疑'); assert.equal(snd('Room Tone').category, '氛围');
  for (const s of lib.data.sounds) await lib.setLoudness(s.id, { lufs: -20, peakDb: -6, peakOffsetSec: s.name.startsWith('Whoosh') ? 0.4 : s.name === 'Boom Hit' ? 0.08 : 0 });
  assert.equal(snd('Whoosh_A').peakOffsetSec, 0.4);
  await lib.setLoudness(snd('Room Tone').id, { lufs: -30, peakDb: -10, peakOffsetSec: NaN });
  assert.equal(snd('Room Tone').peakOffsetSec, null);
  // loudness.js 的峰值位置
  const sig = new Float64Array(48000); for (let i = 0; i < sig.length; i += 1) sig[i] = 0.05 * Math.sin(i / 7); sig[12000] = 0.9;
  assert.ok(Math.abs(L.measureChannels([sig], 48000).peakOffsetSec - 0.25) < 1e-6);

  // 套餐 CRUD
  const stack = await lib.addStack({ name: '重转场', layers: [{ soundId: snd('Whoosh_A').id, offsetMs: 0, align: 'auto', gainDb: 0 }, { soundId: snd('Boom Hit').id, offsetMs: 200, align: 'peak', gainDb: -3 }] });
  assert.equal(lib.data.stacks.length, 1); assert.equal(stack.layers[1].offsetMs, 200);
  await assert.rejects(lib.addStack({ name: '重转场', layers: [{ soundId: snd('Whoosh_A').id }] }), /同名/);
  await assert.rejects(lib.addStack({ name: '空', layers: [] }), /至少/);
  await assert.rejects(lib.addStack({ name: '坏', layers: [{ soundId: 'nope' }] }), /不存在/);
  await lib.updateStack(stack.id, { name: '重转场 v2', layers: [...stack.layers, { soundId: snd('Riser Up').id, offsetMs: -1500, align: 'tail', gainDb: 99 }] });
  assert.equal(lib.stack(stack.id).layers.length, 3); assert.equal(lib.stack(stack.id).layers[2].gainDb, 12, '增益限制在 +12');
  assert.equal(lib.snapshot().stacks[0].layers[0].name, 'Whoosh_A');
  console.log('LIB: 分类音轨/对齐、老库升级、最响点、套餐 OK');

  // ---------- 2. 对齐方式 ----------
  const b = new ResolveBridge('x', '/nope'); b.resolve = resolve; b.version = [21, 1, 0];
  const settings = { poolRootName: '音效库', autoSaveBeforeApply: true, soundTarget: 'route' };
  const tl = new Timeline('第1集', 25, 0); project.tl = tl; tl.playhead = 1000;
  const audio = { gainDb: -2, fadeInMs: 0, fadeOutMs: 0 };
  let r = await b.placeSound(lib, snd('Whoosh_A'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.equal(r.recordFrame, 1000); assert.equal(r.align, 'head'); assert.equal(r.trackName, 'FX 转场'); assert.equal(r.trackIndex, 3); assert.equal(tl.names[2], 'FX 转场');
  assert.equal(tl.audio[2][0].props.AudioVolume, -2);
  tl.playhead = 2000;
  r = await b.placeSound(lib, snd('Whoosh_A'), 'route', settings, 'playhead', audio, { align: 'peak' });
  assert.equal(r.recordFrame, 1990, '最响点 0.4s = 10 帧，片段提前 10 帧'); assert.equal(r.trackIndex, 3, '位置不重叠，复用同一条轨');
  tl.playhead = 3000;
  r = await b.placeSound(lib, snd('Whoosh_A'), 'route', settings, 'playhead', audio, { align: 'tail' });
  assert.equal(r.recordFrame, 2950, '结尾对齐：50 帧的片段从 2950 开始');
  tl.playhead = 4000;
  r = await b.placeSound(lib, snd('Whoosh_A'), 'route', settings, 'playhead', audio, { align: 'auto' });
  assert.equal(r.recordFrame, 3990, '分类默认（转场 = 最响点）'); assert.equal(r.alignLabel, '最响点对齐');
  r = await b.placeSound(lib, snd('Room Tone'), 'route', settings, 'playhead', audio, { align: 'peak' });
  assert.equal(r.align, 'head'); assert.ok(r.alignFallback, '没有最响点数据时退回开头对齐'); assert.equal(r.trackName, 'BG 氛围');
  tl.playhead = 4; // 对齐后超出时间线开头：裁掉前面
  r = await b.placeSound(lib, snd('Whoosh_B'), 'route', settings, 'playhead', audio, { align: 'peak' });
  assert.equal(r.recordFrame, 0); assert.equal(r.durationFrames, 44);
  const trimmed = tl.audio[r.trackIndex - 1].find((x) => x.start === 0);
  assert.equal(trimmed.srcStart, 6, '媒体入点往后 6 帧，最响点仍对准播放头');
  tl.playhead = 0;
  await assert.rejects(b.placeSound(lib, snd('Riser Up'), 'route', settings, 'playhead', audio, { align: 'tail' }), /完全落在时间线开始之前/);
  console.log('ALIGN: head/peak/tail/auto/fallback/trim OK');

  // ---------- 3. 按分类固定轨 ----------
  const t2 = new Timeline('路由', 25, 0); project.tl = t2; t2.playhead = 500;
  r = await b.placeSound(lib, snd('Whoosh_A'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.deepEqual([r.trackIndex, r.trackName, r.createdTrack], [3, 'FX 转场', true]);
  r = await b.placeSound(lib, snd('Boom Hit'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.deepEqual([r.trackIndex, r.trackName], [4, 'FX 打击']);
  r = await b.placeSound(lib, snd('Whoosh_B'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.deepEqual([r.trackIndex, r.trackName, r.createdTrack], [4, 'FX 转场 2', true], '同位置被占：新建“FX 转场 2”并紧跟在 FX 转场后面');
  assert.deepEqual(t2.names, ['对白', '音乐', 'FX 转场', 'FX 转场 2', 'FX 打击']);
  assert.equal(t2.audio[4].length, 1, '原 FX 打击 轨连同片段一起后移');
  t2.playhead = 2000;
  r = await b.placeSound(lib, snd('Whoosh_C'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.deepEqual([r.trackIndex, r.createdTrack], [3, false], '有空位就用第一条 FX 转场');
  t2.locked[3] = true; t2.playhead = 3000;
  r = await b.placeSound(lib, snd('Whoosh_C'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.equal(r.trackIndex, 4, '锁定的轨跳过');
  t2.locked = {};
  // 音乐：MX 音乐，并且 soundTarget 为指定轨时冲突会报错
  r = await b.placeSound(lib, snd('bgm_happy'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.equal(r.trackName, 'MX 音乐'); assert.equal(r.durationFrames, 2500, '30fps 3000 帧 → 25fps 2500 帧');
  t2.playhead = 500;
  await assert.rejects(b.placeSound(lib, snd('Whoosh_A'), 3, settings, 'playhead', audio, { align: 'head' }), /已有片段/);
  r = await b.placeSound(lib, snd('Whoosh_A'), 'new', settings, 'playhead', audio, { align: 'head' });
  assert.equal(r.trackIndex, t2.audio.length); assert.ok(r.createdTrack);
  // 片段颜色
  await lib.updateCategory(lib.category('打击').id, { clipColor: 'Orange' });
  t2.playhead = 6000;
  r = await b.placeSound(lib, snd('Boom Hit'), 'route', settings, 'playhead', audio, { align: 'head' });
  assert.equal(t2.audio[r.trackIndex - 1].find((x) => x.start === r.recordFrame).color, 'Orange');
  console.log('ROUTE: 固定轨新建/复用/序号插入/锁定/音乐/颜色 OK');

  // ---------- 4. 标记与切点 ----------
  const t3 = new Timeline('标记', 25, 90000); project.tl = t3;
  // 实机：JS 接口 GetMarkers 的键 = 真实帧偏移 - 1（标记真实位置 100/250/400/700/850/1000/1300）
  t3.markers = { 99: { color: 'Blue', name: 'a' }, 249: { color: 'Red', name: 'b' }, 399: { color: 'Blue', name: 'c' }, 699: { color: 'Blue' }, 849: { color: 'Red' }, 999: { color: 'Blue' }, 1299: { color: 'Blue' } };
  t3.video[0].push(new TI(null, 90000, 100, 0), new TI(null, 90100, 150, 0), new TI(null, 90300, 100, 0));
  const pts = await b.timelinePoints({ videoTrack: 1 });
  assert.deepEqual(pts.markers.map((m) => m.frame), [90100, 90250, 90400, 90700, 90850, 91000, 91300], '标记相对时间线起点，并补回 JS 接口少掉的 1 帧');
  assert.deepEqual(pts.colors, ['Blue', 'Red']);
  assert.deepEqual(pts.cuts, [90100, 90250, 90300], '片段开头 + 有空隙的结尾；时间线起点和最后的结尾不算');

  // ---------- 5. 批量放置 ----------
  saved = 0;
  const cands = [snd('Whoosh_A'), snd('Whoosh_B'), snd('Whoosh_C')];
  const bp = await b.placeBatch(lib, cands, pts.markers.map((m) => m.frame), { preFrames: 2, align: 'head', target: 'route', rotate: true }, settings, () => ({ gainDb: -1 }));
  assert.equal(bp.placed, 7); assert.equal(bp.failed.length, 0); assert.equal(saved, 1, '批量前自动保存一次');
  assert.deepEqual(bp.results.map((x) => x.recordFrame), [90098, 90248, 90398, 90698, 90848, 90998, 91298], '每个点提前 2 帧');
  for (let i = 1; i < bp.results.length; i += 1) assert.notEqual(bp.results[i].id, bp.results[i - 1].id, '相邻两个点不会是同一个音效');
  assert.ok(bp.results.every((x) => x.trackName === 'FX 转场'), '位置不重叠，全部在 FX 转场');
  assert.equal(snd('Whoosh_A').useCount + snd('Whoosh_B').useCount + snd('Whoosh_C').useCount >= 7, true);
  const bp2 = await b.placeBatch(lib, [snd('Boom Hit')], pts.cuts, { preFrames: 0, align: 'peak', target: 3, rotate: false }, settings, () => ({}));
  assert.equal(bp2.failed.length, 2, '指定到已占用的轨：被占的点逐个失败并报告'); assert.equal(bp2.placed, 1); assert.match(bp2.failed[0].error, /已有片段/);
  const bp3 = await b.placeBatch(lib, [snd('Boom Hit')], pts.cuts, { preFrames: 0, align: 'peak', target: 'route', rotate: false }, settings, () => ({}));
  assert.equal(bp3.placed, 3); assert.deepEqual(bp3.results.map((x) => x.recordFrame), [90098, 90248, 90298], '最响点 0.08s = 2 帧');
  await assert.rejects(b.placeBatch(lib, [], [1], {}, settings), /没有可用/);
  await assert.rejects(b.placeBatch(lib, cands, [], {}, settings), /没有可放置/);
  console.log('BATCH: 标记/切点读取、轮换不重复、提前帧、失败报告 OK');

  // ---------- 6. 套餐 ----------
  const t4 = new Timeline('套餐', 25, 0); project.tl = t4; t4.playhead = 1000;
  const sr = await b.placeStack(lib, lib.stack(stack.id), settings, 'playhead', () => ({ gainDb: -2 }));
  assert.equal(sr.placed, 3); assert.equal(sr.failed.length, 0);
  const byName = Object.fromEntries(sr.results.map((x) => [x.name, x]));
  assert.equal(byName['Whoosh_A'].recordFrame, 990, '第 1 层：分类默认最响点对齐（0.4s）');
  assert.equal(byName['Boom Hit'].recordFrame, 1005 - 2, '第 2 层：+200ms = 5 帧，最响点 0.08s = 2 帧');
  assert.equal(byName['Riser Up'].recordFrame, 1000 - 37 - 100, '第 3 层：-1500ms = -37.5 → -37 帧，结尾对齐再减去 100 帧时长');
  assert.deepEqual([byName['Whoosh_A'].trackName, byName['Boom Hit'].trackName, byName['Riser Up'].trackName], ['FX 转场', 'FX 打击', 'FX 悬疑']);
  assert.equal(t4.audio[byName['Boom Hit'].trackIndex - 1][0].props.AudioVolume, -5, '响度增益 -2 + 层增益 -3');
  assert.equal(lib.stack(stack.id).useCount, 1);
  console.log('STACK: 多层偏移/对齐/增益/分轨 OK');

  // ---------- 7. 音乐避让对白 ----------
  const t5 = new Timeline('避让', 25, 0); project.tl = t5;
  t5.names = ['对白', '音乐']; t5.AddTrack('audio', 'stereo'); t5.names[2] = '采访';
  const bgm = new MPI(path.join(media, 'bgm_happy.mp3'), 25, 3000);
  const m1 = new TI(bgm, 0, 1000, 0); m1.props = { AudioVolume: -3 }; m1.fades = { FadeIn: 10, FadeOut: 20 }; m1.color = 'Blue';
  const m2 = new TI(bgm, 1000, 500, 1000);          // 整段都在对白里
  const m3 = new TI(bgm, 1600, 400, 1500);          // 没有对白
  t5.audio[1].push(m1, m2, m3);
  t5.audio[0].push(new TI(new MPI('dx1.wav'), 200, 100, 0), new TI(new MPI('dx2.wav'), 320, 80, 0), new TI(new MPI('dx4.wav'), 950, 600, 0));
  t5.audio[2].push(new TI(new MPI('dx3.wav'), 700, 60, 0));
  saved = 0;
  const dk = await b.duckMusic({ musicTrack: 2, dialogueTracks: [1, 3], reduceDb: 9, preMs: 160, postMs: 240, fadeMs: 240, mergeGapMs: 700 }, settings);
  assert.equal(saved, 1);
  assert.equal(dk.clips, 1); assert.equal(dk.wholeDucked, 1); assert.equal(dk.untouched, 1); assert.equal(dk.skipped.length, 0);
  assert.equal(dk.duckTrack, 3); assert.equal(dk.duckTrackName, '音乐 避让'); assert.ok(dk.duckTrackCreated);
  assert.deepEqual(t5.names, ['对白', '音乐', '音乐 避让', '采访'], '避让轨紧跟在音乐轨后面');
  // 对白 [200,300)+[320,400) → 扩成 [196,306]+[316,406] → 合并 [196,406]；[700,760) → [696,766]；[950,1550) → [946,1556] 覆盖 m1 结尾和整个 m2
  assert.deepEqual(byTrack(t5, 2), [[0, 196], [406, 696], [766, 946], [1000, 1500], [1600, 2000]], '音乐轨：有对白处留空');
  assert.deepEqual(byTrack(t5, 3), [[190, 412], [690, 772], [940, 1000]], '避让轨：对白段两头各多 6 帧用来交叉淡化');
  assert.equal(dk.fullSegments, 3); assert.equal(dk.duckedSegments, 3);
  const full = t5.audio[1].slice().sort((a, c) => a.start - c.start), duck = t5.audio[2].slice().sort((a, c) => a.start - c.start);
  assert.deepEqual(full.slice(0, 3).map((x) => x.props.AudioVolume), [-3, -3, -3], '原音量保留');
  assert.deepEqual(duck.map((x) => x.props.AudioVolume), [-12, -12, -12], '避让段降低 9 dB');
  assert.deepEqual(full.slice(0, 3).map((x) => [x.fades.FadeIn, x.fades.FadeOut]), [[10, 6], [6, 6], [6, 6]], '开头保留原淡入，中间用过渡长度');
  assert.deepEqual(duck.map((x) => [x.fades.FadeIn, x.fades.FadeOut]), [[6, 6], [6, 6], [6, 20]], '最后一段到片段结尾，保留原淡出');
  assert.deepEqual(full.slice(0, 3).map((x) => x.srcStart), [0, 406, 766], '分段的媒体入点连续');
  assert.ok(full.slice(0, 3).every((x) => x.color === 'Blue'));
  assert.equal(full[3].props.AudioVolume, -9, '整段在对白里的片段直接降 9 dB');
  assert.equal(full[4].props.AudioVolume, undefined, '没有对白的片段不动');
  // 再跑一次应当是幂等的：音乐轨上的分段都不再和对白重叠
  const dk2 = await b.duckMusic({ musicTrack: 2, dialogueTracks: [1, 3], reduceDb: 9, preMs: 160, postMs: 240, fadeMs: 240, mergeGapMs: 700 }, settings);
  assert.equal(dk2.clips, 0); assert.equal(dk2.duckedSegments, 0); assert.equal(dk2.wholeDucked, 1, '只有整段片段会再次被降低（提示用户不要重复运行）');
  assert.deepEqual(byTrack(t5, 3), [[190, 412], [690, 772], [940, 1000]]);
  // 参数校验
  await assert.rejects(b.duckMusic({ musicTrack: 2, dialogueTracks: [2] }, settings), /不能和音乐音轨相同/);
  await assert.rejects(b.duckMusic({ musicTrack: 9, dialogueTracks: [1] }, settings), /音乐所在/);
  await assert.rejects(b.duckMusic({ musicTrack: 2, dialogueTracks: [] }, settings), /至少选择一条/);
  // 避让轨位置被占 → 恢复原片段
  const t6 = new Timeline('恢复', 25, 0); project.tl = t6; t6.AddTrack('audio', 'stereo'); t6.names[2] = '音乐 避让';
  const m6 = new TI(bgm, 0, 1000, 0); m6.props = { AudioVolume: -1 }; t6.audio[1].push(m6);
  t6.audio[2].push(new TI(new MPI('block.wav'), 150, 300, 0));
  t6.audio[0].push(new TI(new MPI('dx.wav'), 200, 100, 0));
  const dk3 = await b.duckMusic({ musicTrack: 2, dialogueTracks: [1], reduceDb: 9, preMs: 0, postMs: 0, fadeMs: 0, mergeGapMs: 0 }, settings);
  assert.equal(dk3.clips, 0); assert.equal(dk3.restored.length, 1); assert.match(dk3.skipped[0], /已恢复原片段/);
  assert.deepEqual(byTrack(t6, 2), [[0, 1000]]); assert.equal(t6.audio[1][0].props.AudioVolume, -1);
  console.log('DUCK: 分段/音量/淡入淡出/避让轨/幂等/恢复 OK');

  // ---------- 8. 导出合并保留套餐 ----------
  const exp = await lib.exportTo(tmp);
  const lib2 = await new Library(path.join(tmp, 'lib2')).load();
  const mr = await lib2.mergeFrom(exp);
  assert.equal(mr.stacks, 1); assert.equal(lib2.data.stacks[0].layers.length, 3);
  assert.ok(lib2.data.stacks[0].layers.every((l) => lib2.sound(l.soundId)), '套餐里的音效 id 已映射到新库');
  assert.equal(lib2.category('提示音').align, 'head');
  // 删除音效会从套餐里移除
  await lib.deleteSound(snd('Riser Up').id, false);
  assert.equal(lib.stack(stack.id).layers.length, 2);
  console.log('MERGE/DELETE: 套餐跟随 OK');

  console.log('PLACE v1.3.0 OK');
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
