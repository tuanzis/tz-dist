// 测试用的假达芬奇（从 place-v130.test.js 抽出共用）
const path = require('path'), fs = require('fs');
const P = path.resolve(__dirname, '../plugin/com.sfxlib.resolve');
const tc = require(P + '/lib/timecode');
// ---------- 假达芬奇 ----------
let uidc = 0;
class MPI { constructor(file, fps = 25, frames = 50) { this.file = file; this.fps = fps; this.frames = frames; this.id = ++uidc; }
  GetClipProperty(k) { return { 'File Path': this.file, FPS: String(this.fps), Frames: String(this.frames), Type: 'Audio' }[k]; }
  GetName() { return path.basename(this.file); } }
class Folder { constructor(name) { this.name = name; this.clips = []; this.subs = []; }
  GetName() { return this.name; } GetClipList() { return this.clips; } GetSubFolderList() { return this.subs; } }
class TI { constructor(mp, start, dur, srcStart) { Object.assign(this, { mp, start, dur, srcStart, props: {}, fades: { FadeIn: 0, FadeOut: 0 }, color: '', enabled: true }); }
  GetType() { return 'audio'; } GetName() { return this.mp ? this.mp.GetName() : ''; } GetStart() { return this.start; } GetEnd() { return this.start + this.dur; }
  GetMediaPoolItem() { return this.mp; } GetSourceStartFrame() { return this.srcStart; } GetLeftOffset() { return this.srcStart; }
  GetProperty(k) { return k ? this.props[k] : this.props; } SetProperty(k, v) { this.props[k] = v; return true; }
  GetFades() { return this.fades; } SetFades(f) { this.fades = f; return true; } GetClipColor() { return this.color; } SetClipColor(c) { this.color = c; return true; }
  GetClipEnabled() { return this.enabled; } SetClipEnabled(v) { this.enabled = v; return true; } }
class Timeline {
  constructor(name, fps, start) { Object.assign(this, { name, fps, start, audio: [[], []], video: [[]], names: ['对白', '音乐'], sub: ['mono', 'stereo'], locked: {}, playhead: start, markers: {} }); }
  GetName() { return this.name; } GetSetting(k) { return k === 'timelineFrameRate' ? String(this.fps) : k === 'timelineDropFrameTimecode' ? '0' : null; }
  GetStartTimecode() { return tc.framesToTc(this.start, this.fps); } GetStartFrame() { return this.start; }
  GetCurrentTimecode() { return tc.framesToTc(this.playhead, this.fps); }
  GetTrackCount(t) { return t === 'audio' ? this.audio.length : t === 'video' ? this.video.length : 0; }
  GetItemListInTrack(t, i) { return (t === 'audio' ? this.audio : t === 'video' ? this.video : [])[i - 1] || []; }
  GetTrackName(t, i) { return this.names[i - 1]; } SetTrackName(t, i, n) { this.names[i - 1] = n; return true; }
  GetTrackSubType(t, i) { return this.sub[i - 1]; } GetIsTrackEnabled() { return true; } SetTrackEnable() { return true; }
  GetIsTrackLocked(t, i) { return Boolean(this.locked[i]); }
  AddTrack(t, opt) {
    // 20.x+：AddTrack('audio', { audioType, index }) 可以插在中间
    if (opt && typeof opt === 'object' && Number.isInteger(opt.index) && opt.index >= 1 && opt.index <= this.audio.length) {
      const at = opt.index - 1;
      this.audio.splice(at, 0, []); this.names.splice(at, 0, `Audio ${opt.index}`); this.sub.splice(at, 0, opt.audioType || 'stereo');
      const nl = {}; for (const [k, v] of Object.entries(this.locked)) nl[Number(k) >= opt.index ? Number(k) + 1 : Number(k)] = v; this.locked = nl;
      return true;
    }
    this.audio.push([]); this.names.push(`Audio ${this.audio.length}`); this.sub.push(typeof opt === 'string' ? opt : (opt && opt.audioType) || 'stereo'); return true;
  }
  DeleteClips(items) { let n = 0; for (const tr of [...this.audio, ...this.video]) for (const it of items) { const i = tr.indexOf(it); if (i >= 0) { tr.splice(i, 1); n += 1; } } return n > 0; }
  GetMarkers() { return this.markers; }
}
class MediaPool { constructor(project) { this.project = project; this.root = new Folder('Master'); this.cur = this.root; }
  GetRootFolder() { return this.root; } AddSubFolder(f, n) { const s = new Folder(n); f.subs.push(s); return s; }
  GetCurrentFolder() { return this.cur; } SetCurrentFolder(f) { this.cur = f; return true; }
  ImportMedia(paths) { const items = paths.map((p) => new MPI(p, p.includes('bgm') ? 30 : 25, p.includes('bgm') ? 3000 : p.includes('Riser') ? 100 : 50)); this.cur.clips.push(...items); return items; }
  AppendToTimeline(infos) { const tl = this.project.tl; const out = [];
    for (const i of infos) { const tr = tl.audio[i.trackIndex - 1]; if (!tr) continue;
      const mp = i.mediaPoolItem; const sf = i.startFrame || 0, ef = i.endFrame === undefined ? mp.frames : i.endFrame;
      const dur = Math.round((ef - sf) / mp.fps * tl.fps);
      if (tr.some((x) => i.recordFrame < x.start + x.dur && i.recordFrame + dur > x.start)) continue;
      const it = new TI(mp, i.recordFrame, dur, sf); tr.push(it); out.push(it); } return out; }
  DeleteTimelines() { return true; } }
class Project { constructor() { this.mp = new MediaPool(this); } GetName() { return '测试'; } GetMediaPool() { return this.mp; } GetCurrentTimeline() { return this.tl; } SetCurrentTimeline(t) { this.tl = t; return true; } GetSetting() { return '25'; } }

module.exports = { MPI, Folder, TI, Timeline, MediaPool, Project };
