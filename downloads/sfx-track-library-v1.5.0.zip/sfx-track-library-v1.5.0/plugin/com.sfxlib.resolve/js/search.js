'use strict';

/*
 * 搜索与相似度（v1.4.0）：中英同义词扩展、条件筛选、“找相似”。
 * 同时在渲染进程（window.SfxSearch）和 Node（module.exports）里使用。
 */

(function () {
/** 同义词组：搜其中任何一个词，都能命中同组的其他词 */
const SYNONYM_GROUPS = [
  ['whoosh', 'swoosh', 'swish', 'swipe', 'woosh', '转场', '嗖', '呼啸', '划过', '刷'],
  ['hit', 'impact', 'boom', 'slam', 'thud', 'punch', 'braam', '打击', '撞击', '重击', '砰', '咚', '冲击'],
  ['riser', 'rise', 'build', 'uplifter', '上升', '渐强', '爬升'],
  ['tension', 'suspense', 'drone', '悬疑', '紧张', '压迫'],
  ['reverse', 'rev', '反转', '倒放'],
  ['ding', 'chime', 'bell', 'notification', 'notify', '叮', '提示音', '提示', '通知'],
  ['click', 'tap', 'button', 'ui', '点击', '按键', '按钮'],
  ['pop', 'bubble', '弹出', '气泡', '啵'],
  ['beep', 'blip', '哔', '滴'],
  ['error', 'fail', 'wrong', 'buzzer', '错误', '失败', '答错'],
  ['success', 'win', 'correct', 'achievement', '成功', '答对', '胜利', '完成'],
  ['laugh', 'laughter', 'giggle', '笑', '笑声', '哈哈'],
  ['cartoon', 'boing', 'comic', 'funny', '搞笑', '卡通', '滑稽', '综艺'],
  ['crow', 'cricket', 'awkward', '乌鸦', '尴尬', '冷场'],
  ['question', 'huh', 'confused', '问号', '疑惑', '震惊'],
  ['ambience', 'ambient', 'atmos', 'atmosphere', 'room tone', 'roomtone', 'background', '环境', '氛围', '底噪', '环境声'],
  ['wind', 'breeze', 'gust', '风', '风声'],
  ['rain', 'storm', 'thunder', '雨', '雨声', '雷', '暴雨'],
  ['crowd', 'people', 'walla', 'chatter', '人群', '人声', '嘈杂', '闹市'],
  ['city', 'traffic', 'street', '城市', '街道', '车流'],
  ['forest', 'birds', 'nature', '森林', '鸟', '自然'],
  ['water', 'splash', 'drip', 'wave', 'ocean', '水', '水声', '海浪', '滴水'],
  ['fire', 'flame', 'burn', '火', '火焰', '燃烧'],
  ['footstep', 'footsteps', 'step', 'steps', 'walk', '脚步', '走路', '步声'],
  ['door', 'knock', 'slam door', '门', '开门', '关门', '敲门'],
  ['paper', 'page', '纸', '翻页', '纸张'],
  ['cloth', 'fabric', 'rustle', '布', '衣服', '摩擦'],
  ['glass', 'shatter', 'break', '玻璃', '碎', '打碎'],
  ['typing', 'keyboard', 'type', '键盘', '打字'],
  ['phone', 'ring', 'ringtone', 'vibrate', '手机', '电话', '铃声', '震动'],
  ['camera', 'shutter', 'photo', '相机', '快门', '拍照'],
  ['explosion', 'blast', 'bomb', '爆炸', '炸'],
  ['gun', 'shot', 'gunshot', '枪', '枪声', '开枪'],
  ['car', 'engine', 'vehicle', 'drive', '汽车', '引擎', '发动机'],
  ['sword', 'blade', 'slash', '刀', '剑', '挥砍'],
  ['magic', 'sparkle', 'shimmer', 'twinkle', '魔法', '闪亮', '星星'],
  ['heartbeat', 'heart', 'pulse', '心跳'],
  ['clock', 'tick', 'ticking', '钟', '滴答', '倒计时'],
  ['whistle', '口哨', '哨声'],
  ['applause', 'clap', 'cheer', '掌声', '鼓掌', '欢呼'],
  ['stinger', 'sting', 'jingle', 'logo', 'ident', '片头', '片尾', '音效片段', '短音乐'],
  ['music', 'bgm', 'score', 'soundtrack', 'song', '音乐', '配乐', '背景音乐', '歌'],
  ['intro', 'opening', 'title', 'theme', '开场', '主题曲', '片头曲'],
  ['outro', 'ending', 'credits', '结尾', '片尾曲'],
  ['happy', 'upbeat', 'cheerful', 'fun', 'bright', '欢快', '轻松', '明快', '活泼'],
  ['sad', 'emotional', 'cry', 'melancholy', '悲伤', '感人', '伤感', '催泪'],
  ['epic', 'action', 'battle', 'drums', 'trailer', '史诗', '动作', '战斗', '燃', '预告'],
  ['romantic', 'love', 'warm', 'piano', 'sentimental', '温情', '抒情', '浪漫', '钢琴'],
  ['calm', 'soft', 'pad', 'relax', 'chill', '舒缓', '安静', '轻柔', '放松'],
  ['dark', 'horror', 'creepy', 'scary', 'thriller', '恐怖', '诡异', '黑暗', '惊悚'],
  ['loop', 'loopable', 'seamless', '循环', '可循环'],
  ['sub', 'bass', 'low', 'rumble', '低频', '低音', '轰鸣'],
  ['transition', 'cut', 'swipe', '过渡', '转场'],
  ['vlog', 'daily', '日常'],
  ['game', 'arcade', '8bit', '游戏', '像素'],
  ['office', 'workplace', '办公', '办公室', '公司'],
  ['kitchen', 'cooking', 'sizzle', '厨房', '做饭', '煎炒'],
  ['school', 'classroom', '学校', '教室', '上课'],
  ['hospital', 'monitor', '医院', '监护仪'],
  ['restaurant', 'cafe', 'bar', '餐厅', '咖啡馆', '酒吧'],
  ['night', 'crickets', '夜晚', '虫鸣', '夜'],
  ['train', 'subway', 'metro', '火车', '地铁', '列车'],
  ['airport', 'plane', 'airplane', 'jet', '机场', '飞机'],
  ['baby', 'child', 'kids', '婴儿', '小孩', '儿童'],
  ['dog', 'bark', '狗', '狗叫'],
  ['cat', 'meow', '猫', '猫叫'],
  ['bird', 'chirp', '鸟', '鸟叫', '鸟鸣']
];

const SYN_INDEX = new Map();
for (const g of SYNONYM_GROUPS) for (const w of g) SYN_INDEX.set(w.toLowerCase(), g);

/** 把查询词切成 token（空格、逗号分隔；中文整体作为一个 token，也按 2 字切片） */
function tokenize(q) {
  const out = new Set();
  for (const raw of String(q || '').toLowerCase().split(/[\s,，、/]+/)) {
    const t = raw.trim();
    if (!t) continue;
    out.add(t);
  }
  return [...out];
}

/** 一个 token 扩展成同义词集合（含自身） */
function expandToken(t) {
  const set = new Set([t]);
  const g = SYN_INDEX.get(t);
  if (g) for (const w of g) set.add(w.toLowerCase());
  // 中文词：如果某个同义词包含在 token 里（比如“快速转场” 包含 “转场”），也扩展
  if (/[\u4e00-\u9fff]/.test(t)) {
    for (const [w, grp] of SYN_INDEX) if (w.length >= 2 && t.includes(w)) for (const x of grp) set.add(x.toLowerCase());
  }
  return [...set];
}

/** 音效的可搜索文本 */
function haystack(s) {
  return `${s.name || ''} ${s.category || ''} ${(s.tags || []).join(' ')} ${s.key || ''} ${s.mood || ''} ${s.source || ''} ${s.license || ''} ${s.originalPath ? s.originalPath.split(/[\\/]/).pop() : ''}`.toLowerCase();
}

/**
 * 关键词匹配：每个 token（或它的任一同义词）都要命中。
 * 返回 0 = 不匹配，否则是分数（直接命中比同义词命中分高）。
 */
function matchScore(s, tokens) {
  if (!tokens.length) return 1;
  const h = haystack(s);
  let score = 0;
  for (const t of tokens) {
    if (h.includes(t)) { score += 3; continue; }
    const alt = expandToken(t).filter((x) => x !== t && h.includes(x));
    if (!alt.length) return 0;
    score += 1;
  }
  return score;
}

/**
 * 条件筛选
 * f: { duration: ''|'short'|'medium'|'long'|'xlong', channels: ''|'1'|'2+', rate: ''|'48k'|'other', loud: ''|'quiet'|'mid'|'loud', measured: bool }
 */
function passFilters(s, f) {
  if (!f) return true;
  if (f.duration) {
    const d = Number(s.duration);
    if (!Number.isFinite(d)) return false;
    if (f.duration === 'short' && !(d < 1)) return false;
    if (f.duration === 'medium' && !(d >= 1 && d < 5)) return false;
    if (f.duration === 'long' && !(d >= 5 && d < 30)) return false;
    if (f.duration === 'xlong' && !(d >= 30)) return false;
  }
  if (f.channels) {
    const c = Number(s.channels);
    if (!Number.isFinite(c)) return false;
    if (f.channels === '1' && c !== 1) return false;
    if (f.channels === '2+' && c < 2) return false;
  }
  if (f.rate) {
    const r = Number(s.sampleRate);
    if (!Number.isFinite(r)) return false;
    if (f.rate === '48k' && r !== 48000) return false;
    if (f.rate === 'other' && r === 48000) return false;
  }
  if (f.loud) {
    const l = Number(s.loudness);
    if (!Number.isFinite(l)) return false;
    if (f.loud === 'quiet' && !(l < -24)) return false;
    if (f.loud === 'mid' && !(l >= -24 && l <= -14)) return false;
    if (f.loud === 'loud' && !(l > -14)) return false;
  }
  return true;
}

function countActiveFilters(f) {
  return f ? ['duration', 'channels', 'rate', 'loud'].filter((k) => f[k]).length : 0;
}

/** 相似度特征：时长（对数）、响度、峰值比（瞬态感）、过零率（亮度）、最响点位置比例 */
function features(s) {
  const d = Number(s.duration) > 0 ? Math.log10(Number(s.duration) + 0.05) : null;
  const l = Number.isFinite(Number(s.loudness)) ? Number(s.loudness) : null;
  const crest = Number.isFinite(Number(s.peakDb)) && l !== null ? Number(s.peakDb) - l : null;
  const z = Number.isFinite(Number(s.zcr)) ? Number(s.zcr) : null;
  const pos = Number(s.duration) > 0 && Number.isFinite(Number(s.peakOffsetSec)) ? Math.min(1, Number(s.peakOffsetSec) / Number(s.duration)) : null;
  return { d, l, crest, z, pos };
}

/** 距离越小越像；维度缺失时按中等差异计 */
function distance(a, b) {
  const fa = features(a), fb = features(b);
  const dim = (x, y, scale, miss = 0.6) => (x === null || y === null ? miss : Math.min(1.5, Math.abs(x - y) / scale));
  let d = 0;
  d += dim(fa.d, fb.d, 0.6) * 1.2;      // 时长差一个数量级 ≈ 1.6
  d += dim(fa.l, fb.l, 8) * 0.8;        // 响度差 8 LU
  d += dim(fa.crest, fb.crest, 8) * 1.0; // 瞬态感
  d += dim(fa.z, fb.z, 0.15) * 1.0;     // 亮度
  d += dim(fa.pos, fb.pos, 0.4) * 0.6;  // 最响点位置
  if (a.category && a.category === b.category) d -= 0.6; // 同分类更像
  if ((a.kind || 'sfx') !== (b.kind || 'sfx')) d += 1.5;
  return d;
}

function findSimilar(target, list, limit = 30) {
  return (list || [])
    .filter((s) => s && s.id !== target.id)
    .map((s) => ({ s, d: distance(target, s) }))
    .sort((x, y) => x.d - y.d)
    .slice(0, limit)
    .map((x) => x.s);
}

const api = { SYNONYM_GROUPS, tokenize, expandToken, matchScore, passFilters, countActiveFilters, features, distance, findSimilar, haystack };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof window !== 'undefined') window.SfxSearch = api;
})();
