'use strict';

/*
 * 响度工具（v1.2.1，v1.3.0 增加峰值位置）：ITU-R BS.1770-4 积分响度（LUFS）+ 采样峰值（dBFS）及其位置，以及放置增益计算。
 * 同时兼容两种运行环境：
 *   - 渲染进程（Electron 页面）：作为普通脚本加载，挂到 window.SfxLoudness
 *   - Node（主进程与测试）：通过 module.exports 引用
 * 注意：这里计算的是“采样峰值”，不是过采样的真峰值（True Peak）。
 */

(function () {
const LOUDNESS_CONSTANTS = {
  shelf: { f0: 1681.974450955533, G: 3.999843853973347, Q: 0.7071752369554196 },
  hp: { f0: 38.13547087602444, Q: 0.5003270373238773 },
  blockMs: 400,
  stepMs: 100,
  absGate: -70,
  relGateOffset: -10
};

/** K 加权滤波器系数（按采样率推导，48 kHz 时与标准表一致） */
function kWeightCoefficients(fs) {
  const { shelf, hp } = LOUDNESS_CONSTANTS;
  // 第一级：高频搁架
  const K1 = Math.tan((Math.PI * shelf.f0) / fs);
  const Vh = Math.pow(10, shelf.G / 20);
  const Vb = Math.pow(Vh, 0.4997667);
  const a0s = 1 + K1 / shelf.Q + K1 * K1;
  const stage1 = {
    b: [(Vh + (Vb * K1) / shelf.Q + K1 * K1) / a0s, (2 * (K1 * K1 - Vh)) / a0s, (Vh - (Vb * K1) / shelf.Q + K1 * K1) / a0s],
    a: [1, (2 * (K1 * K1 - 1)) / a0s, (1 - K1 / shelf.Q + K1 * K1) / a0s]
  };
  // 第二级：RLB 高通
  const K2 = Math.tan((Math.PI * hp.f0) / fs);
  const a0h = 1 + K2 / hp.Q + K2 * K2;
  const stage2 = {
    b: [1, -2, 1],
    a: [1, (2 * (K2 * K2 - 1)) / a0h, (1 - K2 / hp.Q + K2 * K2) / a0h]
  };
  return [stage1, stage2];
}

/** 对一条声道做双二阶滤波（直接 I 型），返回新数组 */
function biquadFilter(x, { b, a }) {
  const y = new Float64Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let n = 0; n < x.length; n += 1) {
    const xn = x[n];
    const yn = b[0] * xn + b[1] * x1 + b[2] * x2 - a[1] * y1 - a[2] * y2;
    y[n] = yn;
    x2 = x1; x1 = xn; y2 = y1; y1 = yn;
  }
  return y;
}

/**
 * 测量积分响度与采样峰值
 * channels: Float32Array / Float64Array 数组（每个元素一个声道）
 * 返回 { lufs, peakDb, peakOffsetSec }；静音时 lufs 为 -Infinity
 * peakOffsetSec（v1.3.0）：最响的那一个采样点距文件开头的秒数，用于“最响点对齐”放置。
 */
function measureChannels(channels, sampleRate) {
  const chs = (channels || []).filter((c) => c && c.length);
  if (!chs.length) return { lufs: -Infinity, peakDb: -Infinity, peakOffsetSec: 0 };

  let peak = 0;
  let peakIndex = 0;
  for (const c of chs) {
    for (let i = 0; i < c.length; i += 1) {
      const v = Math.abs(c[i]);
      if (v > peak) { peak = v; peakIndex = i; }
    }
  }
  const peakDb = peak > 0 ? 20 * Math.log10(peak) : -Infinity;
  const peakOffsetSec = sampleRate > 0 ? peakIndex / sampleRate : 0;
  const truePeakDb = interSamplePeakDb(chs, peak);
  const zcr = zeroCrossingRate(chs[0], sampleRate);

  const [s1, s2] = kWeightCoefficients(sampleRate);
  const weighted = chs.map((c) => biquadFilter(biquadFilter(c, s1), s2));
  const len = weighted[0].length;
  const block = Math.max(1, Math.round((LOUDNESS_CONSTANTS.blockMs / 1000) * sampleRate));
  const step = Math.max(1, Math.round((LOUDNESS_CONSTANTS.stepMs / 1000) * sampleRate));

  // 每个块的加权均方和（声道权重都为 1）
  const blockZ = [];
  if (len < block) {
    // 不足 400 ms：整段作为一个块（短音效也能测）
    let z = 0;
    for (const w of weighted) { let s = 0; for (let i = 0; i < len; i += 1) s += w[i] * w[i]; z += s / len; }
    blockZ.push(z);
  } else {
    for (let start = 0; start + block <= len; start += step) {
      let z = 0;
      for (const w of weighted) {
        let s = 0;
        for (let i = start; i < start + block; i += 1) s += w[i] * w[i];
        z += s / block;
      }
      blockZ.push(z);
    }
  }
  const lk = (z) => (z > 0 ? -0.691 + 10 * Math.log10(z) : -Infinity);

  // 绝对门限 -70 LUFS
  const abs = blockZ.filter((z) => lk(z) > LOUDNESS_CONSTANTS.absGate);
  if (!abs.length) return { lufs: -Infinity, peakDb, peakOffsetSec, truePeakDb, zcr };
  const meanAbs = abs.reduce((a, b) => a + b, 0) / abs.length;
  const relGate = lk(meanAbs) + LOUDNESS_CONSTANTS.relGateOffset;
  const rel = abs.filter((z) => lk(z) > relGate);
  const meanRel = rel.reduce((a, b) => a + b, 0) / rel.length;
  return { lufs: lk(meanRel), peakDb, peakOffsetSec, truePeakDb, zcr };
}

/**
 * 采样间峰值估计（v1.4.0）：对每个局部最大值用相邻三点抛物线插值，近似真峰值（True Peak）。
 * 比 4 倍过采样便宜得多，误差通常在 0.3 dB 以内；静音返回 -Infinity。
 */
function interSamplePeakDb(chs, samplePeak) {
  if (!(samplePeak > 0)) return -Infinity;
  const threshold = samplePeak * 0.5; // 只看接近峰值的区域
  let best = samplePeak;
  for (const c of chs) {
    for (let i = 1; i < c.length - 1; i += 1) {
      const y1 = Math.abs(c[i]);
      if (y1 < threshold) continue;
      const y0 = Math.abs(c[i - 1]), y2 = Math.abs(c[i + 1]);
      if (y1 < y0 || y1 < y2) continue;
      const denom = y0 - 2 * y1 + y2;
      if (denom >= 0) continue;
      const x = (0.5 * (y0 - y2)) / denom;
      if (x > -1 && x < 1) {
        const yp = y1 - 0.25 * (y0 - y2) * x;
        if (yp > best) best = yp;
      }
    }
  }
  return 20 * Math.log10(best);
}

/** 过零率（0~1，越大越“亮”/越嘈杂），用于“找相似” */
function zeroCrossingRate(x, sampleRate) {
  if (!x || x.length < 2) return 0;
  let n = 0;
  for (let i = 1; i < x.length; i += 1) if ((x[i] >= 0) !== (x[i - 1] >= 0)) n += 1;
  // 归一化：每秒过零次数 / 奈奎斯特频率的两倍（纯白噪声约 0.5）
  const perSec = (n / x.length) * sampleRate;
  return Math.min(1, perSec / sampleRate);
}

/**
 * 波形缩略图（v1.4.0）：按 bins 段取各段最大绝对值，归一化到 0~100 的整数数组
 * channels: Float32Array / Float64Array 数组
 */
function waveformBins(channels, bins = 140) {
  const chs = (channels || []).filter((c) => c && c.length);
  if (!chs.length) return [];
  const len = chs[0].length;
  const out = new Array(bins).fill(0);
  const step = len / bins;
  for (let b = 0; b < bins; b += 1) {
    const s0 = Math.floor(b * step), s1 = Math.max(s0 + 1, Math.floor((b + 1) * step));
    let m = 0;
    for (const c of chs) for (let i = s0; i < s1 && i < c.length; i += 1) { const v = Math.abs(c[i]); if (v > m) m = v; }
    out[b] = m;
  }
  const max = Math.max(...out);
  if (!(max > 0)) return out.map(() => 0);
  // 用平方根拉开小信号，缩略图更容易看出形状
  return out.map((v) => Math.round(Math.sqrt(v / max) * 100));
}

/**
 * 放置增益：把响度调到目标值，但不超过最大提升/衰减，并保证峰值不超过天花板
 * sound: { loudness, peakDb }（loudness 为 null 时不调整）
 * 返回 { gainDb, limitedByPeak, reason }
 */
function placementGain(sound, targetLufs, opts = {}) {
  const maxBoost = opts.maxBoostDb ?? 12;
  const maxCut = opts.maxCutDb ?? -24;
  const ceiling = opts.peakCeilingDb ?? -1;
  const lufs = sound ? sound.loudness : null;
  if (!Number.isFinite(lufs)) return { gainDb: 0, limitedByPeak: false, reason: 'no-loudness' };
  if (!Number.isFinite(targetLufs)) return { gainDb: 0, limitedByPeak: false, reason: 'no-target' };
  if (lufs < -60) return { gainDb: 0, limitedByPeak: false, reason: 'too-quiet-to-measure' };
  let g = Math.min(maxBoost, Math.max(maxCut, targetLufs - lufs));
  let limited = false;
  const peak = sound.peakDb;
  if (Number.isFinite(peak) && peak + g > ceiling) {
    g = ceiling - peak;
    limited = true;
  }
  g = Math.round(g * 10) / 10;
  return { gainDb: g, limitedByPeak: limited, reason: limited ? 'peak-limited' : 'ok' };
}

const api = { measureChannels, kWeightCoefficients, placementGain, waveformBins, interSamplePeakDb, zeroCrossingRate, LOUDNESS_CONSTANTS };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof window !== 'undefined') window.SfxLoudness = api;
})();
