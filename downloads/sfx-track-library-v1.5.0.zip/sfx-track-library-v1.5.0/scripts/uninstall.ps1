﻿# 音效轨道库 —— 卸载脚本
$ErrorActionPreference = 'Stop'
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}
$dest = Join-Path $env:ProgramData 'Blackmagic Design\DaVinci Resolve\Support\Workflow Integration Plugins\com.sfxlib.resolve'
if (Test-Path $dest) {
    Remove-Item $dest -Recurse -Force
    Write-Host '插件已卸载。你的音效库数据和设置没有被删除。' -ForegroundColor Green
} else {
    Write-Host '没有找到已安装的插件。'
}
Read-Host '按回车键关闭窗口'
