﻿# 音效轨道库 —— 生成对外发布包（Make-Release.bat 调用）
#
# 做的事：
#   1. 读取 plugin/package.json 的版本号，并检查 manifest.xml 一致
#   2. 把 Install/Uninstall、scripts、plugin、tests(*.js)、文档、LICENSE 复制到 release/音效轨道库-v<版本>/
#   3. 扫描私人信息（release.private.json 的 privatePatterns + 通用关键词），发现就中止
#   4. 打成 release/sfx-track-library-v<版本>.zip，计算 SHA256
#   5. 从 更新说明.md 里提取本版要点，生成 version.json
#   6. 把 zip、version.json、更新说明、使用说明、robots.txt 放进 docs/（docs 就是发布站的全部内容）
#   7. 按 release.config.json 的 siteBaseUrl 写 plugin/update-source.json（插件检查更新的地址）
#   8. 若配置了 publishRepoUrl：把 docs/ 同步到发布站仓库的本地目录并 git 推送（-NoPublish 跳过）
param([switch]$NoZip, [switch]$NoPublish)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$utf8 = New-Object Text.UTF8Encoding($false)

$root = Split-Path $PSScriptRoot -Parent
$pluginDir = Join-Path $root 'plugin\com.sfxlib.resolve'
$cfgPath = Join-Path $root 'release.config.json'
$cfg = if (Test-Path $cfgPath) { Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } else { [pscustomobject]@{} }
$siteBase = ([string]$cfg.siteBaseUrl).Trim().TrimEnd('/')
$productName = if ($cfg.productName) { [string]$cfg.productName } else { '音效轨道库' }
$minResolve = if ($cfg.minResolve) { [string]$cfg.minResolve } else { '20.2.2' }
$privPath = Join-Path $root 'release.private.json'
$priv = if (Test-Path $privPath) { Get-Content $privPath -Raw -Encoding UTF8 | ConvertFrom-Json } else { $null }
# git：优先 PATH，其次 release.private.json 的 gitPath
$git = (Get-Command git -ErrorAction SilentlyContinue | Select-Object -First 1).Source
if (-not $git -and $priv -and $priv.gitPath -and (Test-Path $priv.gitPath)) { $git = [string]$priv.gitPath }

$pkg = Get-Content (Join-Path $pluginDir 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$ver = [string]$pkg.version
if ($ver -notmatch '^\d+(\.\d+){1,3}$') { throw "package.json 的 version 不合法：$ver" }
$manifest = Get-Content (Join-Path $pluginDir 'manifest.xml') -Raw -Encoding UTF8
if ($manifest -notmatch "<Version>$([regex]::Escape($ver))</Version>") { throw "manifest.xml 的 <Version> 与 package.json（$ver）不一致，请先改成一样。" }

Write-Host "=== 生成发布包 v$ver ===" -ForegroundColor Cyan

# 1) 插件的更新源地址（先写，再复制）
if ($siteBase) {
    $src = [ordered]@{ url = "$siteBase/version.json"; pageUrl = "$siteBase/" }
    [IO.File]::WriteAllText((Join-Path $pluginDir 'update-source.json'), ($src | ConvertTo-Json), $utf8)
    Write-Host "更新源：$siteBase/version.json"
} else {
    Write-Host '提示：release.config.json 的 siteBaseUrl 为空，version.json 里不会有下载链接，插件也不会自动检查更新。' -ForegroundColor Yellow
}

# 2) 复制到暂存目录
$out = Join-Path $root 'release'
$folderName = "sfx-track-library-v$ver"   # 顶层文件夹用 ASCII 名，避免在非中文系统上乱码
$zipName = "sfx-track-library-v$ver.zip"
$stage = Join-Path $out $folderName
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $stage | Out-Null
foreach ($f in @('Install.bat', 'Uninstall.bat', 'LICENSE', 'README.md', 'CHANGELOG.md', '更新说明.md', '使用说明.md', '快速上手.md')) {
    $p = Join-Path $root $f
    if (Test-Path $p) { Copy-Item $p $stage } else { Write-Host "  （没有 $f，跳过）" -ForegroundColor DarkGray }
}
Copy-Item (Join-Path $root 'scripts') $stage -Recurse
Copy-Item (Join-Path $root 'plugin') $stage -Recurse
Get-ChildItem (Join-Path $stage 'plugin') -Recurse -File | Where-Object { $_.Name -like 'selftest-*' -or $_.Name -eq 'WorkflowIntegration.node' } | Remove-Item -Force
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'tests') | Out-Null
Get-ChildItem (Join-Path $root 'tests') -File -Filter '*.js' | Copy-Item -Destination (Join-Path $stage 'tests')

# 3) 私人信息扫描
$patterns = @('try' + 'cloudflare')
if ($priv -and $priv.privatePatterns) { $patterns += @($priv.privatePatterns | Where-Object { $_ }) }
elseif (-not $priv) { Write-Host '  （没有 release.private.json，只扫描通用关键词）' -ForegroundColor DarkGray }
if ($cfg.privatePatterns) { $patterns += @($cfg.privatePatterns | Where-Object { $_ }) }
# 扫描暂存目录里的文本文件（本脚本自身除外：它的默认模式字符串会误报）
$textFiles = Get-ChildItem $stage -Recurse -File | Where-Object { ($_.Extension -in '.md', '.js', '.json', '.ps1', '.bat', '.html', '.css', '.xml', '.txt' -or $_.Name -eq 'LICENSE') -and $_.Name -ne 'make-release.ps1' }
$leaks = $textFiles | Select-String -Pattern $patterns -List -ErrorAction SilentlyContinue
if ($leaks) {
    foreach ($l in $leaks) { Write-Host ("  含私人信息: " + $l.Path.Substring($stage.Length + 1) + "  ->  " + $l.Line.Trim()) -ForegroundColor Red }
    throw '发布包里含有私人信息（路径、用户名、项目名或连接地址），已中止。请先清理再重新生成。'
}
Write-Host ("已暂存 " + (Get-ChildItem $stage -Recurse -File).Count + " 个文件，私人信息扫描通过")

if ($NoZip) { Write-Host "（-NoZip）只生成了文件夹：$stage"; exit 0 }

# 4) 打 zip（.NET，文件名按 UTF-8 存储并打标记，中文文件名在 macOS / 其他语言的 Windows 上也不会乱码）+ SHA256
$zipPath = Join-Path $out $zipName
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
# 不用 ZipFile.CreateFromDirectory：Windows PowerShell 下它会把路径分隔符写成反斜杠，macOS 解压会出问题
$zipStream = [IO.File]::Open($zipPath, [IO.FileMode]::Create)
$zipArchive = New-Object IO.Compression.ZipArchive($zipStream, [IO.Compression.ZipArchiveMode]::Create, $false, [Text.Encoding]::UTF8)
try {
    foreach ($f in Get-ChildItem $stage -Recurse -File) {
        $rel = $f.FullName.Substring($stage.Length + 1).Replace('\', '/')
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zipArchive, $f.FullName, "$folderName/$rel", [IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $zipArchive.Dispose(); $zipStream.Dispose() }
# 用 .NET 算 SHA256（Get-FileHash 在某些嵌套启动的 Windows PowerShell 里找不到）
$sha256 = [System.Security.Cryptography.SHA256]::Create()
try { $sha = ([BitConverter]::ToString($sha256.ComputeHash([IO.File]::ReadAllBytes($zipPath))) -replace '-', '').ToLower() } finally { $sha256.Dispose() }
$size = (Get-Item $zipPath).Length

# 5) version.json（要点来自 更新说明.md 里本版的 "- " 行）
$notes = @()
$notesPath = Join-Path $root '更新说明.md'
if (Test-Path $notesPath) {
    $doc = Get-Content $notesPath -Raw -Encoding UTF8
    $m = [regex]::Match($doc, "(?ms)^## $([regex]::Escape($ver))[^\r\n]*\r?\n(.*?)(?=^## |\z)")
    if ($m.Success) {
        $notes = @([regex]::Matches($m.Groups[1].Value, '(?m)^- (.+)$') | ForEach-Object { (($_.Groups[1].Value -replace '\*\*', '') -replace '`', '').Trim() } | Select-Object -First 10)
    } else { Write-Host "  更新说明.md 里没有 '## $ver' 小节，version.json 的要点为空" -ForegroundColor Yellow }
}
$info = [ordered]@{
    name = $productName; version = $ver; releasedAt = (Get-Date -Format 'yyyy-MM-dd'); minResolve = $minResolve
    downloadUrl = $(if ($siteBase) { "$siteBase/downloads/$zipName" } else { '' })
    pageUrl = $(if ($siteBase) { "$siteBase/" } else { '' })
    notesUrl = $(if ($siteBase) { "$siteBase/更新说明.md" } else { '' })
    sha256 = $sha; size = $size; notes = @($notes)
}
$json = $info | ConvertTo-Json -Depth 4
$json = [regex]::Replace($json, '\\u([0-9a-fA-F]{4})', { param($mm) [string][char][Convert]::ToInt32($mm.Groups[1].Value, 16) })
[IO.File]::WriteAllText((Join-Path $out 'version.json'), $json, $utf8)

# 6) docs：整个目录发布到网上
$docs = Join-Path $root 'docs'
$dl = Join-Path $docs 'downloads'
New-Item -ItemType Directory -Force -Path $dl | Out-Null
Copy-Item $zipPath $dl -Force
[IO.File]::WriteAllText((Join-Path $docs 'version.json'), $json, $utf8)
foreach ($f in @('更新说明.md', '使用说明.md')) { $p = Join-Path $root $f; if (Test-Path $p) { Copy-Item $p $docs -Force } }
Remove-Item (Join-Path $docs 'CHANGELOG.md') -ErrorAction SilentlyContinue
if (-not (Test-Path (Join-Path $docs '.nojekyll'))) { [IO.File]::WriteAllText((Join-Path $docs '.nojekyll'), '', $utf8) }
# 不让搜索引擎收录发布站
[IO.File]::WriteAllText((Join-Path $docs 'robots.txt'), "User-agent: *`nDisallow: /`n", $utf8)

Write-Host ''
Write-Host "发布包：$zipPath" -ForegroundColor Green
Write-Host ("大小：" + [math]::Round($size / 1KB) + " KB   SHA256：$sha")
Write-Host "version.json：$(Join-Path $out 'version.json')（docs/ 里也放了一份）"
Write-Host ("要点（" + $notes.Count + " 条）：") ; $notes | ForEach-Object { Write-Host ("  - " + $_) }
# 7) 同步到发布站仓库并推送
$pubUrl = [string]$cfg.publishRepoUrl
if ($NoPublish -or -not $pubUrl) {
    Write-Host ''
    Write-Host '接下来：把 docs/ 目录里的全部内容发布到 siteBaseUrl 对应的位置。' -ForegroundColor Cyan
    exit 0
}
if (-not $git) { throw '找不到 git.exe：请安装 Git，或在 release.private.json 里填写 gitPath。' }
$pubDir = [string]$cfg.publishRepoDir
if (-not $pubDir) { $pubDir = '..\release-site' }
$pubDir = [IO.Path]::GetFullPath((Join-Path $root $pubDir))
$branch = if ($cfg.publishBranch) { [string]$cfg.publishBranch } else { 'main' }
Write-Host ''
Write-Host "=== 发布到 $pubUrl ===" -ForegroundColor Cyan
if (-not (Test-Path (Join-Path $pubDir '.git'))) {
    New-Item -ItemType Directory -Force -Path (Split-Path $pubDir -Parent) | Out-Null
    & $git clone --quiet $pubUrl $pubDir
    if ($LASTEXITCODE -ne 0) { throw "克隆发布站仓库失败：$pubUrl" }
}
Push-Location $pubDir
$prevEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'   # git 会往 stderr 写普通信息，不能当成错误
try {
    & $git fetch --quiet origin 2>&1 | Out-Null
    & $git rev-parse --verify --quiet "origin/$branch" 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { & $git checkout --quiet -B $branch "origin/$branch" 2>&1 | Out-Null }
    else { & $git checkout --quiet -B $branch 2>&1 | Out-Null }   # 空仓库：第一次推送
    # 镜像同步 docs/ → 发布站（保留 .git）
    Get-ChildItem $pubDir -Force | Where-Object { $_.Name -ne '.git' } | Remove-Item -Recurse -Force
    Copy-Item (Join-Path $docs '*') $pubDir -Recurse -Force
    if (-not (Test-Path (Join-Path $pubDir 'README.md'))) { [IO.File]::WriteAllText((Join-Path $pubDir 'README.md'), "Release files for a DaVinci Resolve plugin.`n", $utf8) }
    & $git add -A 2>&1 | Out-Null
    & $git -c user.name=release -c user.email=release@local commit --quiet -m "v$ver" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Write-Host '发布站没有变化，无需提交' }
    $pushOut = & $git push --quiet -u origin $branch 2>&1
    if ($LASTEXITCODE -ne 0) { Write-Host ($pushOut | Out-String); throw '推送发布站失败（网络或登录问题）。可稍后重新运行 Make-Release.bat。' }
    Write-Host "已推送到发布站：$siteBase/   （GitHub Pages 约 1～2 分钟后生效）" -ForegroundColor Green
} finally { $ErrorActionPreference = $prevEAP; Pop-Location }
