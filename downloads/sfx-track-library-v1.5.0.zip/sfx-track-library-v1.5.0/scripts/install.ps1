﻿# 音效轨道库 —— 安装脚本（Windows，DaVinci Resolve Studio）
$ErrorActionPreference = 'Stop'

# 需要管理员权限写入 ProgramData，自动提权
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

function Pause-Exit($code) {
    Write-Host ''
    Read-Host '按回车键关闭窗口'
    exit $code
}

try {
    $pluginId = 'com.sfxlib.resolve'
    $src = Join-Path (Split-Path $PSScriptRoot -Parent) "plugin\$pluginId"
    $support = Join-Path $env:ProgramData 'Blackmagic Design\DaVinci Resolve\Support'
    $pluginRoot = Join-Path $support 'Workflow Integration Plugins'
    $dest = Join-Path $pluginRoot $pluginId

    Write-Host '=== 音效轨道库 安装程序 ===' -ForegroundColor Cyan

    if (-not (Test-Path $src)) { throw "找不到插件文件夹：$src" }
    if (-not (Test-Path $support)) { throw "没有找到达芬奇的安装目录：$support`n请确认已安装 DaVinci Resolve Studio（从官网下载的版本）。" }

    if (Get-Process -Name 'Resolve' -ErrorAction SilentlyContinue) {
        Write-Host '检测到达芬奇正在运行。安装完成后需要重启达芬奇才能看到插件。' -ForegroundColor Yellow
    }

    # WorkflowIntegration.node 由达芬奇自带，必须与达芬奇版本一致，所以从本机安装目录复制
    $node = Join-Path $support 'Developer\Workflow Integrations\Examples\SamplePlugin\WorkflowIntegration.node'
    if (-not (Test-Path $node)) {
        $found = Get-ChildItem (Join-Path $support 'Developer') -Recurse -Filter 'WorkflowIntegration.node' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) { $node = $found.FullName }
    }
    if (-not (Test-Path $node)) { throw '没有找到 WorkflowIntegration.node。请确认使用的是 DaVinci Resolve Studio，并且安装时包含了开发者文档。' }

    New-Item -ItemType Directory -Force -Path $pluginRoot | Out-Null
    if (Test-Path $dest) {
        Write-Host '发现旧版本，正在替换…'
        Remove-Item $dest -Recurse -Force
    }
    Copy-Item $src $dest -Recurse
    Copy-Item $node (Join-Path $dest 'WorkflowIntegration.node') -Force

    Write-Host ''
    Write-Host "安装完成：$dest" -ForegroundColor Green
    Write-Host '重启达芬奇后，在菜单「工作区(Workspace) › 工作流集成(Workflow Integrations)」里打开「音效轨道库」。'
    Write-Host '音效库与插件分开保存，实际位置以面板“设置”页显示为准；重装/升级不会删除库数据。'
    Pause-Exit 0
}
catch {
    Write-Host ''
    Write-Host "安装失败：$($_.Exception.Message)" -ForegroundColor Red
    Pause-Exit 1
}
