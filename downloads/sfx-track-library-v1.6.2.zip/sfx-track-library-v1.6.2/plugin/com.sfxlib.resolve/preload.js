'use strict';

const { contextBridge, ipcRenderer, webUtils } = require('electron');

const call = (channel) => (...args) => ipcRenderer.invoke(channel, ...args);

contextBridge.exposeInMainWorld('sfx', {
  state: call('app:state'),
  status: call('resolve:status'),
  saveSettings: call('settings:save'),

  chooseLibrary: call('lib:choose'),
  openLibrary: call('lib:open'),
  exportLibrary: call('lib:export'),
  importLibrary: call('lib:import'),
  syncPool: call('pool:sync'),

  addCategory: call('cat:add'),
  updateCategory: call('cat:update'),
  deleteCategory: call('cat:delete'),

  pickFiles: call('sfx:pickFiles'),
  addFiles: call('sfx:addFiles'),
  addFromResolve: call('sfx:addFromResolve'),
  updateSound: call('sfx:update'),
  deleteSound: call('sfx:delete'),
  soundToTimeline: call('sfx:toTimeline'),
  batchSounds: call('sfx:batch'),
  readSoundBytes: call('sfx:readBytes'),
  setLoudness: call('sfx:setLoudness'),
  getSound: call('sfx:getSound'),
  timelinePoints: call('timeline:points'),
  placeBatch: call('sfx:placeBatch'),
  duckMusic: call('music:duck'),
  addStack: call('stack:add'),
  updateStack: call('stack:update'),
  deleteStack: call('stack:delete'),
  placeStack: call('stack:place'),
  addCollection: call('coll:add'),
  updateCollection: call('coll:update'),
  deleteCollection: call('coll:delete'),
  syncCollection: call('coll:sync'),
  libraryHealth: call('lib:health'),
  removeMissing: call('lib:removeMissing'),
  fillAmbience: call('fill:ambience'),
  auditionPlace: call('audition:place'),
  auditionConfirm: call('audition:confirm'),
  auditionCancel: call('audition:cancel'),
  auditionStatus: call('audition:status'),
  exportCueSheet: call('report:cuesheet'),
  createStandardTracks: call('tl:standardTracks'),
  stackFromSelection: call('stack:fromSelection'),
  tidyPlan: call('tidy:plan'),
  tidyApply: call('tidy:apply'),
  checkUpdate: call('update:check'),
  updateInfo: call('update:info'),
  downloadUpdate: call('update:download'),
  skipUpdate: call('update:skip'),
  openUpdatePage: call('update:open'),
  /** 主进程推送的更新结果 / 下载进度（v1.5.0） */
  onUpdateResult: (fn) => { ipcRenderer.on('update:result', (_e, r) => fn(r)); },
  onUpdateProgress: (fn) => { ipcRenderer.on('update:progress', (_e, p) => fn(p)); },
  restoreSounds: call('sfx:restore'),
  revealSound: call('sfx:reveal'),
  markUsed: call('sfx:markUsed'),
  setDuration: call('sfx:setDuration'),
  startDrag: (id) => ipcRenderer.send('sfx:startDrag', id),

  saveTemplate: call('tpl:save'),
  applyTemplate: call('tpl:apply'),
  getTemplate: call('tpl:get'),
  updateTemplate: call('tpl:update'),
  deleteTemplate: call('tpl:delete'),
  revealTemplate: call('tpl:reveal'),

  /** 拖入文件时取得真实路径（Electron 32+ 不再提供 File.path） */
  pathForFile: (file) => {
    try {
      if (webUtils && webUtils.getPathForFile) return webUtils.getPathForFile(file);
    } catch {}
    return file && file.path ? file.path : '';
  }
});
