'use strict';

/**
 * 音效轨道库 —— DaVinci Resolve Studio 工作流集成插件（Electron 主进程）
 */

const { app, BrowserWindow, dialog, ipcMain, shell, screen, net } = require('electron');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const updateLib = require('./lib/update');
const { Library, UserError } = require('./lib/library');
const { ResolveBridge } = require('./lib/resolve-bridge');
const { placementGain } = require('./js/loudness');

const PLUGIN_ID = 'com.sfxlib.resolve'; // 必须与 manifest.xml 中的 <Id> 一致
const SETTINGS_DIR = path.join(app.getPath('appData'), 'DaVinciSfxTrackLibrary');
const SETTINGS_FILE = path.join(SETTINGS_DIR, 'settings.json');

let mainWindow = null;
let library = null;
let settings = null;
const bridge = new ResolveBridge(PLUGIN_ID, __dirname);

// ---------- 设置 ----------

function defaultSettings() {
  return {
    libraryPath: path.join(app.getPath('documents'), '达芬奇音效库'),
    poolRootName: '音效库',
    copyFiles: true,
    learnOnMove: true,
    autoSaveBeforeApply: true,
    alwaysOnTop: true,
    defaultTarget: 'new',
    defaultPosition: 'original',
    soundTarget: 'route',        // v1.3.0：默认按分类放到固定音轨（'new' 新建 / 音轨序号）
    placeAlign: 'auto',          // v1.3.0：放置对齐方式 auto（分类默认）/ head / peak / tail
    placeAudio: defaultPlaceAudio(),
    ducking: defaultDucking(),
    batchPlace: defaultBatchPlace(),
    windowBounds: null,          // v1.3.1：记住面板上次的位置和大小
    theme: 'dark',               // v1.4.0：dark / light / system
    ambience: defaultAmbience(),
    update: defaultUpdate(),      // v1.5.0：联网检查更新
    tidy: defaultTidy(),          // v1.6.0：一键整理音轨
    schema: SETTINGS_SCHEMA
  };
}

function defaultTidy() {
  return { mode: 'detailed', backup: true, deleteEmpty: true, dropDisabled: true, gapFrames: 0 };
}
function sanitizeTidy(v) {
  const d = defaultTidy();
  const src = v && typeof v === 'object' ? v : {};
  const gap = Number(src.gapFrames);
  return { mode: src.mode === 'simple' || src.mode === 'compact' ? 'simple' : 'detailed', backup: src.backup === undefined ? d.backup : Boolean(src.backup), deleteEmpty: src.deleteEmpty === undefined ? d.deleteEmpty : Boolean(src.deleteEmpty), dropDisabled: src.dropDisabled === undefined ? d.dropDisabled : Boolean(src.dropDisabled), gapFrames: Number.isFinite(gap) ? Math.min(100, Math.max(0, Math.round(gap))) : 0 };
}

// ---------- 检查更新（v1.5.0） ----------

const APP_VERSION = (() => {
  try { return String(JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version || '0.0.0'); } catch { return '0.0.0'; }
})();

/** 更新源：plugin/update-source.json（由 Make-Release.bat 按 release.config.json 生成）；没有就不自动检查 */
function builtinUpdateSource() {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(__dirname, 'update-source.json'), 'utf8'));
    return { url: updateLib.isHttpUrl(j.url) ? String(j.url) : '', pageUrl: updateLib.isHttpUrl(j.pageUrl) ? String(j.pageUrl) : '' };
  } catch {
    return { url: '', pageUrl: '' };
  }
}

function defaultUpdate() {
  return { auto: true, url: '', skippedVersion: '', lastCheckedAt: null, lastResult: null };
}

function sanitizeUpdate(v) {
  const d = defaultUpdate();
  const src = v && typeof v === 'object' ? v : {};
  return {
    auto: src.auto === undefined ? d.auto : Boolean(src.auto),
    url: updateLib.isHttpUrl(src.url) ? String(src.url).trim().slice(0, 2000) : '',
    skippedVersion: updateLib.VERSION_RE.test(String(src.skippedVersion || '')) ? String(src.skippedVersion) : '',
    lastCheckedAt: typeof src.lastCheckedAt === 'string' ? src.lastCheckedAt : null,
    lastResult: src.lastResult && typeof src.lastResult === 'object' ? src.lastResult : null
  };
}

/** 实际使用的更新源地址：用户在设置里填的优先，否则用安装包自带的 */
function updateSourceUrl() {
  return (settings.update && settings.update.url) || builtinUpdateSource().url;
}

/** 用 Electron 的 net 模块下载（走系统代理设置）；返回 Buffer，带大小与超时限制 */
function fetchBuffer(url, { timeoutMs = 15000, maxBytes = 2 * 1024 * 1024, onProgress } = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const done = (fn, v) => { if (!settled) { settled = true; clearTimeout(timer); fn(v); } };
    const timer = setTimeout(() => { try { req.abort(); } catch {} done(reject, new Error('连接超时')); }, timeoutMs);
    let req;
    try {
      req = net.request({ url, method: 'GET', redirect: 'follow', useSessionCookies: false });
    } catch (e) {
      return done(reject, e);
    }
    req.setHeader('User-Agent', `SfxTrackLibrary/${APP_VERSION} (${process.platform})`);
    req.setHeader('Cache-Control', 'no-cache');
    req.on('response', (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) {
        res.on('data', () => {});
        res.on('end', () => done(reject, new Error(`服务器返回 ${res.statusCode}`)));
        return;
      }
      const total = Number(res.headers['content-length']) || 0;
      if (total > maxBytes) return done(reject, new Error('文件太大'));
      const chunks = [];
      let got = 0;
      res.on('data', (c) => {
        got += c.length;
        if (got > maxBytes) { try { req.abort(); } catch {} return done(reject, new Error('文件太大')); }
        chunks.push(c);
        if (onProgress) onProgress(got, total);
      });
      res.on('end', () => done(resolve, Buffer.concat(chunks)));
      res.on('error', (e) => done(reject, e));
    });
    req.on('error', (e) => done(reject, e));
    req.end();
  });
}

/** 检查一次：读取 version.json → 校验 → 与当前版本比较；结果写进设置 */
async function checkForUpdate({ manual = false } = {}) {
  const url = updateSourceUrl();
  const base = { checkedAt: new Date().toISOString(), currentVersion: APP_VERSION, url };
  if (!url) {
    const r = { ...base, status: 'unconfigured', message: '没有设置更新源地址' };
    settings.update.lastResult = r;
    return r;
  }
  let result;
  try {
    const buf = await fetchBuffer(url, { timeoutMs: manual ? 20000 : 12000, maxBytes: 256 * 1024 });
    const info = updateLib.normalizeInfo(JSON.parse(buf.toString('utf8')));
    const ev = updateLib.evaluate(info, APP_VERSION, settings.update.skippedVersion);
    result = { ...base, status: ev.status, isNewer: ev.isNewer, skipped: ev.skipped, info };
  } catch (e) {
    result = { ...base, status: 'error', message: e && e.message ? e.message : String(e) };
  }
  settings.update.lastCheckedAt = base.checkedAt;
  settings.update.lastResult = result;
  await saveSettings().catch(() => {});
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('update:result', result);
  return result;
}

/** 下载安装包到“下载”文件夹并核对 SHA256；成功后在资源管理器里选中它 */
async function downloadUpdate(opts = {}) {
  const r = settings.update.lastResult;
  const info = r && r.info;
  if (!info || !info.downloadUrl) throw new UserError('没有可下载的安装包地址，请先检查更新。');
  const dir = app.getPath('downloads');
  const name = updateLib.fileNameFromUrl(info.downloadUrl, `sfx-track-library-v${info.version}.zip`);
  let dest = path.join(dir, name);
  const ext = path.extname(name), baseName = path.basename(name, ext);
  for (let i = 2; fs.existsSync(dest); i += 1) dest = path.join(dir, `${baseName} (${i})${ext}`);
  let lastSent = 0;
  const buf = await fetchBuffer(info.downloadUrl, {
    timeoutMs: 120000, maxBytes: 200 * 1024 * 1024,
    onProgress: (got, total) => {
      const now = Date.now();
      if (now - lastSent > 200 && mainWindow && !mainWindow.isDestroyed()) { lastSent = now; mainWindow.webContents.send('update:progress', { got, total }); }
    }
  });
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  if (info.sha256 && sha !== info.sha256) throw new UserError('下载的文件校验失败（SHA256 不一致），已丢弃。请稍后重试或到下载页手动下载。');
  await fsp.writeFile(dest, buf);
  if (opts.reveal !== false) shell.showItemInFolder(dest);
  return { file: dest, size: buf.length, sha256: sha, verified: Boolean(info.sha256) };
}

/** 氛围铺底默认参数（v1.4.0） */
function defaultAmbience() {
  return { crossfadeMs: 1500, fadeInMs: 500, fadeOutMs: 1000 };
}
function sanitizeAmbience(v) {
  const d = defaultAmbience();
  const src = v && typeof v === 'object' ? v : {};
  const num = (k, lo, hi) => { const n = Number(src[k]); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d[k]; };
  return { crossfadeMs: num('crossfadeMs', 0, 20000), fadeInMs: num('fadeInMs', 0, 20000), fadeOutMs: num('fadeOutMs', 0, 20000) };
}
const THEMES = ['dark', 'light', 'system'];

/** 设置文件版本：2 = 1.3.x（放置目标默认“按分类固定轨”） */
const SETTINGS_SCHEMA = 2;

/** 对白避让默认参数（v1.3.0） */
function defaultDucking() {
  return { reduceDb: 9, preMs: 150, postMs: 250, fadeMs: 250, mergeGapMs: 700 };
}

function sanitizeDucking(v) {
  const d = defaultDucking();
  const src = v && typeof v === 'object' ? v : {};
  const num = (key, lo, hi) => {
    const n = Number(src[key]);
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d[key];
  };
  return { reduceDb: Math.abs(num('reduceDb', 1, 40)), preMs: num('preMs', 0, 5000), postMs: num('postMs', 0, 5000), fadeMs: num('fadeMs', 0, 5000), mergeGapMs: num('mergeGapMs', 0, 20000) };
}

/** 批量放置上次使用的选项（v1.3.0） */
function defaultBatchPlace() {
  return { source: 'markers', markerColor: '', preFrames: 0, rotate: true, align: 'auto' };
}

function sanitizeBatchPlace(v) {
  const d = defaultBatchPlace();
  const src = v && typeof v === 'object' ? v : {};
  const pre = Number(src.preFrames);
  return {
    source: src.source === 'cuts' ? 'cuts' : 'markers',
    markerColor: typeof src.markerColor === 'string' ? src.markerColor.slice(0, 30) : '',
    preFrames: Number.isFinite(pre) ? Math.min(250, Math.max(-250, Math.round(pre))) : d.preFrames,
    rotate: src.rotate === undefined ? d.rotate : Boolean(src.rotate),
    align: ALIGN_OPTIONS.includes(src.align) ? src.align : 'auto'
  };
}

const ALIGN_OPTIONS = ['auto', 'head', 'peak', 'tail'];

/** 放入时间线的音频设置（v1.2.1）：是否按响度调整、目标 LUFS、淡入淡出（毫秒） */
function defaultPlaceAudio() {
  return {
    normalize: true,
    targetLufs: { sfx: -18, music: -20 },
    fadeIn: { sfx: 0, music: 500 },
    fadeOut: { sfx: 0, music: 1500 }
  };
}

function sanitizePlaceAudio(v) {
  const d = defaultPlaceAudio();
  const src = v && typeof v === 'object' ? v : {};
  const pick = (obj, key, lo, hi, fallback) => {
    const n = Number(obj?.[key]);
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : fallback;
  };
  return {
    normalize: src.normalize === undefined ? d.normalize : Boolean(src.normalize),
    targetLufs: {
      sfx: pick(src.targetLufs, 'sfx', -40, -6, d.targetLufs.sfx),
      music: pick(src.targetLufs, 'music', -40, -6, d.targetLufs.music)
    },
    fadeIn: {
      sfx: pick(src.fadeIn, 'sfx', 0, 10000, d.fadeIn.sfx),
      music: pick(src.fadeIn, 'music', 0, 10000, d.fadeIn.music)
    },
    fadeOut: {
      sfx: pick(src.fadeOut, 'sfx', 0, 10000, d.fadeOut.sfx),
      music: pick(src.fadeOut, 'music', 0, 10000, d.fadeOut.music)
    }
  };
}

/** 计算某条音效放入时要用的增益与淡入淡出（毫秒） */
function placementAudio(s) {
  const pa = sanitizePlaceAudio(settings.placeAudio);
  const kind = s.kind === 'music' ? 'music' : 'sfx';
  const out = { gainDb: 0, gainReason: 'off', fadeInMs: pa.fadeIn[kind], fadeOutMs: pa.fadeOut[kind] };
  if (pa.normalize) {
    // 有真峰值估计时用它做峰值保护
    const g = placementGain(Number.isFinite(s.truePeakDb) ? { ...s, peakDb: Math.max(s.truePeakDb, Number.isFinite(s.peakDb) ? s.peakDb : -Infinity) } : s, pa.targetLufs[kind]);
    out.gainDb = g.gainDb;
    out.gainReason = g.reason;
  }
  return out;
}

async function loadSettings() {
  let raw;
  try {
    raw = JSON.parse(await fsp.readFile(SETTINGS_FILE, 'utf8'));
  } catch {
    return defaultSettings();
  }
  const st = { ...defaultSettings(), ...raw };
  // 1.3.x：老设置里的“总是新建音轨”一次性改为“按分类固定轨”（只看文件里原有的版本号，之后用户自己改的会保留）
  const fileSchema = Number(raw.schema) || 0;
  if (fileSchema < 2) {
    if (raw.soundTarget === 'new' || raw.soundTarget === undefined) st.soundTarget = 'route';
  }
  st.schema = SETTINGS_SCHEMA;
  delete st.routeMigrated;
  if (!ALIGN_OPTIONS.includes(st.placeAlign)) st.placeAlign = 'auto';
  st.placeAudio = sanitizePlaceAudio(st.placeAudio);
  st.ducking = sanitizeDucking(st.ducking);
  st.batchPlace = sanitizeBatchPlace(st.batchPlace);
  st.windowBounds = sanitizeBounds(st.windowBounds);
  st.theme = THEMES.includes(st.theme) ? st.theme : 'dark';
  st.ambience = sanitizeAmbience(st.ambience);
  st.update = sanitizeUpdate(st.update);
  st.tidy = sanitizeTidy(st.tidy);
  return st;
}

function sanitizeBounds(b) {
  if (!b || typeof b !== 'object') return null;
  const n = (v) => (Number.isFinite(Number(v)) ? Math.round(Number(v)) : null);
  const out = { x: n(b.x), y: n(b.y), width: n(b.width), height: n(b.height) };
  if (out.width === null || out.height === null || out.width < 420 || out.height < 520) return null;
  return out;
}

/** 上次的窗口位置还在某个屏幕上才沿用，否则回到默认位置 */
function restoredBounds() {
  const b = settings.windowBounds;
  if (!b || b.x === null || b.y === null) return b ? { width: b.width, height: b.height } : {};
  const visible = screen.getAllDisplays().some((d) => {
    const a = d.workArea;
    return b.x + 80 < a.x + a.width && b.x + b.width - 80 > a.x && b.y + 40 < a.y + a.height && b.y + 40 > a.y;
  });
  return visible ? b : { width: b.width, height: b.height };
}

let boundsTimer = null;
function rememberBounds() {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.isMinimized() || mainWindow.isMaximized()) return;
  clearTimeout(boundsTimer);
  boundsTimer = setTimeout(() => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    settings.windowBounds = sanitizeBounds(mainWindow.getBounds());
    saveSettings().catch(() => {});
  }, 600);
}

/**
 * 置顶（v1.3.1 修复）：实测 Electron 36 在 Windows 上 BrowserWindow 的 alwaysOnTop 选项和 'floating' 层级
 * 都不会真正置顶（窗口没有 WS_EX_TOPMOST），'screen-saver' 层级才有效。
 */
function applyAlwaysOnTop(on) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (on) {
    mainWindow.setAlwaysOnTop(true, 'screen-saver');
    if (typeof mainWindow.moveTop === 'function') mainWindow.moveTop();
  } else {
    mainWindow.setAlwaysOnTop(false);
  }
}

async function saveSettings() {
  await fsp.mkdir(SETTINGS_DIR, { recursive: true });
  await fsp.writeFile(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf8');
}

async function openLibrary(dir) {
  library = await new Library(dir).load();
  settings.libraryPath = dir;
  await saveSettings();
}

// ---------- 串行执行 Resolve 调用，避免并发 ----------

let chain = Promise.resolve();
function serial(fn) {
  const p = chain.then(fn, fn);
  chain = p.catch(() => {});
  return p;
}

function handle(channel, fn) {
  ipcMain.handle(channel, (_event, ...args) =>
    serial(async () => {
      try {
        return { ok: true, data: await fn(...args) };
      } catch (error) {
        console.error(`[${channel}]`, error);
        return { ok: false, error: error instanceof UserError ? error.message : `出错了：${error.message}` };
      }
    })
  );
}

function state() {
  return { settings, library: library.snapshot() };
}

// ---------- IPC ----------

function registerIpc() {
  handle('app:state', async () => state());
  handle('resolve:status', async () => bridge.status());

  handle('settings:save', async (patch) => {
    const allowed = ['poolRootName', 'copyFiles', 'learnOnMove', 'autoSaveBeforeApply', 'alwaysOnTop', 'defaultTarget', 'defaultPosition', 'soundTarget'];
    for (const k of allowed) if (patch[k] !== undefined) settings[k] = patch[k];
    if (patch.placeAlign !== undefined) settings.placeAlign = ALIGN_OPTIONS.includes(patch.placeAlign) ? patch.placeAlign : 'auto';
    if (patch.placeAudio !== undefined) settings.placeAudio = sanitizePlaceAudio(patch.placeAudio);
    if (patch.ducking !== undefined) settings.ducking = sanitizeDucking({ ...settings.ducking, ...patch.ducking });
    if (patch.ambience !== undefined) settings.ambience = sanitizeAmbience({ ...settings.ambience, ...patch.ambience });
    if (patch.theme !== undefined) settings.theme = THEMES.includes(patch.theme) ? patch.theme : 'dark';
    if (patch.update !== undefined) settings.update = sanitizeUpdate({ ...settings.update, ...patch.update });
    if (patch.tidy !== undefined) settings.tidy = sanitizeTidy({ ...settings.tidy, ...patch.tidy });
    if (patch.batchPlace !== undefined) settings.batchPlace = sanitizeBatchPlace({ ...settings.batchPlace, ...patch.batchPlace });
    settings.poolRootName = String(settings.poolRootName || '').trim() || '音效库';
    await saveSettings();
    applyAlwaysOnTop(Boolean(settings.alwaysOnTop));
    return state();
  });

  // 库位置 / 导入导出
  handle('lib:choose', async () => {
    const r = await dialog.showOpenDialog(mainWindow, { title: '选择音效库文件夹（可以是网盘/NAS 同步目录）', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    await openLibrary(r.filePaths[0]);
    return state();
  });
  handle('lib:open', async () => shell.openPath(library.root));
  handle('lib:export', async () => {
    const r = await dialog.showOpenDialog(mainWindow, { title: '选择导出到哪个文件夹', properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    const dest = await library.exportTo(r.filePaths[0]);
    shell.showItemInFolder(path.join(dest, 'library.json'));
    return dest;
  });
  handle('lib:import', async () => {
    const r = await dialog.showOpenDialog(mainWindow, { title: '选择要导入的音效库文件夹（里面有 library.json）', properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    if (!fs.existsSync(path.join(r.filePaths[0], 'library.json'))) throw new UserError('这个文件夹里没有 library.json，不是音效库。');
    if (path.resolve(r.filePaths[0]) === path.resolve(library.root)) throw new UserError('不能导入当前正在使用的库。');
    return { result: await library.mergeFrom(r.filePaths[0]), state: state() };
  });

  // 媒体池
  handle('pool:sync', async () => bridge.syncLibrary(library, settings.poolRootName));

  // 分类
  handle('cat:add', async (name, kind) => {
    await library.addCategory(name, null, kind === 'music' ? 'music' : 'sfx');
    return state();
  });
  handle('cat:update', async (id, patch) => {
    await library.updateCategory(id, patch);
    return state();
  });
  handle('cat:delete', async (id) => {
    await library.deleteCategory(id);
    return state();
  });

  // 音效
  handle('sfx:pickFiles', async () => {
    const r = await dialog.showOpenDialog(mainWindow, {
      title: '选择音效文件',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: '音频', extensions: ['wav', 'mp3', 'aif', 'aiff', 'flac', 'm4a', 'aac', 'ogg', 'caf', 'bwf', 'wma', 'opus'] }]
    });
    return r.canceled ? [] : r.filePaths;
  });
  handle('sfx:addFiles', async (paths, category, kind) => {
    const list = await expandPaths(paths);
    const results = await library.addSounds(list, category || null, { copy: settings.copyFiles, kind: kind === 'music' ? 'music' : 'sfx' });
    return { results: summarize(results), state: state() };
  });
  handle('sfx:addFromResolve', async (source, category, kind) => {
    const paths = await bridge.poolItemsFromSelection(source);
    if (!paths.length) throw new UserError(source === 'timeline' ? '时间线上没有选中带源文件的片段。' : '媒体池里没有选中片段。');
    const results = await library.addSounds(paths, category || null, { copy: settings.copyFiles, kind: kind === 'music' ? 'music' : 'sfx' });
    return { results: summarize(results), state: state() };
  });
  handle('sfx:update', async (id, patch) => {
    await library.updateSound(id, patch, { learn: settings.learnOnMove });
    return state();
  });
  handle('sfx:delete', async (id, deleteFile) => {
    await library.deleteSound(id, deleteFile);
    return state();
  });
  handle('sfx:toTimeline', async (id, target, position, opts) => {
    const s = library.sound(id);
    if (!s) throw new UserError('音效不存在。');
    const audio = placementAudio(s);
    const align = opts && ALIGN_OPTIONS.includes(opts.align) ? opts.align : settings.placeAlign || 'auto';
    const r = await bridge.placeSound(library, s, target || settings.soundTarget, settings, position === 'start' ? 'start' : 'playhead', audio, { align });
    return { ...r, audio, state: state() };
  });
  // v1.3.0：时间线上的标记 / 画面切点
  handle('timeline:points', async (opts) => bridge.timelinePoints(opts || {}));
  // v1.3.0：按标记或切点批量放置
  handle('sfx:placeBatch', async (ids, points, opts) => {
    const sounds = (Array.isArray(ids) ? ids : []).map((id) => library.sound(id)).filter(Boolean);
    const o = opts || {};
    const r = await bridge.placeBatch(library, sounds, Array.isArray(points) ? points : [], {
      preFrames: o.preFrames, align: ALIGN_OPTIONS.includes(o.align) ? o.align : settings.placeAlign || 'auto',
      target: o.target === undefined || o.target === '' ? settings.soundTarget : o.target, rotate: o.rotate !== false
    }, settings, placementAudio);
    return { ...r, state: state() };
  });
  // v1.3.0：音乐避让对白
  handle('music:duck', async (opts) => {
    const o = { ...settings.ducking, ...(opts || {}) };
    const r = await bridge.duckMusic(o, settings);
    settings.ducking = sanitizeDucking(o);
    await saveSettings();
    return r;
  });
  // v1.3.0：音效套餐
  handle('stack:add', async (payload) => {
    await library.addStack(payload || {});
    return state();
  });
  handle('stack:update', async (id, patch) => {
    await library.updateStack(id, patch || {});
    return state();
  });
  handle('stack:delete', async (id) => {
    await library.deleteStack(id);
    return state();
  });
  handle('stack:place', async (id, position) => {
    const k = library.stack(id);
    if (!k) throw new UserError('套餐不存在。');
    const r = await bridge.placeStack(library, k, settings, position === 'start' ? 'start' : 'playhead', placementAudio);
    return { ...r, state: state() };
  });
  // 响度测量：读取音频字节交给渲染进程解码；测量结果写回库
  handle('sfx:readBytes', async (id) => {
    const s = library.sound(id);
    if (!s) throw new UserError('音效不存在。');
    return fsp.readFile(library.abs(s.file));
  });
  handle('sfx:setLoudness', async (id, m) => {
    await library.setLoudness(id, m || {});
    return true;
  });
  handle('sfx:getSound', async (id) => {
    const s = library.sound(id);
    if (!s) throw new UserError('音效不存在。');
    return { ...s };
  });
  handle('sfx:batch', async (ids, action, payload) => {
    const r = await library.batch(Array.isArray(ids) ? ids : [], action, payload || {});
    return { ...r, state: state() };
  });
  handle('sfx:restore', async (list) => {
    await library.restore(list);
    return state();
  });
  handle('sfx:markUsed', async (id) => {
    await library.markUsed(id);
    return state();
  });
  handle('sfx:reveal', async (id) => {
    const s = library.sound(id);
    if (s) shell.showItemInFolder(library.abs(s.file));
    return true;
  });

  // 轨道模板
  handle('tpl:save', async (trackIndices, opts) => {
    const selected = (Array.isArray(trackIndices) ? trackIndices : [trackIndices]).map(Number);
    const r = await bridge.captureTracks(library, selected, opts || {});
    return { ...r, state: state() };
  });
  handle('tpl:apply', async (id, opts) => {
    const r = await bridge.applyTemplate(library, id, opts || {}, settings);
    return { ...r, state: state() };
  });
  handle('tpl:get', async (id) => {
    const t = library.template(id);
    if (!t) throw new UserError('模板不存在。');
    return t;
  });
  handle('tpl:update', async (id, patch) => {
    await library.updateTemplate(id, patch);
    return state();
  });
  handle('tpl:delete', async (id) => {
    await library.deleteTemplate(id);
    return state();
  });
  handle('tpl:reveal', async (id) => shell.openPath(library.templateDir(id)));

  // v1.4.0：素材包
  handle('coll:add', async (name, ids, note) => {
    await library.addCollection(name, Array.isArray(ids) ? ids : [], note || '');
    return state();
  });
  handle('coll:update', async (id, patch) => {
    await library.updateCollection(id, patch || {});
    return state();
  });
  handle('coll:delete', async (id) => {
    await library.deleteCollection(id);
    return state();
  });
  handle('coll:sync', async (id) => {
    const c = library.collection(id);
    if (!c) throw new UserError('素材包不存在。');
    const r = await bridge.syncLibrary(library, settings.poolRootName, { onlyIds: new Set(c.soundIds) });
    await library.markCollectionUsed(id);
    return r;
  });
  // v1.4.0：库健康检查
  handle('lib:health', async () => library.health());
  handle('lib:removeMissing', async () => ({ removed: await library.removeMissing(), state: state() }));
  // v1.4.0：氛围铺底
  handle('fill:ambience', async (id, opts) => {
    const s = library.sound(id);
    if (!s) throw new UserError('音效不存在。');
    const o = { ...settings.ambience, ...(opts || {}) };
    const r = await bridge.fillAmbience(library, s, o, settings, placementAudio(s));
    settings.ambience = sanitizeAmbience(o);
    await saveSettings();
    return { ...r, state: state() };
  });
  // v1.4.0：时间线试听
  handle('audition:place', async (id, opts) => {
    const s = library.sound(id);
    if (!s) throw new UserError('音效不存在。');
    const o = opts || {};
    const align = ALIGN_OPTIONS.includes(o.align) ? o.align : settings.placeAlign || 'auto';
    return bridge.auditionPlace(library, s, settings, placementAudio(s), { align, anchorFrame: o.anchorFrame });
  });
  handle('audition:confirm', async (opts) => {
    const a = bridge.audition;
    const s = a ? library.sound(a.soundId) : null;
    const r = await bridge.auditionConfirm(library, settings, s ? placementAudio(s) : {}, opts || {});
    return { ...r, state: state() };
  });
  handle('audition:cancel', async () => bridge.auditionCancel());
  handle('audition:status', async () => (bridge.audition ? { ...bridge.audition } : null));
  // v1.4.0：音频使用清单（CSV）
  handle('report:cuesheet', async (opts) => {
    const inv = await bridge.audioInventory(library);
    const musicOnly = !opts || opts.scope !== 'all';
    const rows = musicOnly ? inv.rows.filter((r) => r.kind === 'music' || !r.inLibrary) : inv.rows;
    const r = await dialog.showSaveDialog(mainWindow, {
      title: '导出音频使用清单',
      defaultPath: path.join(app.getPath('documents'), `${safeFile(inv.project)}-${safeFile(inv.timeline)}-${musicOnly ? '音乐使用清单' : '音频使用清单'}.csv`),
      filters: [{ name: 'CSV 表格', extensions: ['csv'] }]
    });
    if (r.canceled || !r.filePath) return null;
    const head = ['序号', '轨道', '轨道名', '片段名', '入点', '出点', '时长(秒)', '类型', '库内名称', '分类', '来源', '授权/许可', 'BPM', '调性', '情绪', '音量(dB)', '文件路径'];
    const csvCell = (v) => { const t = v === null || v === undefined ? '' : String(v); return /[",\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t; };
    const lines = [head.join(',')];
    rows.forEach((x, i) => {
      lines.push([i + 1, `A${x.track}`, x.trackName, x.clipName, x.startTc, x.endTc, x.durationSec, x.inLibrary ? (x.kind === 'music' ? '音乐' : '音效') : '未入库', x.libName, x.category, x.source, x.license, x.bpm || '', x.key, x.mood, x.volumeDb === null ? '' : x.volumeDb, x.filePath].map(csvCell).join(','));
    });
    await fsp.writeFile(r.filePath, '\ufeff' + lines.join('\r\n') + '\r\n', 'utf8');
    shell.showItemInFolder(r.filePath);
    return { file: r.filePath, rows: rows.length, total: inv.rows.length, project: inv.project, timeline: inv.timeline };
  });
  // v1.4.0：一键建立标准音轨
  handle('tl:standardTracks', async (names) => bridge.createStandardTracks(Array.isArray(names) ? names : []));

  // v1.6.0：把时间线选中的音效存为组合（套餐）
  handle('stack:fromSelection', async (opts) => {
    const r = await bridge.captureSelectionAsStack(library, opts || {}, settings);
    return { ...r, state: state() };
  });
  // v1.6.0：一键整理音轨
  handle('tidy:plan', async (opts) => {
    const o = { ...settings.tidy, ...(opts || {}) };
    const plan = await bridge.tidyPlan(library, o);
    settings.tidy = sanitizeTidy(o);
    await saveSettings();
    return plan;
  });
  handle('tidy:apply', async (opts) => {
    const o = { ...settings.tidy, ...(opts || {}) };
    const r = await bridge.tidyApply(library, o, settings);
    settings.tidy = sanitizeTidy(o);
    await saveSettings();
    return r;
  });

  // v1.5.0：检查更新（不走达芬奇串行队列，用普通 handler）
  ipcMain.handle('update:check', async () => {
    try { return { ok: true, data: await checkForUpdate({ manual: true }) }; } catch (e) { return { ok: false, error: `出错了：${e.message}` }; }
  });
  ipcMain.handle('update:info', async () => ({ ok: true, data: { currentVersion: APP_VERSION, builtin: builtinUpdateSource(), effectiveUrl: updateSourceUrl(), settings: settings.update } }));
  ipcMain.handle('update:download', async () => {
    try { return { ok: true, data: await downloadUpdate() }; } catch (e) { return { ok: false, error: e instanceof UserError ? e.message : `下载失败：${e.message}` }; }
  });
  ipcMain.handle('update:skip', async (_e, version) => {
    settings.update.skippedVersion = updateLib.VERSION_RE.test(String(version || '')) ? String(version) : '';
    await saveSettings();
    return { ok: true, data: settings.update };
  });
  ipcMain.handle('update:open', async (_e, which) => {
    const r = settings.update.lastResult;
    const info = r && r.info;
    const builtin = builtinUpdateSource();
    const url = which === 'notes' ? (info && info.notesUrl) || (info && info.pageUrl) || builtin.pageUrl : (info && info.pageUrl) || builtin.pageUrl;
    if (updateLib.isHttpUrl(url)) await shell.openExternal(url);
    return { ok: true, data: Boolean(url) };
  });

  // 从面板直接把音效拖进达芬奇（时间线 / 媒体池）
  ipcMain.on('sfx:startDrag', (event, id) => {
    const s = library?.sound(id);
    if (!s) return;
    const file = library.abs(s.file);
    if (!fs.existsSync(file)) return;
    event.sender.startDrag({ file, icon: path.join(__dirname, 'img', 'drag.png') });
  });

  // 时长等轻量信息，不走串行队列
  ipcMain.handle('sfx:setDuration', async (_e, id, duration) => {
    try {
      const s = library.sound(id);
      if (s && Number.isFinite(duration)) {
        s.duration = duration;
        await library.save();
      }
    } catch {}
    return true;
  });
}

const safeFile = (name) => String(name || '').replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').trim().slice(0, 60) || '未命名';

async function expandPaths(paths) {
  const out = [];
  async function walk(p, depth) {
    let st;
    try {
      st = await fsp.stat(p);
    } catch {
      return;
    }
    if (st.isDirectory() && depth < 4) {
      for (const name of await fsp.readdir(p)) await walk(path.join(p, name), depth + 1);
    } else if (st.isFile()) out.push(p);
  }
  for (const p of paths || []) await walk(p, 0);
  return out;
}

function summarize(results) {
  const added = results.filter((r) => r.status === 'added');
  return {
    added: added.length,
    auto: added.filter((r) => r.auto).map((r) => ({ name: r.sound.name, category: r.sound.category })),
    duplicate: results.filter((r) => r.status === 'duplicate').length,
    skipped: results.filter((r) => r.status === 'skipped').length
  };
}

// ---------- 窗口 ----------

function createWindow() {
  const bounds = restoredBounds();
  mainWindow = new BrowserWindow({
    width: bounds.width || 560,
    height: bounds.height || 820,
    ...(bounds.x !== undefined && bounds.x !== null ? { x: bounds.x, y: bounds.y } : {}),
    minWidth: 420,
    minHeight: 520,
    useContentSize: false,
    title: '音效轨道库',
    backgroundColor: settings.theme === 'light' ? '#f2f2f7' : '#141518',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    applyAlwaysOnTop(Boolean(settings.alwaysOnTop));
    mainWindow.focus();
    // 启动 4 秒后静默检查一次更新（每天最多一次；没有更新源或用户关闭则不检查）
    setTimeout(() => {
      if (settings.update && settings.update.auto && updateSourceUrl() && updateLib.shouldAutoCheck(settings.update.lastCheckedAt)) {
        checkForUpdate({ manual: false }).catch(() => {});
      }
    }, 4000);
  });
  // 达芬奇把面板带到前面或用户点回来时，确认置顶状态还在
  mainWindow.on('show', () => applyAlwaysOnTop(Boolean(settings.alwaysOnTop)));
  mainWindow.on('focus', () => { if (settings.alwaysOnTop && !mainWindow.isAlwaysOnTop()) applyAlwaysOnTop(true); });
  mainWindow.on('move', rememberBounds);
  mainWindow.on('resize', rememberBounds);
  mainWindow.on('closed', () => {
    mainWindow = null;
    app.quit();
  });
}

app.whenReady().then(async () => {
  settings = await loadSettings();
  try {
    await openLibrary(settings.libraryPath);
  } catch (error) {
    // 库路径失效（比如 U 盘拔了）就回到默认位置
    settings.libraryPath = defaultSettings().libraryPath;
    await openLibrary(settings.libraryPath);
    console.error('库加载失败，已使用默认位置', error);
  }
  registerIpc();
  createWindow();
});

app.on('window-all-closed', () => app.quit());
app.on('quit', () => bridge.cleanup());
